package extra;

public class ItemL {
	public int id;
	public int count;
	public int rarity;
	
	public ItemL(int id, int count, int rarity) {
		this.id = id;
		this.count = count;
		this.rarity = rarity;
	}
	
	
}
