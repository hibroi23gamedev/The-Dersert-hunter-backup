package shadows;

import org.lwjgl.util.vector.Matrix4f;
import shaders.ShaderProgram;

public class ShadowShader extends ShaderProgram {
   private static final String VERTEX_FILE = "/shadows/shadowVertexShader.txt";
   private static final String FRAGMENT_FILE = "/shadows/shadowFragmentShader.txt";
   private int location_mvpMatrix;

   protected ShadowShader() {
      super("/shadows/shadowVertexShader.txt", "/shadows/shadowFragmentShader.txt");
   }

   protected void getAllUniformLocations() {
      this.location_mvpMatrix = super.getUniformLocation("mvpMatrix");
   }

   protected void loadMvpMatrix(Matrix4f mvpMatrix) {
      super.loadMatrix(this.location_mvpMatrix, mvpMatrix);
   }

   protected void bindATTR() {
      super.bindATTR(0, "in_position");
      super.bindATTR(1, "in_textureCoords");
   }
}
