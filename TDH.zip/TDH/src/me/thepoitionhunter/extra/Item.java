package me.thepoitionhunter.extra;

import java.awt.image.BufferedImage;

public class Item {
	public String name;
	public BufferedImage img;
	public int maxstack;
	public int width;
	public int height;
	
	public Item(String name, int width, int height, BufferedImage img, int maxstack) {
		this.name = name;
		this.width = width;
		this.height = height;
		this.img = img;
		this.maxstack = maxstack;
	}
}
