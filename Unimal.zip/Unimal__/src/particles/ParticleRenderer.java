package particles;

import entitys.Camera;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import models.RawModel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import render.Loader;
import toolbox.Maths;

public class ParticleRenderer {
   private static final float[] VERTICES = new float[]{-0.5F, 0.5F, -0.5F, -0.5F, 0.5F, 0.5F, 0.5F, -0.5F};
   private static final int MAX_INSTANCES = 10000;
   private static final int INSTANCE_DATA_LENGTH = 21;
   private RawModel quad;
   private ParticleShader shader;
   private Loader loader;
   private int vbo;

   protected ParticleRenderer(Loader loader, Matrix4f projectionMatrix) {
      this.loader = loader;
      this.vbo = loader.createEmptyVbo(210000);
      this.quad = loader.loadToVAO(VERTICES, 2, null);
      this.shader = new ParticleShader();
      this.shader.start();
      this.shader.loadProjectionMatrix(projectionMatrix);
      this.shader.stop();
   }

   protected void render(Map<ParticleTexture, List<Particle>> particles, Camera camera) {
      Matrix4f viewMatrix = Maths.createView(camera);
      this.prepare();
      Iterator var5 = particles.keySet().iterator();

      while(var5.hasNext()) {
         ParticleTexture texture = (ParticleTexture)var5.next();
         this.bindTexture(texture);
         this.shader.loadNumberOfRows((float)texture.getNumberofRows());
         Iterator var7 = ((List)particles.get(texture)).iterator();

         while(var7.hasNext()) {
            Particle part = (Particle)var7.next();
            this.updateModelViewMatrix(part.getPosition(), part.getRotation(), part.getScale(), viewMatrix);
            GL11.glDrawArrays(5, 0, this.quad.getVertexCount());
         }
      }

      this.finishRendering();
   }

   private void updateModelViewMatrix(Vector3f position, float rotation, float scale, Matrix4f viewMatrix) {
      Matrix4f modelMatrix = new Matrix4f();
      Matrix4f.translate(position, modelMatrix, modelMatrix);
      modelMatrix.m00 = viewMatrix.m00;
      modelMatrix.m01 = viewMatrix.m10;
      modelMatrix.m02 = viewMatrix.m20;
      modelMatrix.m10 = viewMatrix.m01;
      modelMatrix.m11 = viewMatrix.m11;
      modelMatrix.m12 = viewMatrix.m21;
      modelMatrix.m20 = viewMatrix.m02;
      modelMatrix.m21 = viewMatrix.m12;
      modelMatrix.m22 = viewMatrix.m22;
      Matrix4f modelViewMatrix = Matrix4f.mul(viewMatrix, modelMatrix, (Matrix4f)null);
      Matrix4f.rotate((float)Math.toRadians((double)rotation), new Vector3f(0.0F, 0.0F, 1.0F), modelViewMatrix, modelViewMatrix);
      Matrix4f.scale(new Vector3f(scale, scale, scale), modelViewMatrix, modelViewMatrix);
   }

   private void bindTexture(ParticleTexture texture) {
      GL13.glActiveTexture(33984);
      GL11.glBindTexture(3553, texture.getTextureID());
   }

   protected void cleanUp() {
      this.shader.cleanUp();
   }

   private void prepare() {
      this.shader.start();
      GL30.glBindVertexArray(this.quad.getVaoID());
      GL20.glEnableVertexAttribArray(0);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(false);
   }

   private void finishRendering() {
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL20.glDisableVertexAttribArray(0);
      GL30.glBindVertexArray(0);
      this.shader.stop();
   }
}
