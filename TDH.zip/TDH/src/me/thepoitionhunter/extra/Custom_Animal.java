package me.thepoitionhunter.extra;

import java.awt.image.BufferedImage;

public class Custom_Animal {
	public BufferedImage left;
	public BufferedImage right;
	public BufferedImage up;
	public BufferedImage down;
	public BufferedImage dead;
	public int invgive;
	public int width;
	public int height;
	public String name;
}
