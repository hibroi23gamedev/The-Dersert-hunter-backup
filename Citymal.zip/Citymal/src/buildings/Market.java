package buildings;

import java.util.ArrayList;

import building_cs.Building_Componment;
import building_cs.*;
import models.TexturedModel;
import render.Loader;
import render.ModelData;
import render.OBJFileLoader;
import textures.ModelTexture;
import models.RawModel;

public class Market extends Building_Type{
	static String name = "Market";
	static String description = "shop";
	public static TexturedModel model;
	static ArrayList<Building_Componment> components = new ArrayList<Building_Componment>();

	public Market(Loader loader) {
		super(name, description, components);
		ModelData data = OBJFileLoader.loadOBJ("buildings/market");
		RawModel raw = loader.loadtoVAO(data.getVertices(), data.getTextureCoords(), data.getNormals(), data.getIndices(), data);
		ModelTexture texture = new ModelTexture(loader.loadTexture("buildings/market"));
		Market.texture = texture;
		TexturedModel model = new TexturedModel(raw, texture);
		Market.model = model;
		this.id = 1;
		this.components.add(new Owning());
	}

	@Override
	public void update() {
		
	}
}
