package extra;

import org.lwjgl.util.vector.Vector3f;

import models.TexturedModel;

public class Rig {
	public TexturedModel model;
	public Vector3f offset;
	public Vector3f position;
	public float scale;
	
	public Vector3f rotation;
	
	public Vector3f or_rotation;
	
	public int type;

	public Rig(TexturedModel model, Vector3f offset, Vector3f position, float scale, Vector3f rotation, int type) {
		super();
		this.model = model;
		this.offset = offset;
		this.position = position;
		this.scale = scale;
		this.rotation = rotation;
		this.or_rotation = rotation;
		this.type = type;
	}
}
