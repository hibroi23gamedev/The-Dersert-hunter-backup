package items;

public class ItemPro {
   boolean heal;
   float healamount;
   int timetouse;
   boolean isuseable;

   public boolean isHeal() {
      return this.heal;
   }

   public void setHeal(boolean heal) {
      this.heal = heal;
   }

   public float getHealamount() {
      return this.healamount;
   }

   public void setHealamount(float healamount) {
      this.healamount = healamount;
   }

   public int getTimetouse() {
      return this.timetouse;
   }

   public void setTimetouse(int timetouse) {
      this.timetouse = timetouse;
   }

   public boolean isIsuseable() {
      return this.isuseable;
   }

   public void setIsuseable(boolean isuseable) {
      this.isuseable = isuseable;
   }
}
