package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_BUSH extends SuperObect{
	GamePanel gp;
	public OBJ_BUSH(GamePanel gp) {
		this.gp = gp;
		name = "bush";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/bush.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = true;
	}
}
