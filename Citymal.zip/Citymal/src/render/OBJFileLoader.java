package render;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

public class OBJFileLoader {
   private static final String RES_LOC = "res/";

   public static ModelData loadOBJ(String objFileName) {
      FileReader isr = null;
      File objFile = new File("res/" + objFileName + ".obj");

      try {
         isr = new FileReader(objFile);
      } catch (FileNotFoundException var15) {
         System.err.println("File not found in res; don't use any extention");
      }

      BufferedReader reader = new BufferedReader(isr);
      List<Vertex> vertices = new ArrayList();
      List<Vector2f> textures = new ArrayList();
      List<Vector3f> normals = new ArrayList();
      ArrayList indices = new ArrayList();

      try {
         String line;
         String[] currentLine;
         label47:
         do {
            while(true) {
               while(true) {
                  while(true) {
                     line = reader.readLine();
                     Vector3f normal;
                     if (!line.startsWith("v ")) {
                        if (!line.startsWith("vt ")) {
                           if (!line.startsWith("vn ")) {
                              continue label47;
                           }

                           currentLine = line.split(" ");
                           normal = new Vector3f(Float.valueOf(currentLine[1]), Float.valueOf(currentLine[2]), Float.valueOf(currentLine[3]));
                           normals.add(normal);
                        } else {
                           currentLine = line.split(" ");
                           Vector2f texture = new Vector2f(Float.valueOf(currentLine[1]), Float.valueOf(currentLine[2]));
                           textures.add(texture);
                        }
                     } else {
                        currentLine = line.split(" ");
                        normal = new Vector3f(Float.valueOf(currentLine[1]), Float.valueOf(currentLine[2]), Float.valueOf(currentLine[3]));
                        Vertex newVertex = new Vertex(vertices.size(), normal);
                        vertices.add(newVertex);
                     }
                  }
               }
            }
         } while(!line.startsWith("f "));

         while(line != null && line.startsWith("f ")) {
            currentLine = line.split(" ");
            String[] vertex1 = currentLine[1].split("/");
            String[] vertex2 = currentLine[2].split("/");
            String[] vertex3 = currentLine[3].split("/");
            processVertex(vertex1, vertices, indices);
            processVertex(vertex2, vertices, indices);
            processVertex(vertex3, vertices, indices);
            line = reader.readLine();
         }

         reader.close();
      } catch (IOException var16) {
         System.err.println("Error reading the file");
      }

      removeUnusedVertices(vertices);
      float[] verticesArray = new float[vertices.size() * 3];
      float[] texturesArray = new float[vertices.size() * 2];
      float[] normalsArray = new float[vertices.size() * 3];
      float furthest = convertDataToArrays(vertices, textures, normals, verticesArray, texturesArray, normalsArray);
      int[] indicesArray = convertIndicesListToArray(indices);
      ModelData data = new ModelData(vertices, verticesArray, texturesArray, normalsArray, indicesArray, furthest);
      return data;
   }

   private static void processVertex(String[] vertex, List<Vertex> vertices, List<Integer> indices) {
      int index = Integer.parseInt(vertex[0]) - 1;
      Vertex currentVertex = (Vertex)vertices.get(index);
      int textureIndex = Integer.parseInt(vertex[1]) - 1;
      int normalIndex = Integer.parseInt(vertex[2]) - 1;
      if (!currentVertex.isSet()) {
         currentVertex.setTextureIndex(textureIndex);
         currentVertex.setNormalIndex(normalIndex);
         indices.add(index);
      } else {
         dealWithAlreadyProcessedVertex(currentVertex, textureIndex, normalIndex, indices, vertices);
      }

   }

   private static int[] convertIndicesListToArray(List<Integer> indices) {
      int[] indicesArray = new int[indices.size()];

      for(int i = 0; i < indicesArray.length; ++i) {
         indicesArray[i] = (Integer)indices.get(i);
      }

      return indicesArray;
   }

   private static float convertDataToArrays(List<Vertex> vertices, List<Vector2f> textures, List<Vector3f> normals, float[] verticesArray, float[] texturesArray, float[] normalsArray) {
      float furthestPoint = 0.0F;

      for(int i = 0; i < vertices.size(); ++i) {
         Vertex currentVertex = (Vertex)vertices.get(i);
         if (currentVertex.getLength() > furthestPoint) {
            furthestPoint = currentVertex.getLength();
         }

         Vector3f position = currentVertex.getPosition();
         Vector2f textureCoord = (Vector2f)textures.get(currentVertex.getTextureIndex());
         Vector3f normalVector = (Vector3f)normals.get(currentVertex.getNormalIndex());
         verticesArray[i * 3] = position.x;
         verticesArray[i * 3 + 1] = position.y;
         verticesArray[i * 3 + 2] = position.z;
         texturesArray[i * 2] = textureCoord.x;
         texturesArray[i * 2 + 1] = 1.0F - textureCoord.y;
         normalsArray[i * 3] = normalVector.x;
         normalsArray[i * 3 + 1] = normalVector.y;
         normalsArray[i * 3 + 2] = normalVector.z;
      }

      return furthestPoint;
   }

   private static void dealWithAlreadyProcessedVertex(Vertex previousVertex, int newTextureIndex, int newNormalIndex, List<Integer> indices, List<Vertex> vertices) {
      if (previousVertex.hasSameTextureAndNormal(newTextureIndex, newNormalIndex)) {
         indices.add(previousVertex.getIndex());
      } else {
         Vertex anotherVertex = previousVertex.getDuplicateVertex();
         if (anotherVertex != null) {
            dealWithAlreadyProcessedVertex(anotherVertex, newTextureIndex, newNormalIndex, indices, vertices);
         } else {
            Vertex duplicateVertex = new Vertex(vertices.size(), previousVertex.getPosition());
            duplicateVertex.setTextureIndex(newTextureIndex);
            duplicateVertex.setNormalIndex(newNormalIndex);
            previousVertex.setDuplicateVertex(duplicateVertex);
            vertices.add(duplicateVertex);
            indices.add(duplicateVertex.getIndex());
         }
      }

   }

   private static void removeUnusedVertices(List<Vertex> vertices) {
      Iterator var2 = vertices.iterator();

      while(var2.hasNext()) {
         Vertex vertex = (Vertex)var2.next();
         if (!vertex.isSet()) {
            vertex.setTextureIndex(0);
            vertex.setNormalIndex(0);
         }
      }

   }
}
