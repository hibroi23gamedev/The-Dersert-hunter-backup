package items;

public class Item {
   public String name;
   public int textureid;
   public ItemPro itemprotecties;

   public Item(String name, int textureid, ItemPro itemprotecties) {
      this.name = name;
      this.textureid = textureid;
      this.itemprotecties = itemprotecties;
   }
}
