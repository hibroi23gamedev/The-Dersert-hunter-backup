package extra;

import models.TexturedModel;

public class Road {
	public int type;
	public boolean placing;
	public TexturedModel model;
	public TexturedModel exmodel;
	public TexturedModel exinmodel;
	public TexturedModel extmodel;
	public TexturedModel exomodel;
	
	public Road(int type, TexturedModel model) {
		this.type = type;
		this.model = model;
	}
	
	public Road(int type) {
		this.type = type;
		this.model = TileManager.tile_types[type].model;
		this.exmodel = TileManager.tile_types[type].exmodel;
		this.exinmodel = TileManager.tile_types[type].exinmodel;
		this.extmodel = TileManager.tile_types[type].extmodel;
		this.exomodel = TileManager.tile_types[type].exomodel;
	}
}
