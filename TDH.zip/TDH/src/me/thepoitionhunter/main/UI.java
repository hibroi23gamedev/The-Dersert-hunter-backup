package me.thepoitionhunter.main;

import me.thepotionhunter.objects.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.lang.reflect.Array;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.FileWriter;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import me.thepoitionhunter.entity.player;
import me.thepoitionhunter.extra.Inventory;
import me.thepoitionhunter.extra.TutorialSpeech;

public class UI {
	GamePanel gp;
	player plr;
	Crafting cr;
	Graphics2D g2;
	KeyHandler keyH;
	Font arial_40;
	Font arial_10;
	boolean enter_world_name = false;
	BufferedImage thristImage;
	BufferedImage thristdownImage;
	BufferedImage thristdown1Image;
	BufferedImage thristdown2Image;
	BufferedImage thristdown3Image;
	BufferedImage thristdown4Image;
	BufferedImage heartImage;
	BufferedImage hotbarImage;
	BufferedImage hotbarselImage;
	BufferedImage heartdownImage;
	BufferedImage inventorysc;
	BufferedImage inventoryrsc;
	BufferedImage inventoryrsel;
	BufferedImage inventoryrinsel;
	public boolean messageOn = false;
	public String message = "";
	int messageCounter = 0;
	public TutorialSpeech[] tutorial = new TutorialSpeech[200];
	public int tuton = 0;
	public int tutcounter = 0;
	public UI(GamePanel gp, player plr, Crafting cr, KeyHandler keyH) {
		this.gp = gp;
		this.cr = cr;
		this.keyH = keyH;
		this.plr = plr;
		makeTutorial();
		arial_40 = new Font("Arial", Font.PLAIN, 40);
		arial_10 = new Font("Arial", Font.PLAIN, 20);
		try {
			thristImage = ImageIO.read(getClass().getResourceAsStream("/objects/water bottle.png"));
			thristdown1Image = ImageIO.read(getClass().getResourceAsStream("/objects/water bottlee1.png"));
			thristdown2Image = ImageIO.read(getClass().getResourceAsStream("/objects/water bottlee2.png"));
			thristdown3Image = ImageIO.read(getClass().getResourceAsStream("/objects/water bottlee3.png"));
			thristdown4Image = ImageIO.read(getClass().getResourceAsStream("/objects/water bottlee4.png"));
			thristdownImage = ImageIO.read(getClass().getResourceAsStream("/objects/emtry bottle.png"));
			heartImage = ImageIO.read(getClass().getResourceAsStream("/objects/heart.png"));
			hotbarImage = ImageIO.read(getClass().getResourceAsStream("/objects/hotbar ele.png"));
			hotbarselImage = ImageIO.read(getClass().getResourceAsStream("/objects/hotbar sel.png"));
			heartdownImage = ImageIO.read(getClass().getResourceAsStream("/objects/heartemtry.png"));
			inventorysc = ImageIO.read(getClass().getResourceAsStream("/objects/Crafting.png"));
			inventoryrsc = ImageIO.read(getClass().getResourceAsStream("/objects/Inventory.png"));
			inventoryrsel = ImageIO.read(getClass().getResourceAsStream("/objects/Inventorysel.png"));
			inventoryrinsel = ImageIO.read(getClass().getResourceAsStream("/objects/InventoryInsel.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void showMessage(String text) {
		message = text;
		messageOn = true;
		messageCounter = 0;
	}
	public void draw(Graphics2D g2, player plr) {
		this.g2 = g2;
		drawtem(plr);
		g2.setFont(arial_40);
		g2.setColor(Color.white);
		if(gp.gameState == gp.playState) {
			g2.drawString("Time Survived: "+ gp.time,60,gp.screenHeight - 50);
		}
		drawThristCounter(plr);
		drawHealthCounter(plr);
		drawHungerCounter(plr);
		if(gp.gameState == gp.playState) {
			drawandhandletut();
		}
		if(gp.gameState == gp.pauseState) {
			drawPauseScreen();
		}
		if(gp.gameState == gp.deadState) {
			drawDeadScreen();
		}
		drawhotbar(plr);
		if(gp.gameState == gp.inventorystate) {
			drawInventoryScreen();
		}
		if(gp.gameState == gp.menustate) {
			drawMenuScreen();
		}
		if(gp.gameState == gp.spraystate) {
			drawSprayScreen();
		}
		if(gp.gameState == gp.mapstate) {
			drawmapscreen();
		}
		if(gp.onmultiplayer == 1) {
			g2.setColor(Color.BLACK);
			g2.setFont(arial_40);
			g2.drawString("IP: 127.0.0.1:"+gp.port, 30, 180);
		}
	}
	public void drawInventoryScreen() {
		int width = 560;
		int height = 560;
		int x = 20;
		g2.drawImage(inventorysc,x, (gp.screenHeight / 2)- (height/2), null);
		g2.drawImage(inventoryrsc,x+160, (gp.screenHeight / 2)- (height/2), null);
		int index = 0;
		for(int i = 0; i < 11; i++) {
			for(int i1 = 0; i1 < 15; i1++) {
				int mousex = MouseInfo.getPointerInfo().getLocation().x-gp.frame.getLocation().x;
				int mousey = MouseInfo.getPointerInfo().getLocation().y-gp.frame.getLocation().y;
				if(mousex <= (x+360)+(i*32) 
						|| mousey <= ((gp.screenHeight / 2) - (height/2))+((i1*32)+50) ||
						mousex >= (x+360)+(i*32)+32 ||
						mousey >= (((gp.screenHeight / 2) - (height/2))+((i1*32)+50))+32) {
					g2.drawImage(inventoryrinsel, (x+360)+(i*32), ((gp.screenHeight / 2)- (height/2))+((i1*32)+50), 32, 32, null);
				}else {
					g2.drawImage(inventoryrsel, (x+360)+(i*32), ((gp.screenHeight / 2)- (height/2))+((i1*32)+50), 32, 32, null);
					if(gp.mouse_pressed) {
						if(gp.fullinventory[index] != null) {
							if(gp.keyH.zpressed) {
								gp.Player.itemhold = gp.fullinventory[index].type;
								if(gp.items.get(gp.Player.itemhold).maxstack > gp.Player.itemholdstack) {
									gp.Player.itemholdstack += 1;
									gp.fullinventory[index].stack -= 1;
								}
							}else {
								if(gp.Player.itemhold != 0) {
									if(gp.items.get(gp.fullinventory[index].type).maxstack > gp.fullinventory[index].stack) {
										gp.fullinventory[index].stack += 1;
										gp.Player.itemholdstack -= 1;
									}
									if(gp.Player.itemholdstack == 0) {
										gp.Player.itemhold = 0;
									}
								}else {
									gp.Player.itemhold = gp.fullinventory[index].type;
									if(gp.items.get(gp.Player.itemhold).maxstack > gp.Player.itemholdstack) {
										gp.Player.itemholdstack += 1;
										gp.fullinventory[index].stack -= 1;
									}
								}
							}
						}else {
							gp.fullinventory[index] = new Inventory();
							gp.fullinventory[index].type = gp.Player.itemhold;
							gp.fullinventory[index].stack = gp.Player.itemholdstack;
							gp.Player.itemhold = 0;
							gp.Player.itemholdstack = 0;
						}
					}
					if(gp.keyH.onepressed) {
						if(gp.fullinventory[index] == null) {
							if(gp.Player.Inventory[0] != 0) {
								gp.fullinventory[index] = new Inventory();
								gp.fullinventory[index].type = gp.Player.Inventory[0];
								gp.fullinventory[index].stack = gp.Player.inventorycount[0]+1;
								gp.Player.Inventory[0] = 0;
							}
						}else {
							if(gp.Player.Inventory[0] == 0) {
								gp.Player.Inventory[0] = gp.fullinventory[index].type;
								gp.Player.inventorycount[0] = 0;
								gp.fullinventory[index].stack -= 1;
							}
						}
					}
					if(gp.keyH.twopressed) {
						if(gp.fullinventory[index] == null) {
							if(gp.Player.Inventory[1] != 0) {
								gp.fullinventory[index] = new Inventory();
								gp.fullinventory[index].type = gp.Player.Inventory[1];
								gp.fullinventory[index].stack = gp.Player.inventorycount[1]+1;
								gp.Player.Inventory[1] = 0;
							}
						}else {
							if(gp.Player.Inventory[1] == 0) {
								gp.Player.Inventory[1] = gp.fullinventory[index].type;
								gp.Player.inventorycount[1] = 0;
								gp.fullinventory[index].stack -= 1;
							}
						}
					}
					if(gp.keyH.threepressed) {
						if(gp.fullinventory[index] == null) {
							if(gp.Player.Inventory[2] != 0) {
								gp.fullinventory[index] = new Inventory();
								gp.fullinventory[index].type = gp.Player.Inventory[2];
								gp.fullinventory[index].stack = gp.Player.inventorycount[2]+1;
								gp.Player.Inventory[2] = 0;
							}
						}else {
							if(gp.Player.Inventory[2] == 0) {
								gp.Player.Inventory[2] = gp.fullinventory[index].type;
								gp.Player.inventorycount[2] = 0;
								gp.fullinventory[index].stack -= 1;
							}
						}
					}
					if(gp.keyH.fourpressed) {
						if(gp.fullinventory[index] == null) {
							if(gp.Player.Inventory[3] != 0) {
								gp.fullinventory[index] = new Inventory();
								gp.fullinventory[index].type = gp.Player.Inventory[3];
								gp.fullinventory[index].stack = gp.Player.inventorycount[3]+1;
								gp.Player.Inventory[3] = 0;
							}
						}else {
							if(gp.Player.Inventory[3] == 0) {
								gp.Player.Inventory[3] = gp.fullinventory[index].type;
								gp.Player.inventorycount[3] = 0;
								gp.fullinventory[index].stack -= 1;
							}
						}
					}
					if(gp.keyH.fivepressed) {
						if(gp.fullinventory[index] == null) {
							if(gp.Player.Inventory[4] != 0) {
								gp.fullinventory[index] = new Inventory();
								gp.fullinventory[index].type = gp.Player.Inventory[4];
								gp.fullinventory[index].stack = gp.Player.inventorycount[4]+1;
								gp.Player.Inventory[4] = 0;
							}
						}else {
							if(gp.Player.Inventory[4] == 0) {
								gp.Player.Inventory[4] = gp.fullinventory[index].type;
								gp.Player.inventorycount[4] = 0;
								gp.fullinventory[index].stack -= 1;
							}
						}
					}
				}
				index += 1;
			}
		}
		int index2 = 0;
		for(int i = 0; i < 11; i++) {
			for(int i1 = 0; i1 < 15; i1++) {
				if(gp.fullinventory[index2] != null) {
					if(gp.fullinventory[index2].type != 0) {
						g2.drawImage(gp.items.get(gp.fullinventory[index2].type).img, (x+360)+(i*32), ((gp.screenHeight / 2)- (height/2))+((i1*32)+50), gp.items.get(gp.fullinventory[index2].type).width*32, gp.items.get(gp.fullinventory[index2].type).height*32, null);
						g2.setFont(arial_10);
						g2.drawString(String.valueOf(gp.fullinventory[index2].stack), ((x+360)+(i*32))+(18*gp.items.get(gp.fullinventory[index2].type).width), (((gp.screenHeight / 2)- (height/2))+((i1*32)+50))+32);
					}
				}
				index2 += 1;
			}
		}
		
		cr.makeCraft(g2, keyH, plr, x);
	}
	public void drawPauseScreen() {
		String text = "PAUSED";
		int x = getXforCenterText(text);
		int y = gp.screenHeight/2;
		g2.drawString("PAUSED",x,y);
	}
	public void drawDeadScreen() {
		String text = "YOU DEAD";
		int x = getXforCenterText(text);
		int y = gp.screenHeight/2;
		g2.drawString("YOU DEAD",x,y);
		g2.drawString("You Survived "+ gp.time + " seconds",getXforCenterText("You Survived "+ gp.time + " seconds"),(gp.screenHeight/2)+70);
	}
	public void drawThristCounter(player pla) {
		if(pla == null) {
			g2.drawString("Unknown", 50, 50);
		}else {
			g2.drawString("Thrist and Hunger:",5,35);
			g2.setStroke(new BasicStroke(6));
			g2.setColor(Color.WHITE);
			g2.drawRect(10, 40, 254, 38);
			g2.setColor(new Color(0,160,205));
			g2.fillRect(14, 42, (int)(gp.Player.thrist/(250/200)), 34);
			g2.setColor(Color.WHITE);
		}
	}
	void drawHungerCounter(player pla) {
		g2.setStroke(new BasicStroke(6));
		g2.setColor(Color.WHITE);
		g2.drawRect(10, 100, 254, 38);
		g2.setColor(Color.orange);
		g2.fillRect(14, 102, (int)(gp.Player.hunger/(250/200)), 34);
		g2.setColor(Color.WHITE);
	}
	void drawHealthCounter(player pla) {
		g2.drawString("Health:",470,35);
		g2.setStroke(new BasicStroke(6));
		g2.setColor(Color.WHITE);
		g2.drawRect(470, 40, 254, 38);
		g2.setColor(Color.RED);
		g2.fillRect(474, 42, (int)(gp.Player.health/(gp.Player.maxhealth/200)), 34);
		g2.setColor(Color.WHITE);
		
	}
	void drawtem(player pla) {
		try {
			if(pla.tem <= 0) {
				g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/tempur/tem0.png")), gp.screenWidth - 37, gp.screenHeight - 37, null);
			}
			else if(pla.tem >= 15) {
				g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/tempur/tem15.png")), gp.screenWidth - 37, gp.screenHeight - 37, null);
			}else {
				g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/tempur/tem"+pla.tem+".png")), gp.screenWidth - 37, gp.screenHeight - 37, null);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	void drawhotbar(player pla) {
		for(int i = 0; i < 5; i++) {
			if(pla.insel == i) {
				g2.drawImage(hotbarselImage, ((gp.screenWidth/2)-(52*(i*1))), gp.screenHeight - (50), 48, 48, null);
			}else {
				g2.drawImage(hotbarImage, ((gp.screenWidth/2)-(52*(i*1))), gp.screenHeight - (50), 48, 48, null);
			}
			int x = ((gp.screenWidth/2)-(52*(i*1)));
			int y = gp.screenHeight - (50);
			if(pla.Inventory[i] != 0) {
				g2.drawImage(gp.items.get(pla.Inventory[i]).img, ((gp.screenWidth/2)-(52*(i*1))), gp.screenHeight - (50), 48,48,null);
			}
		}
	}
	public void drawMenuScreen() {
		g2.setFont(arial_40);
		try {
			g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/menubackground.png")),0, 0, 800, 600, null);
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(gp.menuon == 0) {
			g2.setFont(arial_40);
			String text = "The Dersert Hunter";
			g2.drawString(text, getXforCenterText(text), 100);
			if(gp.menupick == 0) {
				g2.drawString(">Play", getXforCenterText("Play"), 200);
			}else {
				g2.drawString("Play", getXforCenterText("Play"), 200);
			}
			if(gp.menupick == 1) {
				g2.drawString(">Quit", getXforCenterText("Quit"), 230);
			}else {
				g2.drawString("Quit", getXforCenterText("Quit"), 230);
			}
			g2.setFont(arial_10);
			g2.drawString("By Hibro123GameDev, Github: hibroi23gamedev",getXforCenterText("By Hibro123GameDev, Github: hibroi23gamedev"), gp.screenHeight - 60);
			g2.setFont(arial_40);
		}else {
			if(gp.menuon == 1) {
				g2.drawString("Do you want multiplayer?", getXforCenterText("Do you want multiplayer?"), (gp.screenHeight/2) - 150);
				if(gp.menupick == 0) {
					g2.drawString(">Yes", getXforCenterText("Yes"), 200);
				}else {
					g2.drawString("Yes", getXforCenterText("Yes"), 200);
				}
				if(gp.menupick == 1) {
					g2.drawString(">No", getXforCenterText("No"), 230);
				}else {
					g2.drawString("No", getXforCenterText("No"), 230);
				}
			}else { 
				if(gp.menuon == 2) {
					g2.drawString("Do you want to be the", getXforCenterText("Do you want to be the"), (gp.screenHeight/2) - 150);
					int widthbox = 100;
					int heightbox = 100;
					if(gp.menupick == 0) {
						try {
							g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/select.png")), 100, gp.screenHeight/2, widthbox, heightbox, null);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}else {
						try {
							g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/unselect.png")), 100, gp.screenHeight/2, widthbox, heightbox, null);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					if(gp.menupick == 1) {
						try {
							g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/select.png")), 500, gp.screenHeight/2, widthbox, heightbox, null);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}else {
						try {
							g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/unselect.png")), 500, gp.screenHeight/2, widthbox, heightbox, null);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					g2.drawString("Host",100, gp.screenHeight/2);
					g2.drawString("Player",500, gp.screenHeight/2);
					g2.drawString("or",300, gp.screenHeight/2);
					try {
						g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/nonadminselect.png")), 500, gp.screenHeight/2, 100, 100, null);
						g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/adminselect.png")), 100, gp.screenHeight/2, 100, 100, null);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}else { 
					if(gp.menuon == 1) {
						g2.drawString("Do you want multiplayer?", getXforCenterText("Do you want multiplayer?"), (gp.screenHeight/2) - 150);
						if(gp.menupick == 0) {
							g2.drawString(">Yes", getXforCenterText("Yes"), 200);
						}else {
							g2.drawString("Yes", getXforCenterText("Yes"), 200);
						}
						if(gp.menupick == 1) {
							g2.drawString(">No", getXforCenterText("No"), 230);
						}else {
							g2.drawString("No", getXforCenterText("No"), 230);
						}
					}else { 
						if(gp.menuon == 2) {
							g2.drawString("Do you want to be the", getXforCenterText("Do you want to be the"), (gp.screenHeight/2) - 150);
							int widthbox = 100;
							int heightbox = 100;
							if(gp.menupick == 0) {
								try {
									g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/select.png")), 100, gp.screenHeight/2, widthbox, heightbox, null);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}else {
								try {
									g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/unselect.png")), 100, gp.screenHeight/2, widthbox, heightbox, null);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
							if(gp.menupick == 1) {
								try {
									g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/select.png")), 500, gp.screenHeight/2, widthbox, heightbox, null);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}else {
								try {
									g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/unselect.png")), 500, gp.screenHeight/2, widthbox, heightbox, null);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
							g2.drawString("Host",100, gp.screenHeight/2);
							g2.drawString("Player",500, gp.screenHeight/2);
							g2.drawString("or",300, gp.screenHeight/2);
							try {
								g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/nonadminselect.png")), 500, gp.screenHeight/2, 100, 100, null);
								g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/adminselect.png")), 100, gp.screenHeight/2, 100, 100, null);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}else { 
							if(gp.menuon == 3) {
								g2.drawString("What gamemode do you want?", getXforCenterText("What gamemode do you want?"), (gp.screenHeight/2) - 150);
								if(gp.menupick == 0) {
									g2.drawString(">Very Easy", getXforCenterText("Very Easy"), 200);
								}else {
									g2.drawString("Very Easy", getXforCenterText("Very Easy"), 200);
								}
								if(gp.menupick == 1) {
									g2.drawString(">Easy", getXforCenterText("Easy"), 230);
								}else {
									g2.drawString("Easy", getXforCenterText("Easy"), 230);
								}
								if(gp.menupick == 2) {
									g2.drawString(">Normal", getXforCenterText("Normal"), 260);
								}else {
									g2.drawString("Normal", getXforCenterText("Normal"), 260);
								}
								if(gp.menupick == 3) {
									g2.drawString(">Hard", getXforCenterText("Hard"), 290);
								}else {
									g2.drawString("Hard", getXforCenterText("Hard"), 290);
								}
								if(gp.menupick == 4) {
									g2.drawString(">Impossible", getXforCenterText("Impossible"), 320);
								}else {
									g2.drawString("Impossible", getXforCenterText("Impossible"), 320);
								}
							}else { 
								if(gp.menuon == 4) {
									String text = "Worlds";
									g2.setFont(arial_40);
									g2.drawString(text, getXforCenterText(text), 40);
									try {
										int i = 0;
										for(File file:gp.saves) {
											if(gp.menupick == i) {
												g2.drawString(">"+file.getName(), getXforCenterText(">"+file.getName()), (i*40)+70);
												if(gp.keyH.enterpressed) {
													gp.saveL.load("res/saves/my poop world.dat");
													gp.menuon = 1;
												}
												if(gp.keyH.xpressed) {
													file.delete();
												}
											}else {
												g2.drawString(file.getName(), getXforCenterText(file.getName()), (i*40)+70);
											}
											i++;
										}
										if(gp.keyH.zpressed && !enter_world_name) {
											enter_world_name = true;
											String worldname = JOptionPane.showInputDialog("Please Enter your world name!");
											FileWriter writer = new FileWriter("res/saves/"+worldname+".dat");
											writer.write(gp.obj.toString());
											writer.close();
											gp.aSetter.setObject();
											gp.saveL.save("res/saves/"+worldname+".dat");
											gp.keyH.zpressed = false;
											enter_world_name = false;
										}
									}catch(NullPointerException e) {
										String text2 = "Failed to load worlds, please restart the game or download it again";
										String text3 = "If you can't find your worlds, were very sorry!";
										g2.setFont(arial_10);
										g2.drawString(text2, getXforCenterText(text2), 120);
										g2.drawString(text3, getXforCenterText(text3), 140);
									} catch (IOException e) {
										
									}
								}
							}
					}
						}
				}
			}
		}
	}
	public int getXforCenterText(String text) {
		int length = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
		int x = gp.screenWidth/2 - length/2;
		return x;
	}
	public void drawSprayScreen() {
		int index = 0;
		int width = 32;
		int height = 32;
		for(int i = 0; i < gp.Player.spraywidth; i++) {
			for(int i1 = 0; i1 < gp.Player.sprayheight; i1++) {
				int xx = i*width;
				int yy = i1*height;
				int mousex = MouseInfo.getPointerInfo().getLocation().x - gp.frame.getLocation().x;
				int mousey = MouseInfo.getPointerInfo().getLocation().y - (gp.frame.getLocation().y + 30);
				if(mousex > xx-(width/2)) {
					if(mousex < xx+(width/2)) {
						if(mousey > yy+(height/2)) {
							if(mousey < yy-(height/2)) {
								gp.Player.sprayingcount = index;
							}
						}
					}
				}
				System.out.println("X: "+mousex+", Y: "+mousey);
				System.out.println("My X: "+xx+", My Y: "+yy);
				if(gp.Player.spraying[index] == 0) {
					try {
						g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/objects/spraycolors/extra/trasparent.png")),i*width,i1*height,width,height,null);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if(gp.Player.spraying[index] == 1) {
					try {
						g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/objects/spraycolors/white.png")),i*width,i1*height,width,height,null);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if(gp.Player.spraying[index] == 2) {
					try {
						g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/objects/spraycolors/black.png")),i*width,i1*height,width,height,null);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if(gp.Player.sprayingcount == index) {
					try {
						g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/objects/spraycolors/extra/select.png")),i*width,i1*height,width,height,null);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				index += 1;
			}
		}
	}
	
	public void drawmapscreen() {
		try {
			g2.drawImage(ImageIO.read(getClass().getResourceAsStream("/ui/blue.png")),0,0,gp.screenWidth,gp.screenHeight,null);
		} catch (IOException e) {
			e.printStackTrace();
		}
		int reali = 0;
		for(int i = 0; i < gp.worlds.length; i++, reali++) {
			if(i == 1) {
				i = 2;
			}
			if(gp.worlds[i] != null) {
				int width = 128;
				int height = 128;
				int x = (gp.screenWidth/2)+(reali*width);
				int y = gp.screenHeight/2;
				if(gp.mapselect == i) {
					BufferedImage img = gp.utool.brighten(gp.worlds[i].image, 20);
					g2.drawImage(img,x,y,width,height,null);
				}else {
					g2.drawImage(gp.worlds[i].image,x,y,width,height,null);
				}
				g2.drawString(gp.worlds[i].name,x,y);
			}
		}
	}
	public void makeTutorial() {
		makepienetut("Hello, Welcome!", 3, 0);
		makepienetut("Today I will show you how to play my game!", 6, 1);
		makepienetut("So you probably know that you move with WASD,", 8, 2);
		makepienetut("and you know that this is a game where you explore in the Dersert.", 12, 3);
		makepienetut("So start with finding some rocks, that you click z to do,", 9, 4);
		makepienetut("and once you have done that, you find some sand!", 6, 5);
		makepienetut("now to place the rock down, you select it using the number keys,", 12, 6);
		makepienetut("then click V to use it, then it should make it a pan!", 9, 7);
		makepienetut("then while walking, you should be going on the pan,", 6, 8);
		makepienetut("then clicking V to put the sand on,", 5, 9);
		makepienetut("then now just wait for a few secs!", 5, 10);
		makepienetut("After, while walking, stand on the pan, then press V.", 9, 11);
		makepienetut("You should have a emtry bottle!", 4, 12);
		makepienetut("Now go to a pool, and then while walking and being next to it,", 12, 13);
		makepienetut("Press V, now you have a dirty water bottle!", 9, 14);
		makepienetut("Then, grab some sand and rocks and press E", 8, 15);
		makepienetut("Now with the up and down arrow keys,", 7, 16);
		makepienetut("select the Water pre thing(it should cost sand and rock),", 12, 17);
		makepienetut("then craft the water pre by pressing enter!", 7, 18);
		makepienetut("Now use the water pre then grab your dirty water bottle and go on it.", 15, 19);
		makepienetut("Now wait, then while walking, press V while going on the water pre.", 15, 20);
		makepienetut("Now you should have a water bottle, Press X to drink it!", 10, 21);
		makepienetut("Now you know about water, you got to know about hunger!", 8, 22);
		makepienetut("So grab some grass from the sand, then craft some wheat,", 8, 23);
		makepienetut("then grab more grass, then craft more wheat, then craft bread.", 9, 24);
	}
	public void makepienetut(String text, int time, int index) {
		tutorial[index] = new TutorialSpeech();
		tutorial[index].Speech = text;
		tutorial[index].time = (time*5);
	}
	public void drawandhandletut() {
		if(tutorial[tuton] != null)  {
			System.out.println(tutcounter);
			tutcounter += 1;
			if(tutcounter > tutorial[tuton].time) {
				tuton += 1;
				tutcounter = 0;
			}
			g2.setFont(arial_10);
			g2.drawString(tutorial[tuton].Speech, getXforCenterText(tutorial[tuton].Speech), 140);
		}
	}
}
