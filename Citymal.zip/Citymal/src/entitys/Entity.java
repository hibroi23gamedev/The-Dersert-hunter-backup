package entitys;

import models.TexturedModel;
import render.Loader;
import render.MasterRenderer;
import render.ModelData;

import java.util.ArrayList;

import org.lwjgl.util.vector.Vector3f;
import terrains.Terrain;

public class Entity {
   public TexturedModel model;
   protected Vector3f position;
   
   private Vector3f[] positions_for_string;
   
   public float rotX;
   public float rotY;
   public float rotZ;
   protected float scale;
   protected float speedy;
   protected float speedx;
   protected float speedz;
   protected short phy_counter;
   
   float oldterrainheight = 0.0F;
   float oldx;
   float oldz;
   
   public boolean phy = true;

   public Entity(TexturedModel model, Vector3f position, float rotX, float rotY, float rotZ, float scale) {
      this.model = model;
      this.position = position;
      this.rotX = rotX;
      this.rotY = rotY;
      this.rotZ = rotZ;
      this.scale = scale;
      setStringPositions(100);
   }
   
   public void setStringPositions(int length) {
	   positions_for_string = new Vector3f[length];
	   positions_for_string[0] = null;
   }

   public void increasePosition(float dx, float dy, float dz) {
      Vector3f var10000 = this.position;
      var10000.x += dx;
      var10000 = this.position;
      var10000.y += dy;
      var10000 = this.position;
      var10000.z += dz;
   }

   public void increaseRotation(float dx, float dy, float dz) {
      this.rotX += dx;
      this.rotY += dy;
      this.rotZ += dz;
   }

   public TexturedModel getModel() {
      return this.model;
   }

   public void setModel(TexturedModel model) {
      this.model = model;
   }

   public Vector3f getPosition() {
      return this.position;
   }

   public void setPosition(Vector3f position) {
      this.position = position;
   }

   public float getRotX() {
      return this.rotX;
   }

   public void setRotX(float rotX) {
      this.rotX = rotX;
   }

   public float getRotY() {
      return this.rotY;
   }

   public void setRotY(float rotY) {
      this.rotY = rotY;
   }

   public float getRotZ() {
      return this.rotZ;
   }

   public void setRotZ(float rotZ) {
      this.rotZ = rotZ;
   }

   public float getScale() {
      return this.scale;
   }

   public void setScale(float scale) {
      this.scale = scale;
   }
}
