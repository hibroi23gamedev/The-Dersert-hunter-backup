package engineTester;

import audio.AudioMaster;
import audio.Source;
import buildings.Building_Type;
import buildings.House;
import buildings.Market;
import entitys.*;
import extra.*;
import fontMeshCreator.FontType;
import fontMeshCreator.GUIText;
import fontRendering.TextMaster;
import guis.GuiButton;
import guis.GuiRenderer;
import guis.GuiTexture;
import items.Item;
import items.ItemPro;
import items.SuperItem;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import models.RawModel;
import models.TexturedModel;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.openal.AL10;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import particles.ParticleMaster;
import postProcessing.Fbo;
import postProcessing.PostProcessing;
import render.DisplayManager;
import render.Loader;
import render.MasterRenderer;
import render.ModelData;
import render.OBJFileLoader;
import terrains.Terrain;
import textures.ModelTexture;
import textures.TerrainTexture;
import textures.TerrainTexturePack;
import toolbox.*;
import people.*;

public class MainGameLoop {
	public static int tileSize = 128;
	public static Road[][] tiles = new Road[tileSize][tileSize];
	public static ArrayList<Building> buildings = new ArrayList<Building>();
	public static int terrainSize;
	
	public static int sun_Posy;
	
	public static ArrayList<Entity> entities = new ArrayList();
	public static Light light = new Light(new Vector3f(1000000.0F, 1500000.0F, -1000000.0F), new Vector3f(1.0F, 1.0F, 1.0F));
	public static boolean blood_moon = false;
	static boolean shadows = true;
	public static List<GuiTexture> guis = new ArrayList();
	
	public static ArrayList<Person> people = new ArrayList<Person>();
	
	public static int placment = 0;

	public static void main(String[] args) {
	  terrainSize = 800;
	  
      AudioMaster.init();
      AudioMaster.setListenerData(0.0F, 0.0F, 0.0F);
      AL10.alDistanceModel(53252);
      int buffer = AudioMaster.loadSound("audio/bounce.wav");
      Source source = new Source();
      source.setLooping(true);
      //source.play(buffer);
      source.setPosition(0.0F, 0.0F, 0.0F);
      DisplayManager.createDisplay();
      ArrayList<Entity> floor = new ArrayList();
      new ArrayList();
      List<Light> lights = new ArrayList();
      Loader loader = new Loader();
      
      ModelTexture nownedt = new ModelTexture(loader.loadTexture("not_owned"));
      
      Random random = new Random();
      TileManager.init(loader);
	  for(int i = 0; i < tileSize; i++) {
		  for(int i1 = 0; i1 < tileSize; i1++) {
			  tiles[i][i1] = new Road(0);
		  }
	  }
	  tiles[5][5] = new Road(1);
	  tiles[6][5] = new Road(1);
	  tiles[7][5] = new Road(1);
	  tiles[8][5] = new Road(1);
	  tiles[9][5] = new Road(1);
	  
	  tiles[9][6] = new Road(1);
	  tiles[9][7] = new Road(1);
	  tiles[9][8] = new Road(1);
	  tiles[9][9] = new Road(1);
	  tiles[9][10] = new Road(1);
      
      TextMaster.init(loader);
      ModelData data = OBJFileLoader.loadOBJ("grass06");
      RawModel model = loader.loadtoVAO(data.getVertices(), data.getTextureCoords(), data.getNormals(), data.getIndices(), data);
      ModelTexture texture = new ModelTexture(loader.loadTexture("grassTexture"));
      TerrainTexture backtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backrtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backgtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backbtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexturePack texturepack = new TerrainTexturePack(backtexture, backrtexture, backgtexture, backbtexture);
      TerrainTexture blendMap = new TerrainTexture(loader.loadTexture("blend_map"));
      texture.setHasTransparency(true);
      texture.setShineDamper(10.0F);
      texture.setRfi(0.0F);
      texture.setUseFakeLighting(true);
      FontType font = new FontType(loader.loadTexture("segoe"), new File("res/segoe.fnt"));
      //new GUIText("HELLO", 1.0F, font, new Vector2f(0.2F, 0.2F), 0.2F, true);
      ModelData data2 = OBJFileLoader.loadOBJ("fern");
      RawModel model2 = loader.loadtoVAO(data2.getVertices(), data2.getTextureCoords(), data2.getNormals(), data2.getIndices(), data2);
      ModelTexture texture2 = new ModelTexture(loader.loadTexture("fern"));
      texture.setHasTransparency(true);
      texture.setShineDamper(10.0F);
      texture.setRfi(0.0F);
      texture.setUseFakeLighting(true);
      GuiRenderer guiRenderer = new GuiRenderer(loader);
      TexturedModel texturedModel = new TexturedModel(model, texture);
      TexturedModel texturedfern = new TexturedModel(model2, texture2);
      lights.add(light);
      Terrain terrain = new Terrain(0, 0, loader, texturepack, blendMap, "heightmap");
      Camera camera = new Camera();
      MasterRenderer renderer = new MasterRenderer(texture2, loader, camera);
      
      new House(loader);
      new Market(loader);
      
      buildings.add(new Building(new Market(loader), (int)6, (int)6));
      
      
      ModelData persondata = OBJFileLoader.loadOBJ("person");
      RawModel personrawmodel = loader.loadtoVAO(persondata.getVertices(), persondata.getTextureCoords(), persondata.getNormals(), persondata.getIndices(), 
    		  persondata);
      ModelTexture persontexture = new ModelTexture(loader.loadTexture("placement_texture"));
      TexturedModel personmodel = new TexturedModel(personrawmodel, persontexture);
      if(random.nextInt(30) == 0) {
    	  for(int i = 0; i < 6; i++) {
        	  Person person = new Person();
              person.model = personmodel;
              int x = random.nextInt(tileSize);
              int z = random.nextInt(tileSize);
              while(tiles[x][z].type == 0) {
            	  x = random.nextInt(tileSize);
            	  z = random.nextInt(tileSize);
              }
              person.x = x*8;
              person.z = z*8;
        	  people.add(person);
          }
      }
      
      
      for(int i = 0; i < random.nextInt(340) + 1500; ++i) {
         Random random2 = new Random();
         Random random3 = new Random();
         Random random4 = new Random();
         int x = random2.nextInt(800) + 0;
         int z = random3.nextInt(800) + 0;
         if (random4.nextInt(4) == 0) {
            floor.add(new Entity(texturedfern, new Vector3f((float)x, terrain.getHeightOfTerrain((float)x, (float)z), (float)z), 0.0F, 180.0F, 0.5F, 0.3F));
         } else {
            floor.add(new Entity(texturedModel, new Vector3f((float)x, terrain.getHeightOfTerrain((float)x, (float)z) + 0.7F, (float)z), 180.0F, 180.0F, 0.0F, 0.9F));
         }
      }

      Fbo multisampleFbo = new Fbo(Display.getWidth(), Display.getHeight(), 2);
      new Fbo(Display.getWidth(), Display.getHeight(), 1);
      PostProcessing.init(loader);
      
      Entity test = new Entity(texturedfern, new Vector3f(8, 0, 16), 0.0F, 180.0F, 0.5F, 0.3F);
      MousePicker picker = new MousePicker(camera, renderer.getProjectionMatrix(), terrain);
      while(!Display.isCloseRequested()) {
    	 //GAME LOGIC
    	 picker.update();
    	 MouseRay.findmousepos(camera, terrain);
    	 if(picker.getCurrentTerrainPoint() != null) {
    		 test.setPosition(picker.getCurrentTerrainPoint());
    	 }
    	 //test.setPosition(MouseRay.getMousepos());
    	 if(Keyboard.isKeyDown(Keyboard.KEY_F)) {
    		 placment = 0;
    	 }
    	 if(Keyboard.isKeyDown(Keyboard.KEY_G)) {
    		 placment = 1;
    	 }
    	 if(Mouse.isButtonDown(0) && placment == 0) {
    		 Vector2f pos = TileManager.findtilexy(test.getPosition().x, test.getPosition().z);
        	 if(pos.y > 0 && pos.x > 0) {
        		 tiles[(int) pos.x][(int) pos.y] = new Road(1);
        	 }
    	 }
    	 if(random.nextInt(30) == 0) {
    		 for(int i = 0; i < 1; i++) {
    	       	  	Person person = new Person();
    	             person.model = personmodel;
    	             int x = random.nextInt(tileSize);
    	             int z = random.nextInt(tileSize);
    	             while(tiles[x][z].type == 0) {
    	           	  x = random.nextInt(tileSize);
    	           	  z = random.nextInt(tileSize);
    	             }
    	             person.x = x*8;
    	             person.z = z*8;
    	       	  	people.add(person);
    	         }
    	 }
    	 if(Mouse.isButtonDown(0) && placment == 1) {
    		 Vector2f pos = TileManager.findtilexy(test.getPosition().x, test.getPosition().z);
    		 
    		 boolean tbuilding = true;
    		 
    		 for(int i = 0; i < buildings.size(); i++) {
    			 if(buildings.get(i).x == pos.x && buildings.get(i).y == pos.y) {
    				 tbuilding = false;
    			 }
    		 }
    		 
        	 if(pos.y > 0 && pos.x > 0 && tiles[(int)(pos.x)][(int)(pos.y)].type == 0 && tbuilding) {
        		 buildings.add(new Building(new House(loader), (int)pos.x, (int)pos.y));
        	 }
    	 }
    	 
    	 Vector2f pos = TileManager.findtilexy(test.getPosition().x, test.getPosition().z);
    	 if(pos.y > 0 && pos.x > 0) {
    		 if(tiles[(int) pos.x][(int) pos.y].type == 0) {
    			 tiles[(int) pos.x][(int) pos.y] = new Road(1);
        		 tiles[(int) pos.x][(int) pos.y].placing = true;
    		 }
    	 }
    	 
    	 camera.move();
    	 //RENDER
         guis.clear();
         if (shadows) {
            entities.clear();
            for(int i = 0; i < floor.size(); i++) {
            	entities.add(floor.get(i));
            }
            
            for(int i = 0; i < buildings.size(); i++) {
            	int dir = 0;
            	int bx = buildings.get(i).x;
           	 	int by = buildings.get(i).y;
           	 	if(tiles[bx+1][by].type == 1) {
           	 		dir = 0;
           	 	}if(tiles[bx-1][by].type == 1) {
           	 		dir = 180;
           	 	}if(tiles[bx][by+1].type == 1) {
           	 		dir = 270;
           	 	}if(tiles[bx][by-1].type == 1) {
           	 		dir = 90;
           	 	}
            	entities.add(new Entity(House.model, new Vector3f(buildings.get(i).x * 8, 0, buildings.get(i).y * 8), 0, dir, 0, 1));
            }
         }
         renderer.renderShadowMap(entities, light);
         for(int i = 0; i < buildings.size(); i++) {
        	 int dir = 0;
        	 int bx = buildings.get(i).x;
        	 int by = buildings.get(i).y;
        	 if(tiles[bx+1][by].type == 1) {
        		 dir = 0;
        	 }if(tiles[bx-1][by].type == 1) {
        		 dir = 180;
        	 }if(tiles[bx][by+1].type == 1) {
        		 dir = 270;
        	 }if(tiles[bx][by-1].type == 1) {
        		 dir = 90;
        	 }
        	 
        	 TexturedModel buildingt = BuildingManager.getModelfromType(buildings.get(i).type.id);
        	 
        	 //if(!buildings.get(i).owned) {
        	//	 //buildingt.texture = nownedt;
        	 //}else {
        	//	 buildingt.texture = BuildingManager.getTexturefromType(buildings.get(i).type.id);
        	 //}
        	 
        	 Entity building = new Entity(buildingt, new Vector3f(buildings.get(i).x * 8, 0, buildings.get(i).y * 8), 0, dir, 0, 1);
        	 
             renderer.processEntity(building);
         }
         
         if(Keyboard.isKeyDown(Keyboard.KEY_H)) {
        	 if(picker.getCurrentTerrainPoint() != null) {
        		 people.get(0).x = picker.getCurrentTerrainPoint().x;
        		 people.get(0).z = picker.getCurrentTerrainPoint().z;
        		 
        		 if(buildings.size() > 1) {
        			 int x = random.nextInt(128);
        			 int y = random.nextInt(128);
        			 while(tiles[x][y].type == 0) {
        				 x = random.nextInt(128);
            			 y = random.nextInt(128);
        			 }
        			 people.get(0).setTarget(x, y);
        		 }
        	 }
         }
         
         for(int i = 0; i < people.size(); i++) {
        	 people.get(i).update();
             
             renderer.processEntity(new Entity(people.get(i).model, new Vector3f(people.get(i).x, 0, people.get(i).z), 0, 0, 0, 1));
         }
         
         for(int i = 0; i < tileSize; i++) {
        	 for(int i1 = 0; i1 < tileSize; i1++) {
        		 if(tiles[i][i1].model != null) {
        			 TexturedModel tile_model = tiles[i][i1].model;
        			 int dir = 0;
        			 if(i1 > 0) {
        				 if(tiles[i][i1-1].type == 1) {
        					 if(i > 0 && i < tileSize) {
        						 if(tiles[i+1][i1].type != 1 && tiles[i-1][i1].type != 1) {
        							 dir = 90;
        						 }else {
        							 dir = 180;
        							 if(tiles[i + 1][i1].type == 1) {
        								 dir = 180;
        								 tile_model = tiles[i][i1].exinmodel;
        							 }else if(tiles[i - 1][i1].type == 1){
        								 dir = 180;
        								 tile_model = tiles[i][i1].exmodel;
        							 }else {
        								 tile_model = tiles[i][i1].exmodel;
        							 }
        						 }
        					 }
        				 }
        			 }
        			 if(i1 < tileSize) {
        				 if(tiles[i][i1+1].type == 1) {
        					 if(i < tileSize && i > 0) {
        						 if(tiles[i+1][i1].type != 1 && tiles[i-1][i1].type != 1) {
        							 dir = 90;
        						 }else {
        							 dir = 180;
        							 if(tiles[i + 1][i1].type == 1) {
        								 dir = 0;
        								 tile_model = tiles[i][i1].exmodel;
        							 }else if(tiles[i - 1][i1].type == 1){
        								 dir = 270;
        								 tile_model = tiles[i][i1].exmodel;
        							 }else {
        								 tile_model = tiles[i][i1].exmodel;
        							 }
        						 }
        					 }
        				 }
        			 }
        			 if(tiles[i][i1+1].type == 1 && tiles[i][i1-1].type == 1 && tiles[i - 1][i1].type == 1) {
        				 tile_model = tiles[i][i1].extmodel;
        				 dir = 90;
        			 }
        			 if(tiles[i][i1+1].type == 1 && tiles[i][i1-1].type == 1 && tiles[i+1][i1].type == 1) {
        				 tile_model = tiles[i][i1].extmodel;
        				 dir = 270;
        			 }
        			 if(tiles[i+1][i1].type == 1 && tiles[i-1][i1].type == 1 && tiles[i][i1+1].type == 1) {
        				 tile_model = tiles[i][i1].extmodel;
        				 dir = 180;
        			 }
        			 if(tiles[i+1][i1].type == 1 && tiles[i-1][i1].type == 1 && tiles[i][i1-1].type == 1) {
        				 tile_model = tiles[i][i1].extmodel;
        				 dir = 0;
        			 }
        			 
        			 if(tiles[i+1][i1].type == 1 && tiles[i-1][i1].type == 1 && tiles[i][i1-1].type == 1 && tiles[i][i1+1].type == 1) {
        				 tile_model = tiles[i][i1].exomodel;
        				 dir = 0;
        			 }
        			 //tile_model = tiles[i][i1].exomodel;
        			 renderer.processEntity(new Entity(tile_model, new Vector3f(i*8, 0, i1*8), 0, dir, 0, 1));
        			 if(tiles[i][i1].placing) {
        				 tiles[i][i1] = new Road(0);
        			 }
        		 }
        	 }
         }
         
         
         
         for(int i = 0; i < floor.size(); ++i) {
            renderer.processEntity((Entity)floor.get(i));
         }
         renderer.processEntity(test);
         renderer.processTerrain(terrain);
         
         multisampleFbo.bindFrameBuffer();
         renderer.render(lights, camera);
         multisampleFbo.unbindFrameBuffer();
         PostProcessing.doPostProcessing(multisampleFbo.getColourTexture());
         guiRenderer.render(guis);
         TextMaster.render();
         DisplayManager.updateDisplay();
      }

      multisampleFbo.cleanUp();
      guiRenderer.cleanUp();
      renderer.cleanUp();
      loader.cleanUp();
      TextMaster.cleanUp();
      PostProcessing.cleanUp();
      source.delete();
      AudioMaster.cleanUp();
      DisplayManager.closeDisplay();
   }

   public static Vector2f mousePosition() {
      float mx = 2.0F * (float)Mouse.getX() / (float)Display.getWidth() - 1.0F;
      float my = 2.0F * (float)Mouse.getY() / (float)Display.getHeight() - 1.0F;
      return new Vector2f(mx, my);
   }

   public static boolean isInRange(Vector3f position1, Vector3f position2, float rangex, float rangey, float rangez) {
      return position1.x - rangex < position2.x && position1.x + rangex > position2.x && position1.z - rangez < position2.z && position1.z + rangez > position2.z && position1.y - rangey < position2.y && position1.y + rangey > position2.y;
   }
}