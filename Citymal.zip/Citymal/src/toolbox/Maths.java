package toolbox;

import entitys.Camera;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

public class Maths {
   public static Matrix4f createTransformationMatrix(Vector2f translation, Vector2f scale) {
      Matrix4f matrix = new Matrix4f();
      matrix.setIdentity();
      Matrix4f.translate(translation, matrix, matrix);
      Matrix4f.scale(new Vector3f(scale.x, scale.y, 1.0F), matrix, matrix);
      return matrix;
   }

   public static float barryCentric(Vector3f p1, Vector3f p2, Vector3f p3, Vector2f pos) {
      float det = (p2.z - p3.z) * (p1.x - p3.x) + (p3.x - p2.x) * (p1.z - p3.z);
      float l1 = ((p2.z - p3.z) * (pos.x - p3.x) + (p3.x - p2.x) * (pos.y - p3.z)) / det;
      float l2 = ((p3.z - p1.z) * (pos.x - p3.x) + (p1.x - p3.x) * (pos.y - p3.z)) / det;
      float l3 = 1.0F - l1 - l2;
      return l1 * p1.y + l2 * p2.y + l3 * p3.y;
   }

   public static Matrix4f createTransformation(Vector3f translation, float rx, float ry, float rz, float scale) {
      Matrix4f matrix = new Matrix4f();
      matrix.setIdentity();
      Matrix4f.translate(translation, matrix, matrix);
      Matrix4f.rotate((float)Math.toRadians((double)rx), new Vector3f(1.0F, 0.0F, 0.0F), matrix, matrix);
      Matrix4f.rotate((float)Math.toRadians((double)ry), new Vector3f(0.0F, 1.0F, 0.0F), matrix, matrix);
      Matrix4f.rotate((float)Math.toRadians((double)rz), new Vector3f(0.0F, 0.0F, 1.0F), matrix, matrix);
      Matrix4f.scale(new Vector3f(scale, scale, scale), matrix, matrix);
      return matrix;
   }

   public static Matrix4f createView(Camera c) {
      Matrix4f viewmatrix = new Matrix4f();
      viewmatrix.setIdentity();
      viewmatrix.rotate((float)Math.toRadians((double)c.getPitch()), new Vector3f(1.0F, 0.0F, 0.0F), viewmatrix);
      viewmatrix.rotate((float)Math.toRadians((double)c.getYaw()), new Vector3f(0.0F, 1.0F, 0.0F), viewmatrix);
      viewmatrix.rotate((float)Math.toRadians((double)c.getRoll()), new Vector3f(0.0F, 0.0F, 1.0F), viewmatrix);
      Vector3f camerapos = c.getPosition();
      Vector3f ncamerapos = new Vector3f(-camerapos.x, -camerapos.y, -camerapos.z);
      Matrix4f.translate(ncamerapos, viewmatrix, viewmatrix);
      return viewmatrix;
   }
}
