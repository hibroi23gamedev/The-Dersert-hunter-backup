package building_cs;

public abstract class Building_Componment {
	public Building_Componment() {
		
	}
	public abstract void update();
}
