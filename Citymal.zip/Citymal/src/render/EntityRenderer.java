package render;

import entitys.Entity;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import models.RawModel;
import models.TexturedModel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Matrix4f;
import shaders.StaticShader;
import textures.ModelTexture;
import toolbox.Maths;

public class EntityRenderer {
   private StaticShader shader;

   public EntityRenderer(StaticShader shader, Matrix4f projectionMatrix) {
      this.shader = shader;
      shader.start();
      shader.loadProjectionMatrix(projectionMatrix);
      shader.stop();
   }

   public void render(Map<TexturedModel, List<Entity>> entites) {
      Iterator var3 = entites.keySet().iterator();

      while(var3.hasNext()) {
         TexturedModel model = (TexturedModel)var3.next();
         this.prepareTexturedModel(model);
         List<Entity> batch = (List)entites.get(model);
         Iterator var6 = batch.iterator();

         while(var6.hasNext()) {
            Entity entity = (Entity)var6.next();
            this.prepareInstance(entity);
            GL11.glDrawElements(4, model.getModel().getVertexCount(), 5125, 0L);
         }

         this.unbindTexturedModel();
      }

   }

   private void prepareTexturedModel(TexturedModel model) {
      RawModel rmodel = model.getModel();
      GL30.glBindVertexArray(rmodel.getVaoID());
      GL20.glEnableVertexAttribArray(0);
      GL20.glEnableVertexAttribArray(1);
      GL20.glEnableVertexAttribArray(2);
      ModelTexture texture = model.getTexture();
      if (texture.isHasTransparency()) {
         MasterRenderer.disableCulling();
      }

      this.shader.loadFakeLightingVarible(texture.isUseFakeLighting());
      this.shader.loadShineVarables(texture.getShineDamper(), texture.getRfi());
      GL13.glActiveTexture(33984);
      GL11.glBindTexture(3553, model.getTexture().getID());
   }

   private void unbindTexturedModel() {
      MasterRenderer.enableCulling();
      GL20.glDisableVertexAttribArray(0);
      GL20.glDisableVertexAttribArray(1);
      GL20.glDisableVertexAttribArray(2);
      GL30.glBindVertexArray(0);
   }

   private void prepareInstance(Entity entity) {
      Matrix4f transformationMatrix = Maths.createTransformation(entity.getPosition(), entity.getRotX(), entity.getRotY(), entity.getRotZ(), entity.getScale());
      this.shader.loadTransformationMatrix(transformationMatrix);
   }
}
