package me.thepoitionhunter.extra;
import java.awt.image.BufferedImage;

import me.thepotionhunter.objects.*;

public class SuperWorld {
	public String name;
	public int id;
	public BufferedImage image;
	
	public SuperObect[] obj = new SuperObect[1000];
}
