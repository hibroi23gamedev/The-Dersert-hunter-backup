package draw;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import main.GamePanel;

public class Rectangle {
	public Color c;
	public int x;
	public int y;
	public int width;
	public int height;
	public int direction;
	public Rectangle(Color c, int x, int y, int width, int height) {
		this.c = c;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	public void draw(Graphics g) {
		if(direction > 360) {
			direction = 0;
		}
		Graphics2D g2 = (Graphics2D)g;
		g2.setColor(c);
		for(int i = -(width); i < width; i++) {
			for(int i1 = -(height); i1 < height; i1++) {
				int x = this.x + (int)((i*Math.sin(Math.toRadians(direction)))
						-(i1*Math.cos(Math.toRadians(direction))));
				int y = this.y + (int)((i1*Math.sin(Math.toRadians(direction)))
						+(i*Math.cos(Math.toRadians(direction))));
				g2.drawLine(x - GamePanel.camX, y - GamePanel.camY, (x+1) - GamePanel.camX, (y+1) - GamePanel.camY);
			}
		}
	}
}