package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_PREWATERGOOD extends SuperObect{
	GamePanel gp;
	public OBJ_PREWATERGOOD(GamePanel gp) {
		this.gp = gp;
		name = "prewatergood";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/prewatergood.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = false;
	}
}
