package shaders;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.FloatBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL20;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

public abstract class ShaderProgram {
   private int programID;
   private int vertexShaderID;
   private int fragmentShaderID;
   private static FloatBuffer matrixBuffer = BufferUtils.createFloatBuffer(16);

   public ShaderProgram(String vertexFile, String fragmentFile) {
      this.vertexShaderID = loadShader(vertexFile, 35633);
      this.fragmentShaderID = loadShader(fragmentFile, 35632);
      this.programID = GL20.glCreateProgram();
      GL20.glAttachShader(this.programID, this.vertexShaderID);
      GL20.glAttachShader(this.programID, this.fragmentShaderID);
      this.bindATTR();
      GL20.glLinkProgram(this.programID);
      GL20.glValidateProgram(this.programID);
      this.getAllUniformLocations();
   }

   protected abstract void getAllUniformLocations();

   protected int getUniformLocation(String uniformName) {
      return GL20.glGetUniformLocation(this.programID, (CharSequence)uniformName);
   }

   public void start() {
      GL20.glUseProgram(this.programID);
   }

   public void stop() {
      GL20.glUseProgram(0);
   }

   public void cleanUp() {
      this.stop();
      GL20.glDetachShader(this.programID, this.vertexShaderID);
      GL20.glDetachShader(this.programID, this.fragmentShaderID);
      GL20.glDeleteShader(this.vertexShaderID);
      GL20.glDeleteShader(this.fragmentShaderID);
      GL20.glDeleteProgram(this.programID);
   }

   protected void bindATTR(int ATTR, String var) {
      GL20.glBindAttribLocation(this.programID, ATTR, (CharSequence)var);
   }

   protected void loadMatrix(int location, Matrix4f matrix) {
      matrix.store(matrixBuffer);
      matrixBuffer.flip();
      GL20.glUniformMatrix4(location, false, matrixBuffer);
   }

   protected void loadBoolean(int location, boolean value) {
      float toLoad = 0.0F;
      if (value) {
         toLoad = 1.0F;
      }

      GL20.glUniform1f(location, toLoad);
   }

   protected void loadFloat(int location, float value) {
      GL20.glUniform1f(location, value);
   }

   protected void loadInt(int location, int value) {
      GL20.glUniform1i(location, value);
   }

   protected void loadVector(int location, Vector3f vector) {
      GL20.glUniform3f(location, vector.x, vector.y, vector.z);
   }

   protected abstract void bindATTR();

   private static int loadShader(String file, int type) {
      StringBuilder shaderSource = new StringBuilder();

      try {
         //InputStream input = Class.class.getResourceAsStream(file);
         BufferedReader reader = new BufferedReader(new FileReader("src"+file));

         String line;
         while((line = reader.readLine()) != null) {
            shaderSource.append(line).append("\n");
         }

         reader.close();
      } catch (IOException var6) {
         var6.printStackTrace();
         System.err.println("Could not read file!");
         System.exit(-1);
      }

      int shaderID = GL20.glCreateShader(type);
      GL20.glShaderSource(shaderID, (CharSequence)shaderSource);
      GL20.glCompileShader(shaderID);
      if (GL20.glGetShader(shaderID, 35713) == 0) {
         System.out.println(GL20.glGetShaderInfoLog(shaderID, 500));
         System.err.println("Could not compile shader, sadly, if I kept the game running, then there will be no shaders, no colors, no textures.");
         System.exit(-1);
      }

      return shaderID;
   }

   public void load2DVector(int location, Vector2f vector) {
      GL20.glUniform2f(location, vector.x, vector.y);
   }
}
