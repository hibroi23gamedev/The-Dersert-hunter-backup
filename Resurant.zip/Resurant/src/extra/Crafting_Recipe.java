package extra;

public class Crafting_Recipe {
   public int[] recipe;
   public int crafted;
}
