package placing;

public class Placing {
	public String name;
	public int type;
	public int artype;
}
