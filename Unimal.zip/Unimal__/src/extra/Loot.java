package extra;

import java.util.ArrayList;
import java.util.Random;

import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Vector2f;

import engineTester.MainGameLoop;
import guis.*;

public class Loot {
	public ArrayList<Integer> ids = new ArrayList<Integer>();
	public ArrayList<Integer> counts = new ArrayList<Integer>();
	
	public String title;
	
	public Loot(String title, boolean is_random_loot, ArrayList<ItemGroup> itemgroups) {
		if(is_random_loot) {
			for(int i = 0; i < itemgroups.size(); i++) {
				boolean is_found = false;
				for(int i1 = 0; i1 < itemgroups.get(i).items.size(); i1++) {
					Random random = new Random();
					if(random.nextInt(100/itemgroups.get(i).items.get(i1).rarity) == 0) {
						addItem(itemgroups.get(i).items.get(i1).id, itemgroups.get(i).items.get(i1).count);
						is_found = true;
						break;
					}
				}
				if(!is_found) {
					addItem(itemgroups.get(i).items.get(itemgroups.get(i).items.size()-1).id, itemgroups.get(i).items.get(itemgroups.get(i).items.size()-1).count);
				}
			}
		}
		this.title = title;
	}
	public void addItem(int id, int count) {
		ids.add(id);
		counts.add(count);
	}
	public void printallitems() {
		float ind = 0;
		float indy = 0;
		for(int i = 0; i < ids.size(); i++) {
			
			if(i + 1 > ids.size()) {
				return;
			}
			if(ids.get(i) != -1) {
				boolean remove = false;
				try {
					float x = -0.65f + (ind);
					float y = 0.15f + (indy);
					float sx = 0.07f;
					float sy = 0.13f;
					Vector2f mousepos = MainGameLoop.mousePosition();
					GuiTexture slot = new GuiTexture(MainGameLoop.itemmanager.items.get(ids.get(i)).textureid, new Vector2f(x, y), new Vector2f(sx, sy));
					MainGameLoop.guis.add(slot);
					if(mousepos.x > x - (sx/2) && mousepos.y > y - (sy/2) && mousepos.x < x+sx && mousepos.y < y+sy) {
						GuiTexture sel = new GuiTexture(MainGameLoop.sel, new Vector2f(x, y), new Vector2f(sx, sy));
						MainGameLoop.guis.add(sel);
						if(Mouse.isButtonDown(0)) {
							for(int i1 = 0; i1 < MainGameLoop.inventory.length; i1++) {
								if(MainGameLoop.inventory[i1] == 0 || MainGameLoop.inventory[i1] == ids.get(i)+1) {
									remove = true;
									MainGameLoop.inventory[i1] = ids.get(i) + 1;
									MainGameLoop.inventorycount[i1] += 1;
									break;
								}
							}
						}
					}
				}catch(IndexOutOfBoundsException e) {
					
				}
				if(remove) {
					ids.set(i, -1);
				}
			}
			ind += 0.14f;
			if(ind > 1.2f) {
				ind = 0;
				indy -= 0.20f;
			}
		}
	}
}
