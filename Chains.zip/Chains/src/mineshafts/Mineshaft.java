package mineshafts;

import draw.Image;

public class Mineshaft {
	public int x;
	public int y;
	public int z;
	
	public int id;
	
	public Image img;
	
	public Mineshaft(int x, int y, int z, int id) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.id = id;
	}
}
