package entitys;

import models.TexturedModel;
import render.Loader;

import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;

import engineTester.MainGameLoop;
import terrains.Terrain;

public class Player extends Entity {
   private static final float RUN_SPEED = 20.0F;
   private static final float TURN_SPEED = 160.0F;
   public static final float GRAVITY = -50.0F;
   private static final float JUMP_POWER = 30.0F;
   public static final float TERRAIN = 0.0F;
   private float currentSpeed = 0.0F;
   private float currentTrunSpeed;
   private float upwardsSpeed = 0.0F;
   private boolean isInAir = false;
   float oldterrainheight = 0.0F;
   float oldx;
   float oldz;
   public float health = 0.15F;
   
   float slizeAmount = 0;

   public Player(TexturedModel model, Vector3f position, float rotX, float rotY, float rotZ, float scale) {
      super(model, position, rotX, rotY, rotZ, scale);
   }

   public void move(Terrain terrain, Loader loader, Camera camera) {
      this.checkInputs(loader);
      super.increaseRotation(0.0F, (float)((double)this.currentTrunSpeed * 0.01D), 0.0F);
      float distance = (float)((double)this.currentSpeed * 0.01D);
      float dx = (float)((double)distance * Math.sin(Math.toRadians((double)super.getRotY())));
      float dz = (float)((double)distance * Math.cos(Math.toRadians((double)super.getRotY())));
      super.increasePosition(dx, 0.0F, dz);
      this.upwardsSpeed = (float)((double)this.upwardsSpeed + -0.005D);
      super.increasePosition(0.0F, this.upwardsSpeed, 0.0F);
      float terrainHeight = terrain.getHeightOfTerrain(super.getPosition().x, super.getPosition().z);
      if (super.getPosition().y < terrainHeight) {
         if (this.upwardsSpeed < -0.3F) {
            this.health += this.upwardsSpeed / 12.0F;
         }

         this.upwardsSpeed = 0.0F;
         this.isInAir = false;
         super.getPosition().y = terrainHeight;
      }

      if(MainGameLoop.which_driving_car == null) {
    	  if ((double)terrainHeight - 0.3D > (double)this.oldterrainheight) {
    	         terrainHeight = this.oldterrainheight;
    	         super.getPosition().y = terrainHeight;
    	         super.getPosition().x = this.oldx;
    	         super.getPosition().z = this.oldz;
    	      }

    	      this.oldterrainheight = terrainHeight;
    	      this.oldx = super.getPosition().x;
    	      this.oldz = super.getPosition().z;
      }
      
      camera.move();
   }

   private void jump() {
      if (!this.isInAir) {
         this.upwardsSpeed = 0.18F;
         this.isInAir = true;
      }

   }

   private void checkInputs(Loader loader) {
	  float speed = 30;
	  
	  if(MainGameLoop.antifact_index != -1) {
		  speed = 3.75f;
	  }else if(MainGameLoop.which_driving_car != null) {
		  speed = 60;
	  }
	  
      if (Keyboard.isKeyDown(17)) {
         this.currentSpeed = speed;
      } else if (Keyboard.isKeyDown(31)) {
         this.currentSpeed = -speed;
      } else {
         this.currentSpeed = 0.0F;
      }

      if (Keyboard.isKeyDown(30)) {
         this.currentTrunSpeed = 160.0F;
      } else if (Keyboard.isKeyDown(32)) {
         this.currentTrunSpeed = -160.0F;
      } else {
         this.currentTrunSpeed = 0.0F;
      }

      if (Keyboard.isKeyDown(57)) {
         this.jump();
      }

   }
}
