package render;

import de.matthiasmann.twl.utils.PNGDecoder;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import models.RawModel;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.EXTTextureFilterAnisotropic;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;
import org.lwjgl.opengl.GLContext;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;
import textures.TextureData;

public class Loader {
   private List<Integer> vaos = new ArrayList();
   private List<Integer> vbos = new ArrayList();
   private List<Integer> textures = new ArrayList();

   public RawModel loadtoVAO(float[] positions, float[] textureCoords, float[] normals, int[] indices, ModelData data) {
      int vaoID = this.createVAO();
      this.bindIndicesBuffer(indices);
      this.storeDataInATTLIST(0, 3, positions);
      this.storeDataInATTLIST(1, 2, textureCoords);
      this.storeDataInATTLIST(2, 3, normals);
      this.unbindVAO();
      return new RawModel(vaoID, indices.length, data);
   }

   public int loadtoVAO(float[] positions, float[] textureCoords) {
      int vaoID = this.createVAO();
      this.storeDataInATTLIST(0, 2, positions);
      this.storeDataInATTLIST(1, 2, textureCoords);
      this.unbindVAO();
      return vaoID;
   }

   public RawModel loadToVAO(float[] positions, int dimensions, ModelData data) {
      int vaoID = this.createVAO();
      this.storeDataInATTLIST(0, dimensions, positions);
      this.unbindVAO();
      return new RawModel(vaoID, positions.length / dimensions, data);
   }

   public int loadCubemap(String[] textureFiles) {
      int texID = GL11.glGenTextures();
      GL13.glActiveTexture(33984);
      GL11.glBindTexture(34067, texID);

      for(int i = 0; i < textureFiles.length; ++i) {
         TextureData data = this.decodeTextureFile("res/" + textureFiles[i] + ".png");
         GL11.glTexImage2D('蔕' + i, 0, 6408, data.getWidth(), data.getHeight(), 0, 6408, 5121, (ByteBuffer)data.getBuffer());
      }

      GL11.glTexParameteri(34067, 10240, 9729);
      GL11.glTexParameteri(34067, 10241, 9729);
      this.textures.add(texID);
      return texID;
   }

   private TextureData decodeTextureFile(String fileName) {
      int width = 0;
      int height = 0;
      ByteBuffer buffer = null;

      try {
         FileInputStream in = new FileInputStream(fileName);
         PNGDecoder decoder = new PNGDecoder(in);
         width = decoder.getWidth();
         height = decoder.getHeight();
         buffer = ByteBuffer.allocateDirect(4 * width * height);
         decoder.decode(buffer, width * 4, PNGDecoder.Format.RGBA);
         buffer.flip();
         in.close();
      } catch (Exception var7) {
         var7.printStackTrace();
         System.err.println("Tried to load texture " + fileName + ", didn't work");
         System.exit(-1);
      }

      return new TextureData(buffer, width, height);
   }

   private int createVAO() {
      int vaoID = GL30.glGenVertexArrays();
      this.vaos.add(vaoID);
      GL30.glBindVertexArray(vaoID);
      return vaoID;
   }

   public int loadTexture(String fileName) {
      Texture texture = null;

      try {
         texture = TextureLoader.getTexture("PNG", new FileInputStream("res/" + fileName + ".png"));
         GL30.glGenerateMipmap(GL11.GL_TEXTURE_2D);
         GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR_MIPMAP_LINEAR);
         GL11.glTexParameterf(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_LOD_BIAS, 0);
         if(GLContext.getCapabilities().GL_EXT_texture_filter_anisotropic) {
        	 float amount = Math.min(4f, GL11.glGetFloat(EXTTextureFilterAnisotropic.GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT));
        	 GL11.glTexParameterf(GL11.GL_TEXTURE_2D, EXTTextureFilterAnisotropic.GL_TEXTURE_MAX_ANISOTROPY_EXT, amount);
         }else {
        	 System.out.println("WTF is wrong with your driver! Update it please!");
         }
      } catch (IOException var4) {
         var4.printStackTrace();
      }

      int textureID = texture.getTextureID();
      this.textures.add(textureID);
      return textureID;
   }

   public void updateVbo(int vbo, float[] data, FloatBuffer buffer) {
      buffer.clear();
      buffer.put(data);
      buffer.flip();
      GL15.glBindBuffer(34962, vbo);
      GL15.glBufferData(34962, (long)buffer.capacity(), 35040);
      GL15.glBufferSubData(34962, 0L, (FloatBuffer)buffer);
      GL15.glBindBuffer(34962, 0);
   }

   public void cleanUp() {
      Iterator var2 = this.vaos.iterator();

      int texture;
      while(var2.hasNext()) {
         texture = (Integer)var2.next();
         GL30.glDeleteVertexArrays(texture);
      }

      var2 = this.vbos.iterator();

      while(var2.hasNext()) {
         texture = (Integer)var2.next();
         GL15.glDeleteBuffers(texture);
      }

      var2 = this.textures.iterator();

      while(var2.hasNext()) {
         texture = (Integer)var2.next();
         GL11.glDeleteTextures(texture);
      }

   }

   public int createEmptyVbo(int floatCount) {
      int vbo = GL15.glGenBuffers();
      this.vbos.add(vbo);
      GL15.glBindBuffer(34962, vbo);
      GL15.glBufferData(34962, (long)(floatCount * 4), 35040);
      GL15.glBindBuffer(34962, 0);
      return vbo;
   }

   public void addInstancedATTR(int vao, int vbo, int attribute, int dataSize, int instandDataLength, int offset) {
      GL15.glBindBuffer(34962, vbo);
      GL30.glBindVertexArray(vao);
      GL20.glVertexAttribPointer(attribute, dataSize, 5126, false, instandDataLength * 4, (long)(offset * 4));
      GL33.glVertexAttribDivisor(attribute, 1);
      GL15.glBindBuffer(34962, 0);
      GL30.glBindVertexArray(0);
   }

   private void storeDataInATTLIST(int ATTNumber, int coordinateSize, float[] data) {
      int vboID = GL15.glGenBuffers();
      this.vbos.add(vboID);
      GL15.glBindBuffer(34962, vboID);
      FloatBuffer b = this.storeDataInFloatBuffer(data);
      GL15.glBufferData(34962, (FloatBuffer)b, 35044);
      GL20.glVertexAttribPointer(ATTNumber, coordinateSize, 5126, false, 0, 0L);
      GL15.glBindBuffer(34962, 0);
   }

   private void unbindVAO() {
      GL30.glBindVertexArray(0);
   }

   private void bindIndicesBuffer(int[] indices) {
      int vboID = GL15.glGenBuffers();
      this.vbos.add(vboID);
      GL15.glBindBuffer(34963, vboID);
      IntBuffer buffer = this.storeDataInIntBuffer(indices);
      GL15.glBufferData(34963, (IntBuffer)buffer, 35044);
   }

   private IntBuffer storeDataInIntBuffer(int[] data) {
      IntBuffer buffer = BufferUtils.createIntBuffer(data.length);
      buffer.put(data);
      buffer.flip();
      return buffer;
   }

   private FloatBuffer storeDataInFloatBuffer(float[] data) {
      FloatBuffer buffer = BufferUtils.createFloatBuffer(data.length);
      buffer.put(data);
      buffer.flip();
      return buffer;
   }
}
