package me.thepoitionhunter.extra;

import java.awt.image.BufferedImage;

public class Custom_Object {
	//Settings
	public BufferedImage[] img = new BufferedImage[16];
	public int frame_time;
	public boolean ani = false;
	public String name;
	
	public int default_width;
	public int default_height;
	public int max_place;
	//Values
	public int counter;
	public int target;
	public int frame_on;
	
	public void update() {
		if(ani) {
			counter += 1;
			if(counter >= frame_time) {
				if(img[frame_on+1] != null) {
					frame_on += 1;
				}else {
					frame_on = 0;
				}
			}
		}
	}
}
