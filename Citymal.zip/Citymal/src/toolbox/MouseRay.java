package toolbox;

import java.util.ArrayList;

import org.lwjgl.util.vector.*;

import entitys.Camera;
import entitys.Entity;
import render.Loader;
import render.MasterRenderer;
import terrains.Terrain;

public class MouseRay {
	static Vector3f mousepos = new Vector3f(0, 0, 0);
	public static ArrayList<Vector3f> path = new ArrayList<Vector3f>();
	public static int length = 0;
	
	public static void findmousepos(Camera camera, Terrain terrain) {
		Vector3f curmousepos = new Vector3f(camera.getPosition().x, camera.getPosition().y, camera.getPosition().z);
		Vector3f dir = new Vector3f(camera.getPitch(), camera.getYaw(), camera.getRoll());
		length = 0;
		path.clear();
		while(terrain.getHeightOfTerrain(curmousepos.x, curmousepos.z) < curmousepos.y && length < 20000) {
			float ox = (float) ((Math.cos(Math.toRadians(camera.yaw))*1));
			float oy = (float) ((Math.sin(Math.toRadians(180-camera.pitch))*1));
			float oz = (float) ((Math.sin(Math.toRadians(180-camera.yaw))*1));
			curmousepos.x += ox;
			curmousepos.y += -0.4f;
			curmousepos.z += oz;
			path.add(curmousepos);
			length++;
		}
		if(length < 20000) {
			mousepos = curmousepos;
		}
	}
	
	public static Vector3f getMousepos() {
		return mousepos;
	}
}
