package shaders;

import entitys.Camera;
import entitys.Light;
import java.util.List;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import toolbox.Maths;

public class StaticShader extends ShaderProgram {
   private static final String VERTEX_FILE = "/shaders/vertexShader.txt";
   private static final String FRAGMENT_FILE = "/shaders/fragmentShader.txt";
   private static final int MAX_LIGHTS = 4;
   private int location_t;
   private int location_p;
   private int location_v;
   private int[] location_l;
   private int[] location_c;
   private int[] location_a;
   private int location_s;
   private int location_r;
   private int location_u;
   private int location_k;

   public StaticShader() {
      super("/shaders/vertexShader.txt", "/shaders/fragmentShader.txt");
   }

   protected void bindATTR() {
      super.bindATTR(0, "position");
      super.bindATTR(1, "textureCoords");
      super.bindATTR(2, "normal");
   }

   protected void getAllUniformLocations() {
      this.location_t = super.getUniformLocation("transformationMatrix");
      this.location_p = super.getUniformLocation("projectionMatrix");
      this.location_v = super.getUniformLocation("viewMatrix");
      this.location_s = super.getUniformLocation("shineDamper");
      this.location_r = super.getUniformLocation("rfi");
      this.location_u = super.getUniformLocation("useFakeLight");
      this.location_k = super.getUniformLocation("skyColour");
      this.location_l = new int[4];
      this.location_c = new int[4];
      this.location_a = new int[4];

      for(int i = 0; i < 4; ++i) {
         this.location_l[i] = super.getUniformLocation("lightPosition[" + i + "]");
         this.location_c[i] = super.getUniformLocation("lightColour[" + i + "]");
         this.location_a[i] = super.getUniformLocation("attenuation[" + i + "]");
      }

   }

   public void loadSkyColour(float r, float g, float b) {
      super.loadVector(this.location_k, new Vector3f(r, g, b));
   }

   public void loadFakeLightingVarible(boolean useF) {
      super.loadBoolean(this.location_u, useF);
   }

   public void loadShineVarables(float damper, float rfi) {
      super.loadFloat(this.location_s, damper);
      super.loadFloat(this.location_r, rfi);
   }

   public void loadViewMatrix(Camera camera) {
      Matrix4f viewMatrix = Maths.createView(camera);
      super.loadMatrix(this.location_v, viewMatrix);
   }

   public void loadLights(List<Light> lights) {
      for(int i = 0; i < 4; ++i) {
         if (i < lights.size()) {
            super.loadVector(this.location_l[i], ((Light)lights.get(i)).getPosition());
            super.loadVector(this.location_c[i], ((Light)lights.get(i)).getColour());
            super.loadVector(this.location_a[i], ((Light)lights.get(i)).getattenuation());
         } else {
            super.loadVector(this.location_l[i], new Vector3f(0.0F, 0.0F, 0.0F));
            super.loadVector(this.location_c[i], new Vector3f(0.0F, 0.0F, 0.0F));
            super.loadVector(this.location_a[i], new Vector3f(1.0F, 0.0F, 0.0F));
         }
      }

   }

   public void loadTransformationMatrix(Matrix4f matrix) {
      super.loadMatrix(this.location_t, matrix);
   }

   public void loadProjectionMatrix(Matrix4f projection) {
      super.loadMatrix(this.location_p, projection);
   }
}
