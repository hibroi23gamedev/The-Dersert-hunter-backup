package me.thepoitionhunter.main;
import me.thepotionhunter.objects.*;

import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
public class AssetSetter {
	GamePanel gp;
	public int widthwhencalling = 7 * 48;
	public int heightwhencalling = 6 * 48;
	public int index;
	int poolgroupindex;
	public AssetSetter(GamePanel gp) {
		this.gp = gp;
	}
	
	public void setObject() {
		widthwhencalling = 7 * gp.tileSize;
		heightwhencalling = 6 * gp.tileSize;
		index = 0;
		poolgroupindex = 0;
		Random randompool = new Random();
		for(int i = 0; i<randompool.nextInt(3)+1; i++) {
			Random randomposx = new Random(); 
			Random randomposy = new Random(); 
			addObject("pool", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
		}
		Random randomrock = new Random();
		for(int i = 0; i<randomrock.nextInt(11)+5; i++) {
			Random randomposx = new Random(); 
			Random randomposy = new Random(); 
			addObject("rock", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
		}
		Random randomsand = new Random();
		for(int i = 0; i<randomsand.nextInt(11)+5; i++) {
			Random randomposx = new Random(); 
			Random randomposy = new Random(); 
			addObject("sand", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
		}
		Random randomstick = new Random();
		for(int i = 0; i<randomstick.nextInt(11)+8; i++) {
			Random randomposx = new Random(); 
			Random randomposy = new Random(); 
			addObject("stick", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
		}
		Random randombush = new Random();
		for(int i = 0; i<randombush.nextInt(11)+5; i++) {
			Random randomposx = new Random(); 
			Random randomposy = new Random(); 
			addObject("bush", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
		}
		Random randomgrass = new Random();
		for(int i = 0; i<randomgrass.nextInt(11)+5; i++) {
			Random randomposx = new Random(); 
			Random randomposy = new Random(); 
			addObject("grass", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
		}
		Random randomposx = new Random(); 
		Random randomposy = new Random(); 
		addObject("map", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
	}
	public void addObject(String object, int x, int y) {
		if(object == "pool") {
			addOnePool(x,y);
			addOnePool(x+1,y);
			addOnePool(x+2,y);
			addOnePool(x+3,y);
			addOnePool(x+4,y);
			addOnePool(x+5,y);
			addTwoPool(x+1,y+1, 0);
			addTwoPool(x+2,y+1, 1);
			addTwoPool(x+3,y+1, 1);
			addTwoPool(x+4,y+1, 1);
			addTwoPool(x+5,y+1, 2);
			addTwoPool(x+1,y+2, 3);
			addTwoPool(x+2,y+2, 4);
			addTwoPool(x+3,y+2, 4);
			addTwoPool(x+4,y+2, 4);
			addTwoPool(x+5,y+2, 5);
			addTwoPool(x+1,y+3, 3);
			addTwoPool(x+2,y+3, 4);
			addTwoPool(x+3,y+3, 4);
			addTwoPool(x+4,y+3, 4);
			addTwoPool(x+5,y+3, 5);
			addTwoPool(x+1,y+4, 6);
			addTwoPool(x+2,y+4, 7);
			addTwoPool(x+3,y+4, 7);
			addTwoPool(x+4,y+4, 7);
			addTwoPool(x+5,y+4, 8);
			addOnePool(x+6,y);
			addOnePool(x,y+1);
			addOnePool(x,y+2);
			addOnePool(x,y+3);
			addOnePool(x,y+4);
			addOnePool(x,y+5);
			addOnePool(x+1,y+5);
			addOnePool(x+2,y+5);
			addOnePool(x+3,y+5);
			addOnePool(x+4,y+5);
			addOnePool(x+5,y+5);
			addOnePool(x+6,y+5);
			addOnePool(x+6,y+4);
			addOnePool(x+6,y+3);
			addOnePool(x+6,y+2);
			addOnePool(x+6,y+1);
			poolgroupindex += 1;
		}
		else if (object == "sand") {
			gp.obj[index] = new OBJ_SAND(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}else if (object == "rock") {
			gp.obj[index] = new OBJ_ROCK(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "pan") {
			gp.obj[index] = new OBJ_PAN(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "prewater") {
			gp.obj[index] = new OBJ_PREWATER(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "stick") {
			gp.obj[index] = new OBJ_STICK(gp, x*gp.tileSize, y*gp.tileSize);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "wall") {
			gp.obj[index] = new OBJ_WALL(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "bush") {
			gp.obj[index] = new OBJ_BUSH(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "fence") {
			gp.obj[index] = new OBJ_FENCE(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "grass") {
			gp.obj[index] = new OBJ_GRASS(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "player") {
			gp.obj[index] = new OBJ_GRASS(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].name = "player";
			try {
				gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/player/tph_player_idle.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
		else if (object == "spray") {
				gp.obj[index] = new OBJ_SPRAY(gp);
				gp.obj[index].worldX = x * gp.tileSize;
				gp.obj[index].worldY = y * gp.tileSize;
				gp.obj[index].width = 1 * gp.tileSize;
				gp.obj[index].height = 1 * gp.tileSize;
				for(int i = 0; i < gp.Player.spraying.length; i++) {
					gp.obj[index].extracounters[i] = gp.Player.spraying[i];
				}
				index += 1;
		}
		else if (object == "map") {
			gp.obj[index] = new OBJ_MAP(gp);
			gp.obj[index].worldX = x * gp.tileSize;
			gp.obj[index].worldY = y * gp.tileSize;
			gp.obj[index].width = 1 * gp.tileSize;
			gp.obj[index].height = 1 * gp.tileSize;
			index += 1;
		}
	}
	void addOnePool(int x,int y) {
		gp.obj[index] = new OBJ_POOL(gp, poolgroupindex);
		gp.obj[index].worldX = x * gp.tileSize;
		gp.obj[index].worldY = y * gp.tileSize;
		gp.obj[index].width = 1 * gp.tileSize;
		gp.obj[index].height = 1 * gp.tileSize;
		index += 1;
	}
	void addTwoPool(int x,int y, int type) {
		gp.obj[index] = new OBJ_POOLWATER(gp, poolgroupindex, type);
		gp.obj[index].worldX = x * gp.tileSize;
		gp.obj[index].worldY = y * gp.tileSize;
		gp.obj[index].width = 1 * gp.tileSize;
		gp.obj[index].height = 1 * gp.tileSize;
		index += 1;
	}
}