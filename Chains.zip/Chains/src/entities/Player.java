package entities;

import java.awt.Graphics;
import java.io.IOException;

import javax.imageio.ImageIO;

import draw.Image;
import draw.Light;
import main.GamePanel;
import tiles.TileManager;

import java.awt.image.BufferedImage;

public class Player extends Entity{
	
	public int cos_index = 0;
	
	public BufferedImage[] imgs = new BufferedImage[2];

	public Player(int x, int y, int z) {
		super(x, y, z);
		
		try {
			imgs[0] = ImageIO.read(getClass().getResourceAsStream("/player/idle_left.png"));
			imgs[1] = ImageIO.read(getClass().getResourceAsStream("/player/idle_right.png"));
			for(int i = 0; i < imgs.length; i++) {
				Image img;
				img = new Image(imgs[i], 0, 0, 60, 60);
				img.init();
				imgs[i] = img.c;
			}
			img = new Image(ImageIO.read(getClass().getResourceAsStream("/player/idle_left.png")), 0, 0, 60, 60);
			img.init();
			img.direction = 90;
			img.RES = 1;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void updateImage() {
		img.c = imgs[cos_index];
	}

	@Override
	public void update() {
		updateImage();
		int speed = GamePanel.player_speed;
		if(GamePanel.keys.keys[0]) {
			x -= speed;
			cos_index = 0;
		}if(GamePanel.keys.keys[1]) {
			x += speed;
			cos_index = 1;
		}if(GamePanel.keys.keys[2]) {
			y -= speed;
		}if(GamePanel.keys.keys[3]) {
			y += speed;
		}
		img.x = x;
		img.y = y;
		//updateImage();
	}

	@Override
	public void draw(Graphics g, Light light) {
		img.draw(g, light);
	}

	@Override
	public void update(GamePanel gp) {
		//Nothing here! This is for entities that will need non-static variables in the GamePanel! Like the items, this was the first item
		//to use this void, and not the other one :D
	}

}
