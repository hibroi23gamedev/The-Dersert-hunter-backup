package shadows;

import entitys.Camera;
import entitys.Entity;
import entitys.Light;
import java.util.List;
import java.util.Map;
import models.TexturedModel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

public class ShadowMapMasterRenderer {
   private static final int SHADOW_MAP_SIZE = 4500;
   private ShadowFrameBuffer shadowFbo;
   private ShadowShader shader = new ShadowShader();
   private ShadowBox shadowBox;
   private Matrix4f projectionMatrix = new Matrix4f();
   private Matrix4f lightViewMatrix = new Matrix4f();
   private Matrix4f projectionViewMatrix = new Matrix4f();
   private Matrix4f offset = createOffset();
   private ShadowMapEntityRenderer entityRenderer;

   public ShadowMapMasterRenderer(Camera camera) {
      this.shadowBox = new ShadowBox(this.lightViewMatrix, camera);
      this.shadowFbo = new ShadowFrameBuffer(4500, 4500);
      this.entityRenderer = new ShadowMapEntityRenderer(this.shader, this.projectionViewMatrix);
   }

   public void render(Map<TexturedModel, List<Entity>> entities, Light sun) {
      this.shadowBox.update();
      Vector3f sunPosition = sun.getPosition();
      Vector3f lightDirection = new Vector3f(-sunPosition.x, -sunPosition.y, -sunPosition.z);
      this.prepare(lightDirection, this.shadowBox);
      this.entityRenderer.render(entities);
      this.finish();
   }

   public Matrix4f getToShadowMapSpaceMatrix() {
      return Matrix4f.mul(this.offset, this.projectionViewMatrix, (Matrix4f)null);
   }

   public void cleanUp() {
      this.shader.cleanUp();
      this.shadowFbo.cleanUp();
   }

   public int getShadowMap() {
      return this.shadowFbo.getShadowMap();
   }

   protected Matrix4f getLightSpaceTransform() {
      return this.lightViewMatrix;
   }

   private void prepare(Vector3f lightDirection, ShadowBox box) {
      this.updateOrthoProjectionMatrix(box.getWidth(), box.getHeight(), box.getLength());
      this.updateLightViewMatrix(lightDirection, box.getCenter());
      Matrix4f.mul(this.projectionMatrix, this.lightViewMatrix, this.projectionViewMatrix);
      this.shadowFbo.bindFrameBuffer();
      GL11.glEnable(2929);
      GL11.glClear(256);
      this.shader.start();
   }

   private void finish() {
      this.shader.stop();
      this.shadowFbo.unbindFrameBuffer();
   }

   private void updateLightViewMatrix(Vector3f direction, Vector3f center) {
      direction.normalise();
      center.negate();
      this.lightViewMatrix.setIdentity();
      float pitch = (float)Math.acos((double)(new Vector2f(direction.x, direction.z)).length());
      Matrix4f.rotate(pitch, new Vector3f(1.0F, 0.0F, 0.0F), this.lightViewMatrix, this.lightViewMatrix);
      float yaw = (float)Math.toDegrees((double)((float)Math.atan((double)(direction.x / direction.z))));
      yaw = direction.z > 0.0F ? yaw - 180.0F : yaw;
      Matrix4f.rotate((float)(-Math.toRadians((double)yaw)), new Vector3f(0.0F, 1.0F, 0.0F), this.lightViewMatrix, this.lightViewMatrix);
      Matrix4f.translate(center, this.lightViewMatrix, this.lightViewMatrix);
   }

   private void updateOrthoProjectionMatrix(float width, float height, float length) {
      this.projectionMatrix.setIdentity();
      this.projectionMatrix.m00 = 2.0F / width;
      this.projectionMatrix.m11 = 2.0F / height;
      this.projectionMatrix.m22 = -2.0F / length;
      this.projectionMatrix.m33 = 1.0F;
   }

   private static Matrix4f createOffset() {
      Matrix4f offset = new Matrix4f();
      offset.translate(new Vector3f(0.5F, 0.5F, 0.5F));
      offset.scale(new Vector3f(0.5F, 0.5F, 0.5F));
      return offset;
   }
}
