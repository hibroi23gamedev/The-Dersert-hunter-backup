package pathfinding;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;

import pathfinding.Node;

public class PathFinder {
	final int maxCol = 128;
	final int maxRow = 128;
	final int nodeSize = 70;
	final int WIDTH = nodeSize*maxCol;
	final int HEIGHT = nodeSize*maxRow;
	
	Node[][] node = new Node[maxCol][maxRow];
	public Node startNode,goalNode,currentNode;
	
	ArrayList<Node> openList = new ArrayList<>();
	public ArrayList<Node> checkList = new ArrayList<>();
	
	public ArrayList<Node> path = new ArrayList<Node>();
	
	boolean goalReached = false;
	
	int step;
	
	public PathFinder() {
		
		int col = 0;
		int row = 0;
		while(col < maxCol && row < maxRow) {
			node[col][row] = new Node(col,row);
			col++;
			if(col == maxCol) {
				col = 0;
				row++;
			}
		}
		
	}
	public void setStartNode(int col, int row) {
		node[col][row].setAsStart();
		startNode = node[col][row];
		currentNode = startNode;
	}
	public void setGoalNode(int col, int row) {
		node[col][row].setAsGoal();
		goalNode = node[col][row];
	}
	public void setSoildNode(int col, int row) {
		node[col][row].setAsSoild();
	}
	public void setNormalNode(int col, int row) {
		node[col][row].soild = false;
	}
	public void setCostOnNodes() {
		int col = 0;
		int row = 0;
		while(col < maxCol && row < maxRow) {
			getCost(node[col][row]);
			col++;
			if(col == maxCol) {
				col = 0;
				row++;
			}
		}
	}
	public void getCost(Node node) {
		int xDistance = Math.abs(node.x - startNode.x);
		int yDistance = Math.abs(node.y - startNode.y);
		node.gCost = xDistance+yDistance;
		xDistance = Math.abs(node.x - goalNode.x);
		yDistance = Math.abs(node.y - goalNode.y);
		node.hCost = xDistance+yDistance;
		
		node.fCost = node.gCost+node.hCost;
	}
	public void search() {
		step = 0;
		while(goalReached == false && step < 16000) {
			int col = currentNode.x;
			int row = currentNode.y;
			
			currentNode.setAsChecked();
			checkList.add(currentNode);
			openList.remove(currentNode);
			
			if(row-1 >= 0) {
				openNode(node[col][row-1]);
			}
			if(row+1 < maxRow) {
				openNode(node[col][row+1]);
			}
			if(col-1 >= 0) {
				openNode(node[col-1][row]);
			}
			if(col+1 < maxCol) {
				openNode(node[col+1][row]);
			}
			step++;
			
			int bestNodeIndex = 0;
			int bestNodefCost = 99999;
			for(int i = 0; i < openList.size(); i++) {
				if(openList.get(i).fCost < bestNodefCost) {
					bestNodeIndex = i;
					bestNodefCost = openList.get(i).fCost;
				}
				else if(openList.get(i).fCost == bestNodefCost) {
					if(openList.get(i).gCost < openList.get(bestNodeIndex).gCost) {
						bestNodeIndex = i;
						bestNodefCost = openList.get(i).fCost;
					}
				}
			}
			if(bestNodeIndex != 0) {
				currentNode = openList.get(bestNodeIndex);
			}
			if(currentNode == goalNode) {
				goalReached = true;
				trackThePath();
			}
		}
	}
	public void openNode(Node node) {
		if(node.open == false && node.checked == false && node.soild == false) {
			node.setAsOpen();
			node.parent = currentNode;
			openList.add(node);
		}
	}
	public void trackThePath() {
		Node current = goalNode;
		int step = 0;
		while(current != startNode && step < 6000) {
			current = current.parent;
			if(current != startNode) {
				path.add(current);
			}
			step++;
		}
	}
}
