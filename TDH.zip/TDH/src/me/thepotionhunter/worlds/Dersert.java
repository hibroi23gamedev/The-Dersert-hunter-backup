package me.thepotionhunter.worlds;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.extra.SuperWorld;

public class Dersert extends SuperWorld{
	public Dersert(int idd) {
		name = "Dersert";
		id = idd;
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/worlds/dersert.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
