package me.thepoitionhunter.entity;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import java.util.Random;

import me.thepoitionhunter.main.GamePanel;
import me.thepoitionhunter.main.KeyHandler;
import me.thepoitionhunter.main.UI;
import me.thepotionhunter.objects.OBJ_BUSH;
import me.thepotionhunter.objects.OBJ_FENCE;
import me.thepotionhunter.objects.OBJ_GRASS;
import me.thepotionhunter.objects.OBJ_MAP;
import me.thepotionhunter.objects.OBJ_PAN;
import me.thepotionhunter.objects.OBJ_PAN_SAND;
import me.thepotionhunter.objects.OBJ_POOL;
import me.thepotionhunter.objects.OBJ_POOLWATER;
import me.thepotionhunter.objects.OBJ_PREWATER;
import me.thepotionhunter.objects.OBJ_PREWATERBAD;
import me.thepotionhunter.objects.OBJ_ROCK;
import me.thepotionhunter.objects.OBJ_SAND;
import me.thepotionhunter.objects.OBJ_SPRAY;
import me.thepotionhunter.objects.OBJ_STICK;
import me.thepotionhunter.objects.OBJ_WALL;
import me.thepotionhunter.weapon.Throwing_Strick;

public class player extends Entity{

	KeyHandler keyH;
	UI ui;
	
	public final int ScreenX;
	public final int ScreenY;
	public int[] Inventory = new int[5];
	public int[] inventorycount = new int[5];
	public int insel = 0;
	public double thrist = 250;
	public int thristcounter = 0;
	public double hunger = 250;
	public int hungercounter = 0;
	public double health = 250;
	public int healthcounter = 0;
	public String thristString = "25";
	public String username;
	public int tem = 10;
	public int spraywidth = 8;
	public int sprayheight = 8;
	public int[] spraying = new int[spraywidth*sprayheight];
	public int sprayingcount = 0;
	public BufferedImage[] sand_img = new BufferedImage[8];
	public BufferedImage cuttingimg;
	
	public boolean cutting = false;
	public int cuttingcounter = 0;
	
	public int hardness = 1;
	
	public int itemhold = 0;
	public int itemholdstack = 0;
	
	public int sand_index = -1;
	public double sand_direction = 0;
	
	public int placing_type = 0;
	public int placing_rotation = 0;
	public int oplacing_rotation = 0;
	public boolean placing_other = false;
	
	public int xoffset = 0;
	public int yoffset = 0;
	
	public int sand_frame = 0;
	public int csand_frame = 0;
	
	public int maxhealth = 250;
	
	public player(GamePanel gp, KeyHandler keyH) {
		super(gp);
		this.gp = gp;
		this.keyH = keyH;
		
		try {
			sand_img[0] = ImageIO.read(getClass().getResourceAsStream("/player/sand_storm/0.png"));
			sand_img[1] = ImageIO.read(getClass().getResourceAsStream("/player/sand_storm/1.png"));
			sand_img[2] = ImageIO.read(getClass().getResourceAsStream("/player/sand_storm/2.png"));
			sand_img[3] = ImageIO.read(getClass().getResourceAsStream("/player/sand_storm/3.png"));
			sand_img[4] = ImageIO.read(getClass().getResourceAsStream("/player/sand_storm/4.png"));
			sand_img[5] = ImageIO.read(getClass().getResourceAsStream("/player/sand_storm/5.png"));
			sand_img[6] = ImageIO.read(getClass().getResourceAsStream("/player/sand_storm/6.png"));
			sand_img[7] = ImageIO.read(getClass().getResourceAsStream("/player/sand_storm/7.png"));
			cuttingimg = ImageIO.read(getClass().getResourceAsStream("/player/player_cut.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		ScreenX = gp.screenWidth/2 - (gp.tileSize/2);
		ScreenY = gp.screenHeight/2 - (gp.tileSize/2);
		
		soildArea = new Rectangle();
		soildArea.x = 8;
		soildArea.y = 16;
		solidAreaDefaultX = soildArea.x;
		solidAreaDefaultY = soildArea.y;
		soildArea.width = 32;
		soildArea.height = 32;
		
		Random windsp = new Random();
		gp.wind = windsp.nextInt(2);
		
		setDefaultValues();
		getPlayerImage();
		
	}
	public void setDefaultValues() {
		worldX = gp.tileSize * 23;
		worldY = gp.tileSize * 21;
		speed = 4;
		direction = "down";
	}
	
	public void getPlayerImage() {
		up1 = setup("/player/player_walk_back_1");
		up2 = setup("/player/player_walk_back_2");
		down1 = setup("/player/player_walk_front_1");
		down2 = setup("/player/player_walk_front_2");
		left1 = setup("/player/player_walk_left1");
		left2 = setup("/player/player_walk_left_2");
		right1 = setup("/player/player_walk_right_1");
		right2 = setup("/player/player_walk_right_2");
	}
	
	public void update() {
		if(!cutting) {
			tem = 10;
			if(tem > 15) {
				tem = 15;
			}
			if(tem < 0) {
				tem = 0;
			}
			
			csand_frame += 1;
			if(csand_frame >= 10) {
				csand_frame = 0;
				sand_frame += 1;
				if(sand_frame > 7) {
					sand_frame = 0;
				}
			}
			
			if(keyH.zpressed) {
				if(gp.items.get(Inventory[insel]).name == "stick") {
					switch(direction) {
					case "up":
						gp.weapons.add(new Throwing_Strick(gp, worldX, worldY, 0));
						break;
					case "down":
						gp.weapons.add(new Throwing_Strick(gp, worldX, worldY, 1));
						break;
					case "left":
						gp.weapons.add(new Throwing_Strick(gp, worldX, worldY, 3));
						break;
					case "right":
						gp.weapons.add(new Throwing_Strick(gp, worldX, worldY, 2));
						break;
					default:
						gp.weapons.add(new Throwing_Strick(gp, worldX, worldY, 2));
						break;
					}
					Inventory[insel] = 0;
				}
			}
			
			speed = 4;
			Random winds = new Random();
			if(winds.nextInt(1)+1 == 1) {
				Random windd = new Random();
				int windacc = windd.nextInt(2);
				if(windacc == 1) {
					gp.wind += 1;
				}else {
					if(windacc == 2) {
						gp.wind += 0;
					}else {
						if(windacc == 0) {
							gp.wind += -1;
						}
					}
				}
			}
			Random winddi = new Random();
			if(winddi.nextInt(8)+1 == 1) {
				Random windd = new Random();
				int windacc = windd.nextInt(2);
				if(windacc == 1) {
					gp.winddirection += 1;
				}else {
					if(windacc == 2) {
						gp.winddirection += 0;
					}else {
						if(windacc == 0) {
							gp.winddirection += -1;
						}
					}
				}
			}
			addInventory();
			thrist -= 0.02*hardness;
			if(thrist < 1) {
				health -= 0.07;
			}
			sand_direction += 0.06;
			if(sand_direction >= 360) {
				sand_direction = 1;
			}
			if(sand_index == -1) {
				xoffset = 0;
				yoffset = 0;
			}else {
				if(gp.sobj[sand_index] != null) {
					xoffset = (int) ((Math.sin(sand_direction))*(gp.sobj[sand_index].width/6));
					yoffset = (int) ((Math.cos(sand_direction))*(gp.sobj[sand_index].height/6));
				}else {
					xoffset = 0;
					yoffset = 0;
				}
			}
			hunger -= 0.01*hardness;
			if(hunger < 0) {
				health -= 0.4;
			}
			if(thrist > 250) {
				thrist = 250;
			}
			if(health < 1) {
				gp.gameState = gp.deadState;
			}
			if(sand_index != -1) {
				health -= 0.06;
				if(gp.sobj[sand_index] != null) {
					worldX = gp.sobj[sand_index].x+((gp.sobj[sand_index].width/2)-(gp.tileSize/2));
					worldY = gp.sobj[sand_index].y+((gp.sobj[sand_index].height/2)-(gp.tileSize/2));
				}else {
					sand_index = -1;
				}
			}
			if(keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed == true || keyH.rightPressed == true) {
				if(keyH.upPressed == true) {
					
					direction = "up";		}
				if(keyH.downPressed == true) {
					
					direction = "down";
				}
				
				if(keyH.leftPressed == true) {
					
					direction = "left";
				}
				
				if(keyH.rightPressed == true) {
					
					direction = "right";
				}
				if(keyH.xpressed == true) {
					if(Inventory[insel] == 4) {
						Inventory[insel] = 3;
						thrist += 80;
					}
					if(Inventory[insel] == 6) {
						Inventory[insel] = 3;
						thrist += 60;
						health -= 20;
					}
				}
				
				collisionOn = false;
				gp.cChecker.checkTile(this);
				int objIndex = gp.cChecker.checkObject(this, true);
				pickUpObject(objIndex);
				
				if (collisionOn == false) {
					switch(direction) {
					case "up":
						worldY -= speed;
						break;
					case "down":
						worldY += speed;
						break;
					case "left":
						worldX -= speed;
						break;
					case "right":
						worldX += speed;
						break;
					}
				}
				
				spriteCounter++;
				if (spriteCounter > 12) {
					if(spriteNum == 1) {
						spriteNum = 2;
					}
					else if(spriteNum == 2) {
						spriteNum = 1;
					}
					spriteCounter = 0;
			}
				if(tem >= 12) {
					healthcounter += 1;
					if(healthcounter >= 4*60) {
						healthcounter = 0;
						int healthtake = 1;
						healthtake += tem-12;
						if(healthtake < 1) {
							healthtake = 1;
						}
						health -= healthtake;
					}
				}
		
			}
		}
	}
	public void pickUpObject(int i) {
		if(i != 999) {
			String objectName = gp.obj[i].name;
			switch(objectName) {
			case "Pool1":
				tem -= 3;
				if(tem < 0) {
					tem = 0;
				}
				if(keyH.zpressed == true) {
					if(Inventory[insel] == 3) {
						if(gp.obj[i].counter > 0) {
							Inventory[insel] = 6;
							for(int i1 = 0; i1 < gp.obj.length; i1++) {
								if(gp.obj[i1] != null) {
									gp.obj[i1].godown(i1, gp.obj[i1].name, gp.obj[i].group, gp);
								}
							}
						}
					}
				}
				break;
			case "sand":
				if(keyH.zpressed == true) {
					Inventory[gp.utool.findLengthofList(Inventory, 0)] = 1;
					Random randomposx = new Random(); 
					Random randomposy = new Random(); 
					addObject("sand", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
					gp.obj[i] = null;
				}
				break;
			case "rock":
				if(keyH.zpressed == true) {
					Inventory[gp.utool.findLengthofList(Inventory, 0)] = 2;
					Random randomposx = new Random(); 
					Random randomposy = new Random(); 
					addObject("rock", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
					gp.obj[i] = null;
				}
				break;
			case "grass":
				if(keyH.zpressed == true) {
					Inventory[gp.utool.findLengthofList(Inventory, 0)] = 10;
					Random randomposx = new Random(); 
					Random randomposy = new Random(); 
					addObject("grass", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
					gp.obj[i] = null;
				}
				break;
			case "stick":
				if(keyH.zpressed == true) {
					Inventory[gp.utool.findLengthofList(Inventory, 0)] = 7;
					Random randomposx = new Random(); 
					Random randomposy = new Random(); 
					addObject("stick", (randomposx.nextInt(30)), (randomposy.nextInt(30)));
					gp.obj[i] = null;
				}
				break;
				case "pan":
				if(keyH.vpressed == true) {
					if(Inventory[insel] == 1) {
						int x = gp.obj[i].worldX;
						int y = gp.obj[i].worldY;
						gp.obj[i] = new OBJ_PAN_SAND(gp);
						gp.obj[i].worldX = x;
						gp.obj[i].worldY = y;
						gp.obj[i].width = 1 * gp.tileSize;
						gp.obj[i].height = 1 * gp.tileSize;
						Inventory[insel] = 0;
					}
				}
				break;
				case "bush":
					healthcounter += 1;
					if(healthcounter == 2*60) {
						healthcounter = 0;
						health -= 1;
					}
					break;
				case "fence":
					if(keyH.zpressed == true) {
						if(gp.obj[i].collision == false) {
							gp.obj[i].collision = true;
						}else {
							gp.obj[i].collision = false;
						}
					}
					break;
				case "prewater":
					if(Inventory[insel] == 6) {
						int x = gp.obj[i].worldX;
						int y = gp.obj[i].worldY;
						gp.obj[i] = new OBJ_PREWATERBAD(gp);
						gp.obj[i].worldX = x;
						gp.obj[i].worldY = y;
						gp.obj[i].width = 1 * gp.tileSize;
						gp.obj[i].height = 1 * gp.tileSize;
						Inventory[insel] = 0;
					}
					break;
				case "prewatergood":
					if(keyH.vpressed) {
						int x = gp.obj[i].worldX;
						int y = gp.obj[i].worldY;
						gp.obj[i] = new OBJ_PREWATER(gp);
						gp.obj[i].worldX = x;
						gp.obj[i].worldY = y;
						gp.obj[i].width = 1 * gp.tileSize;
						gp.obj[i].height = 1 * gp.tileSize;
						Inventory[insel] = 4;
					}
					break;
				
				case "panebottle" :
					int x1 = gp.obj[i].worldX;
					int y1 = gp.obj[i].worldY;
					gp.obj[i] = new OBJ_PAN(gp);
					gp.obj[i].worldX = x1;
					gp.obj[i].worldY = y1;
					gp.obj[i].width = 1 * gp.tileSize;
					gp.obj[i].height = 1 * gp.tileSize;
					gp.Player.Inventory[gp.utool.findLengthofList(Inventory, 0)] = 3;
					break;
				case "map" :
					gp.obj[i] = null;
					gp.Player.Inventory[gp.utool.findLengthofList(Inventory, 0)] = 14;
					break;
		}
		}
	}
	public void draw(Graphics2D g2) {
		BufferedImage image = null;
		
		if(sand_index == -1) {
			switch(direction) 
			{
			case "up":
				if(spriteNum == 1) {
					image = up1;
				}
				if(spriteNum == 2) {
					image = up2;
				}
				break;
			
			case "down":
				if(spriteNum == 1) {
					image = down1;
				}
				if(spriteNum == 2) {
					image = down2;
				}
				break;
			case "left":
				
				if(spriteNum == 1) {
					image = left1;
				}
				if(spriteNum == 2) {
					image = left2;
				}
				break;
			case "right":
				if(spriteNum == 1) {
					image = left1;
				}
				if(spriteNum == 2) {
					image = right2;
				}
				break;
			}
		}else {
			image = sand_img[sand_frame];
		}
		if(cutting) {
			g2.drawImage(cuttingimg, ScreenX+xoffset, ScreenY+yoffset, gp.tileSize, gp.tileSize, null);
			cuttingcounter += 1;
			if(cuttingcounter >= 90) {
				Inventory[insel] = 16;
				inventorycount[insel] = 7;
				cutting = false;
				cuttingcounter = 0;
			}
		}else {
			g2.drawImage(image, ScreenX+xoffset, ScreenY+yoffset, gp.tileSize, gp.tileSize, null);
		}
		if(Inventory[insel] != 0) {
			g2.drawImage(gp.items.get(Inventory[insel]).img, ScreenX+25, ScreenY+16, 32, 32, null);
		}
		if(placing_type != 0) {
			g2.drawImage(gp.cobj[placing_type].img[placing_rotation], ScreenX, ScreenY, gp.cobj[placing_type].default_width, gp.cobj[placing_type].default_height, null);
			if(placing_other) {
				g2.drawImage(gp.cobj[placing_type].img[oplacing_rotation], ScreenX, ScreenY, gp.cobj[placing_type].default_width, gp.cobj[placing_type].default_height, null);
			}
		}
	}
	void addInventory() { 
		if(keyH.vpressed == true) {
			int itemIn = Inventory[insel];
			if(itemIn != 0) {
				switch(itemIn) {
				case 2:
					gp.aSetter.addObject("pan",worldX/gp.tileSize,worldY/gp.tileSize);
					Inventory[insel] = 0;
					break;
				case 4:
					thrist += 60;
					Inventory[insel] = 3;
					break;
				case 5:
					gp.aSetter.addObject("prewater",worldX/gp.tileSize,worldY/gp.tileSize);
					Inventory[insel] = 0;
					break;
				case 12:
					hunger += 60;
					Inventory[insel] = 0;
					break;
				case 8:
					switch (direction) {
					case "up" :
						gp.aSetter.addObject("wall",(worldX + 0)/gp.tileSize,(worldY - 1)/gp.tileSize);
						break;
					case "down" :
						gp.aSetter.addObject("wall",(worldX + 0)/gp.tileSize,(worldY + 1)/gp.tileSize);
						break;
					case "left" :
						gp.aSetter.addObject("wall",(worldX - 1)/gp.tileSize,(worldY + 0)/gp.tileSize);
						break;
					case "right" :
						gp.aSetter.addObject("wall",(worldX + 1)/gp.tileSize,(worldY + 0)/gp.tileSize);
						break;
					}
					Inventory[insel] = 0;
					break;
				case 9:
					switch (direction) {
					case "up" :
						gp.aSetter.addObject("fence",(worldX + 0)/gp.tileSize,(worldY - 1)/gp.tileSize);
						break;
					case "down" :
						gp.aSetter.addObject("fence",(worldX + 0)/gp.tileSize,(worldY + 1)/gp.tileSize);
						break;
					case "left" :
						gp.aSetter.addObject("fence",(worldX - 1)/gp.tileSize,(worldY + 0)/gp.tileSize);
						break;
					case "right" :
						gp.aSetter.addObject("fence",(worldX + 1)/gp.tileSize,(worldY + 0)/gp.tileSize);
						break;
					}
					Inventory[insel] = 0;
					break;
				case 13:
					for(int i = 0; i < spraying.length; i++) {
						spraying[i] = 0;
					}
					gp.gameState = gp.spraystate;
					break;
				case 14:
					gp.gameState = gp.mapstate;
					break;
				case 16:
					hunger += 80;
					Inventory[insel] = 0;
					break;
				case 17:
					if(keyH.vpressed) {
						cutting = true;
						cuttingcounter = 0;
					}
					break;
				case 7:
					if(keyH.zpressed) {
						
					}
					break;
				case 19:
					if(keyH.vpressed) {
						placing_type = 1;
						placing_rotation = 0;
						placing_other = false;
					}
					break;
				}	
			}
		}
	}
	public void addObject(String object, int x, int y) {
		if(object == "pool") {
		}
		else if (object == "sand") {
			gp.obj[gp.aSetter.index] = new OBJ_SAND(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}else if (object == "rock") {
			gp.obj[gp.aSetter.index] = new OBJ_ROCK(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "pan") {
			gp.obj[gp.aSetter.index] = new OBJ_PAN(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "prewater") {
			gp.obj[gp.aSetter.index] = new OBJ_PREWATER(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "stick") {
			gp.obj[gp.aSetter.index] = new OBJ_STICK(gp, x*gp.tileSize, y*gp.tileSize);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "wall") {
			gp.obj[gp.aSetter.index] = new OBJ_WALL(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "bush") {
			gp.obj[gp.aSetter.index] = new OBJ_BUSH(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "fence") {
			gp.obj[gp.aSetter.index] = new OBJ_FENCE(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "grass") {
			gp.obj[gp.aSetter.index] = new OBJ_GRASS(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "player") {
			gp.obj[gp.aSetter.index] = new OBJ_GRASS(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].name = "player";
			try {
				gp.obj[gp.aSetter.index].image = ImageIO.read(getClass().getResourceAsStream("/player/tph_player_idle.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
		else if (object == "spray") {
				gp.obj[gp.aSetter.index] = new OBJ_SPRAY(gp);
				gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
				gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
				gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
				gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
				for(int i = 0; i < gp.Player.spraying.length; i++) {
					gp.obj[gp.aSetter.index].extracounters[i] = gp.Player.spraying[i];
				}
				gp.aSetter.index += 1;
		}
		else if (object == "map") {
			gp.obj[gp.aSetter.index] = new OBJ_MAP(gp);
			gp.obj[gp.aSetter.index].worldX = x * gp.tileSize;
			gp.obj[gp.aSetter.index].worldY = y * gp.tileSize;
			gp.obj[gp.aSetter.index].width = 1 * gp.tileSize;
			gp.obj[gp.aSetter.index].height = 1 * gp.tileSize;
			gp.aSetter.index += 1;
		}
	}
	public String getUsername() {
		return username;
	}
}















