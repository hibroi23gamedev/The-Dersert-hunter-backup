package render;

import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.opengl.ContextAttribs;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.PixelFormat;

public class DisplayManager {
   public static final int WIDTH = 1280;
   public static final int HEIGHT = 720;
   public static final int FPS_CAP = 120;
   public static long lastFrametime;
   public static double delta;

   public static void createDisplay() {
      ContextAttribs attribs = (new ContextAttribs(3, 3)).withForwardCompatible(true).withProfileCore(true);

      try {
         Display.setDisplayMode(new DisplayMode(1280, 720));
         Display.create(new PixelFormat().withDepthBits(24), attribs);
         Display.setTitle("Resurant");
         GL11.glEnable(GL13.GL_MULTISAMPLE);
      } catch (LWJGLException var2) {
         var2.printStackTrace();
      }

      GL11.glViewport(0, 0, 1280, 720);
      lastFrametime = getCurrentTime();
   }

   public static void updateDisplay() {
      Display.sync(60);
      Display.update();
      long currentFrameTime = getCurrentTime();
      delta = (double)((currentFrameTime - lastFrametime) / 1000L);
      lastFrametime = currentFrameTime;
   }

   public static double getFrameTimeSeconds() {
      return delta;
   }

   public static void closeDisplay() {
      Display.destroy();
   }

   private static long getCurrentTime() {
      return Sys.getTime() * 1000L / Sys.getTimerResolution();
   }
}
