package buildings;

import java.util.ArrayList;

import building_cs.Building_Componment;
import models.RawModel;
import models.TexturedModel;
import render.Loader;
import render.ModelData;
import render.OBJFileLoader;
import textures.ModelTexture;

public class Emtry extends Building_Type{
	static String name = "";
	static String description = "";
	public TexturedModel model;
	static ArrayList<Building_Componment> components = new ArrayList<Building_Componment>();

	public Emtry(Loader loader) {
		super(name, description, components);
		ModelData data = OBJFileLoader.loadOBJ("buildings/house");
		RawModel raw = loader.loadtoVAO(data.getVertices(), data.getTextureCoords(), data.getNormals(), data.getIndices(), data);
		ModelTexture texture = new ModelTexture(loader.loadTexture("buildings/house"));
		this.texture = texture;
		TexturedModel model = new TexturedModel(raw, texture);
		this.model = model;
	}

	@Override
	public void update() {
		
	}
}
