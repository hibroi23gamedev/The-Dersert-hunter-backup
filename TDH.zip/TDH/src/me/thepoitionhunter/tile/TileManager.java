package me.thepoitionhunter.tile;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.GamePanel;
import me.thepoitionhunter.main.*;

public class TileManager {
	GamePanel gp;
	public Tile[] tile;
	public int mapTileNum[][];
	public int mapcounter = 0;
	
	public TileManager(GamePanel gp) {
		this.gp = gp;
		
		tile = new Tile[10];
		mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];
		
		getTileImage();
		loadMap("/maps/world"+gp.world+".txt");
	}
	
	public void getTileImage() {
		setup(0,"Grass","Grass", false);
		setup(1,"Stone", "Stone", true);
		try {
			tile[2] = new Tile();
			tile[2].name = "water";
			tile[2].image = ImageIO.read(getClass().getResourceAsStream("/tiles/water.png"));
			tile[2].collision = true;
		}catch(IOException e) {
			e.printStackTrace();
		}
		setup(3, "earth", "earth", false);
		setup(4, "Sand", "Sand", false);
		setup(5, "Tree", "Tree", true);
		setup(6, "cstone", "cstone", true);
		setup(7, "bstone", "bstone", false);
			
	}
	public void setup(int index, String name, String imagePath, boolean collision) {
		UtilityTool uTool = new UtilityTool();
		
		try {
			tile[index] = new Tile();
			tile[index].name = name;
			if(imagePath == "water") {
				tile[index].image = ImageIO.read(getClass().getResourceAsStream("/tiles/water.png"));
			}else {
				tile[index].image = ImageIO.read(getClass().getResourceAsStream("/tiles/"+imagePath+".png"));
			}
			//tile[index].image = uTool.scaleImage(tile[index].image, gp.tileSize, gp.tileSize);
			tile[index].collision = collision;
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	public void loadMap(String filePath) {
		try {
			InputStream is = getClass().getResourceAsStream(filePath);
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			int col = 0;
			int row = 0;
			
			while(col < gp.maxWorldCol && row < gp.maxWorldRow) {
				String line = br.readLine();
				while(col < gp.maxWorldCol) {
					String numbers[] = line.split(" ");
					
					int num = Integer.parseInt(numbers[col]);
					
					mapTileNum[col][row] = num;
					col++;
				}
				if(col == gp.maxWorldCol) {
					col = 0;
					row++;
				}
			}
			br.close();
			
		}catch(Exception e) {
			
		}
	}
	public void draw(Graphics2D g2) {
		
		int WorldCol = 0;
		int WorldRow = 0;
		while(WorldCol < gp.maxWorldCol && WorldRow < gp.maxWorldRow) {
			
			
			int tileNum = mapTileNum[WorldCol][WorldRow];
			
			int worldX = WorldCol * gp.tileSize;
			int worldY = WorldRow * gp.tileSize;
			int screenX = worldX - gp.Player.worldX + gp.Player.ScreenX;
			int screenY = worldY - gp.Player.worldY + gp.Player.ScreenY;
			
			if(worldX > (gp.Player.worldX - gp.Player.ScreenX)-48 &&
					worldX < (gp.Player.worldX + gp.Player.ScreenX)+48 &&
					worldY > (gp.Player.worldY - gp.Player.ScreenY)-48 &&
					worldY < (gp.Player.worldY + gp.Player.ScreenY)+48) {
				if(tile[tileNum].name == "water" ) {
					g2.drawImage(tile[tileNum].image, screenX, screenY, 48, 48, null);
				}else {
					g2.drawImage(tile[tileNum].image, screenX, screenY, 48, 48, null);
				}
			}
			WorldCol++;
			if(WorldCol == gp.maxWorldCol) {
				WorldCol = 0;
				WorldRow++;
			}
		}
	}
}
