package skybox;

import entitys.Camera;
import models.RawModel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Matrix4f;

import engineTester.MainGameLoop;
import render.Loader;

import java.util.Random;

public class SkyboxRenderer {
   private static final float SIZE = 2.0F;
   private static final float[] VERTICES = new float[]{-500.0F, 500.0F, -500.0F, -500.0F, -500.0F, -500.0F, 500.0F, -500.0F, -500.0F, 500.0F, -500.0F, -500.0F, 500.0F, 500.0F, -500.0F, -500.0F, 500.0F, -500.0F, -500.0F, -500.0F, 500.0F, -500.0F, -500.0F, -500.0F, -500.0F, 500.0F, -500.0F, -500.0F, 500.0F, -500.0F, -500.0F, 500.0F, 500.0F, -500.0F, -500.0F, 500.0F, 500.0F, -500.0F, -500.0F, 500.0F, -500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, -500.0F, 500.0F, -500.0F, -500.0F, -500.0F, -500.0F, 500.0F, -500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, -500.0F, 500.0F, -500.0F, -500.0F, 500.0F, -500.0F, 500.0F, -500.0F, 500.0F, 500.0F, -500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, 500.0F, -500.0F, 500.0F, 500.0F, -500.0F, 500.0F, -500.0F, -500.0F, -500.0F, -500.0F, -500.0F, -500.0F, 500.0F, 500.0F, -500.0F, -500.0F, 500.0F, -500.0F, -500.0F, -500.0F, -500.0F, 500.0F, 500.0F, -500.0F, 500.0F};
   private static String[] TEXTURE_FILES = new String[]{"right", "left", "top", "bottom", "back", "front"};
   private static String[] NIGHT_TEXTURE_FILES = new String[]{"nightRight", "nightLeft", "nightTop", "nightBottom", "nightBack", "nightFront"};
   private RawModel cube;
   private int texture;
   public int nightTexture;
   private SkyboxShader shader;
   private float time = 10000.0F;
   
   boolean alreadydoneblood = false;

   public SkyboxRenderer(Loader loader, Matrix4f projectionMatrix) {
      this.cube = loader.loadToVAO(VERTICES, 3, null);
      this.texture = loader.loadCubemap(TEXTURE_FILES);
      this.nightTexture = loader.loadCubemap(NIGHT_TEXTURE_FILES);
      this.shader = new SkyboxShader();
      this.shader.start();
      this.shader.connectTextureUnits();
      this.shader.loadProjectionMatrix(projectionMatrix);
      this.shader.stop();
   }

   public void render(Camera camera, float r, float g, float b) {
      this.shader.start();
      this.shader.loadViewMatrix(camera);
      short c = (short)((int)(((24000.0F - this.time) / 1000.0F - 13.0F) * ((24000.0F - this.time) / 1000.0F - 13.0F) * 0.02F));
      if (c > 255) {
         boolean var6 = true;
      }

      this.shader.loadFogColour(r, g, b);
      GL30.glBindVertexArray(this.cube.getVaoID());
      GL20.glEnableVertexAttribArray(0);
      this.bindTextures();
      GL11.glDrawArrays(4, 0, this.cube.getVertexCount());
      GL30.glBindVertexArray(0);
      this.shader.stop();
   }

   private void bindTextures() {
      this.time = (float)((double)this.time + 1.875D);
	  //this.time += 35;
      if (this.time > 24000.0F) {
         this.time = 0.0F;
         alreadydoneblood = false;
      }
      if(this.time > 16000.0F && !alreadydoneblood) {
    	  Random random = new Random();
          if(random.nextInt(3) == 0) {
         	 MainGameLoop.blood_moon = true;
          }else {
         	 MainGameLoop.blood_moon = false;
          }
          alreadydoneblood = true;
      }

      float blend_Factor = (this.time / 1000.0F - 13.0F) * (this.time / 1000.0F - 13.0F) * 0.02F;
      if (blend_Factor > 1.0F) {
         blend_Factor = 1.0F;
      }
      if(!MainGameLoop.blood_moon) {
    	  MainGameLoop.light.getColour().x = 1f - blend_Factor;
      }else {
    	  MainGameLoop.light.getColour().x = 1f;
      }
      MainGameLoop.light.getColour().y = 1f - blend_Factor;
      MainGameLoop.light.getColour().z = 1f - blend_Factor;
      
      GL13.glActiveTexture(33984);
      GL11.glBindTexture(34067, this.texture);
      GL13.glActiveTexture(33985);
      GL11.glBindTexture(34067, this.nightTexture);
      this.shader.loadBlendFactor(blend_Factor);
   }
}
