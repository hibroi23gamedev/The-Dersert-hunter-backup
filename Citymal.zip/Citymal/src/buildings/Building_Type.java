package buildings;

import models.TexturedModel;
import textures.ModelTexture;
import building_cs.*;

import java.util.ArrayList;

public abstract class Building_Type {
	public int id;
	public static String name;
	public static String description;
	public TexturedModel model;
	public static ModelTexture texture;
	public static ArrayList<Building_Componment> components = new ArrayList<Building_Componment>();
	
	public Building_Type(String name, String description,
			ArrayList<Building_Componment> components) {
		this.name = name;
		this.description = description;
		this.components = components;
	}



	public abstract void update();
}
