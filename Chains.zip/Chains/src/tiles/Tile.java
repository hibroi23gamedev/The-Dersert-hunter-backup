package tiles;

import draw.Image;

public class Tile {
	public int id;
	public int imageID;
	
	//public Image img;
}
