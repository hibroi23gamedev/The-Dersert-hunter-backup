package me.thepoitionhunter.main;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import me.thepoitionhunter.net.packet.*;

public class WindowHandler implements WindowListener{
	private final GamePanel gp;
	
	public WindowHandler(GamePanel gp) {
		this.gp = gp;
		this.gp.frame.addWindowListener(this);
	}
	@Override
	public void windowOpened(WindowEvent e) {
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		Packet01Disconnect packet = new Packet01Disconnect(this.gp.Player.getUsername());
		packet.writeData(this.gp.socketclient);
	}

	@Override
	public void windowClosed(WindowEvent e) {
		
	}

	@Override
	public void windowIconified(WindowEvent e) {		
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		
	}

}
