package me.thepotionhunter.objects;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import me.thepoitionhunter.main.*;
import java.util.Random;

import javax.imageio.ImageIO;

public class SuperObect {
	AssetSetter asset;
	public BufferedImage image;
	public String name;
	public int width;
	public int height;
	public boolean collision = false;
	public int worldX, worldY;
	public Rectangle solidArea = new Rectangle(0,0,48,48);
	public int solidAreaDefaultX = 0;
	public int solidAreaDefaultY = 0;
	public int counter;
	public int[] extracounters = new int[256];
	public int group;
	GamePanel gp;
	public String extraname;
	UtilityTool uTool;
	
	public SuperObect() {
		uTool = new UtilityTool();
	}
	
	public void draw(BufferedImage image,Graphics2D g2, GamePanel gp, int width, int height, int offsetX, int offsetY) { 
		int screenX = worldX - gp.Player.worldX + gp.Player.ScreenX;
		int screenY = worldY - gp.Player.worldY + gp.Player.ScreenY;
		
		if(worldX > (gp.Player.worldX - gp.Player.ScreenX)-48 &&
				worldX < (gp.Player.worldX + gp.Player.ScreenX)+48 &&
				worldY > (gp.Player.worldY - gp.Player.ScreenY)-48 &&
				worldY < (gp.Player.worldY + gp.Player.ScreenY)+48) {
		g2.drawImage(image, screenX + offsetX, screenY + offsetY, width, height, null);
		}
		
	}
	
	public void update(String type, int index, GamePanel gp) {
		if(type == "pansand") {
			counter += 1;
			if(counter >= 7*60) {
				counter = 0;
				int x = gp.obj[index].worldX;
				int y = gp.obj[index].worldY;
				gp.obj[index] = new OBJ_PAN_EBOTTLE(gp);
				gp.obj[index].worldX = x;
				gp.obj[index].worldY = y;
				gp.obj[index].width = 1 * gp.tileSize;
				gp.obj[index].height = 1 * gp.tileSize;
			}
		}else if (type == "prewaterbad") {
			counter += 1;
			if(counter >= 2*60) {
				counter = 0;
				int x = gp.obj[index].worldX;
				int y = gp.obj[index].worldY;
				gp.obj[index] = new OBJ_PREWATERGOOD(gp);
				gp.obj[index].worldX = x;
				gp.obj[index].worldY = y;
				gp.obj[index].width = 1 * gp.tileSize;
				gp.obj[index].height = 1 * gp.tileSize;
			}
		}
		else if (type == "bush") {
			counter += 1;
			if(counter >= 1*60) {
				Random bushX = new Random();
				Random bushY = new Random();
				if(bushX.nextInt(2) >= 0 && bushX.nextInt(2) < 1) {
					gp.obj[index].worldX += -1*gp.wind;
				}
				if(bushX.nextInt(2) >= 1 && bushX.nextInt(2) < 2) {
					gp.obj[index].worldX += 0*gp.wind;
				}
				if(bushX.nextInt(2) >= 1 && bushX.nextInt(2) < 2) {
					gp.obj[index].worldX += 1*gp.wind;
				}
				if(bushY.nextInt(2) >= 0 && bushY.nextInt(2) < 1) {
					gp.obj[index].worldY += -1*gp.wind;
				}
				if(bushY.nextInt(2) >= 1 && bushY.nextInt(2) < 2) {
					gp.obj[index].worldY += 0*gp.wind;
				}
				if(bushY.nextInt(2) >= 1 && bushY.nextInt(2) < 2) {
					gp.obj[index].worldY += 1*gp.wind;
				}
				float bushXX = (float) (Math.sin(gp.winddirection)*gp.wind);
				float bushYY = (float) (Math.cos(gp.winddirection)*gp.wind);
				
				gp.obj[index].worldX += (float)(bushXX);
				gp.obj[index].worldY += (float)(bushYY);
			}
		}
		else if (type == "grass") {
			counter += 1;
			if(counter > 2*60) {
				extracounters[0] += 1;
				try {
					if(extracounters[0] == 0) {
						gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/grass0.png"));
					}
					if(extracounters[0] == 1) {
						gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/grass1.png"));
					}
					if(extracounters[0] == 2) {
						gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/grass2.png"));
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(extracounters[0] > 2) {
				extracounters[0] = 0;
			}
		}
		else if (type == "PoolWater1") {
			extracounters[1] += 1;
			if(gp.weather == 1) {
				extracounters[2] += 1;
				if(extracounters[2] >= 250) {
					extracounters[2] = 0;
					counter += 1;
					if(counter > 5) {
						counter = 5;
					}
				}
			}
			if(gp.weather == 2) {
				extracounters[3] += 1;
				if(extracounters[3] >= 500) {
					extracounters[3] = 0;
					counter -= 1;
					if(counter < 0) {
						counter = 0;
					}
				}
			}
			if(extracounters[1] >= 60) {
				extracounters[1] = 0;
				try {
					if(counter == 5) {
						if(extracounters[5] == 0) {
							gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_top_right.png"));
						}else {
							if(extracounters[5] == 1) {
								gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_top.png"));
							}else {
								if(extracounters[5] == 2) {
									gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_top_left.png"));
								}else {
									if(extracounters[5] == 3) {
										gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_middle_right.png"));
									}else {
										if(extracounters[5] == 4) {
											gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/middle.png"));
										}else {
											if(extracounters[5] == 5) {
												gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_middle_left.png"));
											}else {
												if(extracounters[5] == 6) {
													gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_bottom_right.png"));
												}else {
													if(extracounters[5] == 7) {
														gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_bottom.png"));
													}else {
														if(extracounters[5] == 8) {
															gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_bottom_left.png"));
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}else {
						if(counter == 4) {
							if(extracounters[5] == 0) {
								gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/corner_top_right.png"));
							}else {
								if(extracounters[5] == 1) {
									gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/corner_top.png"));
								}else {
									if(extracounters[5] == 2) {
										gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/corner_top_left.png"));
									}else {
										if(extracounters[5] == 3) {
											gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/corner_middle_right.png"));
										}else {
											if(extracounters[5] == 4) {
												gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/middle.png"));
											}else {
												if(extracounters[5] == 5) {
													gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/corner_middle_left.png"));
												}else {
													if(extracounters[5] == 6) {
														gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/corner_bottom_right.png"));
													}else {
														if(extracounters[5] == 7) {
															gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/corner_bottom.png"));
														}else {
															if(extracounters[5] == 8) {
																gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth2/corner_bottom_left.png"));
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}else {
							if(counter == 3) {
								if(extracounters[5] == 0) {
									gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/corner_top_right.png"));
								}else {
									if(extracounters[5] == 1) {
										gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/corner_top.png"));
									}else {
										if(extracounters[5] == 2) {
											gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/corner_top_left.png"));
										}else {
											if(extracounters[5] == 3) {
												gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/corner_middle_right.png"));
											}else {
												if(extracounters[5] == 4) {
													gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/middle.png"));
												}else {
													if(extracounters[5] == 5) {
														gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/corner_middle_left.png"));
													}else {
														if(extracounters[5] == 6) {
															gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/corner_bottom_right.png"));
														}else {
															if(extracounters[5] == 7) {
																gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/corner_bottom.png"));
															}else {
																if(extracounters[5] == 8) {
																	gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth3/corner_bottom_left.png"));
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}else {
								if(counter == 2) {
									if(extracounters[5] == 0) {
										gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/corner_top_right.png"));
									}else {
										if(extracounters[5] == 1) {
											gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/corner_top.png"));
										}else {
											if(extracounters[5] == 2) {
												gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/corner_top_left.png"));
											}else {
												if(extracounters[5] == 3) {
													gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/corner_middle_right.png"));
												}else {
													if(extracounters[5] == 4) {
														gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/middle.png"));
													}else {
														if(extracounters[5] == 5) {
															gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/corner_middle_left.png"));
														}else {
															if(extracounters[5] == 6) {
																gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/corner_bottom_right.png"));
															}else {
																if(extracounters[5] == 7) {
																	gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/corner_bottom.png"));
																}else {
																	if(extracounters[5] == 8) {
																		gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth4/corner_bottom_left.png"));
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}else {
									if(counter == 1) {
										if(extracounters[5] == 0) {
											gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/corner_top_right.png"));
										}else {
											if(extracounters[5] == 1) {
												gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/corner_top.png"));
											}else {
												if(extracounters[5] == 2) {
													gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/corner_top_left.png"));
												}else {
													if(extracounters[5] == 3) {
														gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/corner_right.png"));
													}else {
														if(extracounters[5] == 4) {
															gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/middle.png"));
														}else {
															if(extracounters[5] == 5) {
																gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/corner_left.png"));
															}else {
																if(extracounters[5] == 6) {
																	gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/corner_bottom_right.png"));
																}else {
																	if(extracounters[5] == 7) {
																		gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/corner_bottom.png"));
																	}else {
																		if(extracounters[5] == 8) {
																			gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth5/corner_bottom_left.png"));
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}else {
										if(counter == 0) {
											if(extracounters[5] == 0) {
												gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/corner_top_right.png"));
											}else {
												if(extracounters[5] == 1) {
													gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/corner_top.png"));
												}else {
													if(extracounters[5] == 2) {
														gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/corner_top_left.png"));
													}else {
														if(extracounters[5] == 3) {
															gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/corner_middle_right.png"));
														}else {
															if(extracounters[5] == 4) {
																gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/middle.png"));
															}else {
																if(extracounters[5] == 5) {
																	gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/corner_middle_left.png"));
																}else {
																	if(extracounters[5] == 6) {
																		gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/corner_bottom_right.png"));
																	}else {
																		if(extracounters[5] == 7) {
																			gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/corner_bottom.png"));
																		}else {
																			if(extracounters[5] == 8) {
																				gp.obj[index].image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth6/corner_bottom_left.png"));
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}else {
											
										}
									}
								}
							}
						}
					}
				}catch(IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public void godown(int index, String name, int playergroup, GamePanel gp) {
		switch(name) {
		case "PoolWater1" :
			if(gp.obj[index].group == playergroup) {
				counter -= 1;
				if(counter < 0) {
					counter = 0;
				}
				System.out.println(counter);
			}
			break;
		case "Pool1" :
			if(gp.obj[index].group == playergroup) {
				counter -= 1;
				if(counter < 0) {
					counter = 0;
				}
				System.out.println(counter);
			}
			break;
	}
	}
}
