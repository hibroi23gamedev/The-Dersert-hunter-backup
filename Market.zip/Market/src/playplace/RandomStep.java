package playplace;

public class RandomStep extends Step{

	public RandomStep(int startx, int starty, int startz, int endx, int endy, int endz, int random) {
		super(startx, starty, startz, endx, endy, endz);
		
	}
	
}
