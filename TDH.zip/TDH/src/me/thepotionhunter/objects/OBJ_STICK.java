package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_STICK extends SuperObect{
	GamePanel gp;
	public OBJ_STICK(GamePanel gp, int worldX, int worldY) {
		this.gp = gp;
		name = "stick";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/stick.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		this.worldX = worldX;
		this.worldY = worldY;
		collision = false;
	}
}
