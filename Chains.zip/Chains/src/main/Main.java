package main;

import javax.swing.JFrame;

public class Main {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(1200,800);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Chains");
		GamePanel gp = new GamePanel(frame);
		frame.add(gp);
		frame.setVisible(true);
		
		gp.startGame();
	}
}