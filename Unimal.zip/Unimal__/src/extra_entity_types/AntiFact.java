package extra_entity_types;

import org.lwjgl.util.vector.Vector3f;

import entitys.Camera;
import entitys.Entity;
import entitys.Player;
import models.TexturedModel;
import render.MasterRenderer;
import terrains.Terrain;

public abstract class AntiFact extends Entity{

	public AntiFact(TexturedModel model, Vector3f position, float rotX, float rotY, float rotZ, float scale) {
		super(model, position, rotX, rotY, rotZ, scale);
	}
	
	public abstract void update(Terrain terrain, MasterRenderer renderer, Player player, Camera camera);
	
}
