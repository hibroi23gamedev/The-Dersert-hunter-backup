package entitys;

import org.lwjgl.util.vector.Vector3f;

import audio.Source;
import models.TexturedModel;
import terrains.Terrain;

public class Sheep extends Animal{

	public Sheep(TexturedModel model, Vector3f position, float rotX, float rotY, float rotZ, float scale, Source source) {
		super(model, position, rotX, rotY, rotZ, scale, source);
		type = 0;
	}
	
	public void update(Terrain terrain) {
		move(terrain);
	}

}
