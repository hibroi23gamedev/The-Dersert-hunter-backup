package draw;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;

import java.awt.Graphics2D;

import java.awt.Polygon;
import java.awt.geom.AffineTransform;

import main.GamePanel;

import java.awt.Dimension;

public class Dir_Trail {
	public int x;
	public int y;
	public int width;
	public int height;
	public double degreey;
	public Color c;
	
	public Dir_Trail(int x, int y, int width, int height, double degreey, Color c) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.degreey = degreey;
		this.c = c;
	}
	
	public void draw(Graphics g, GamePanel gp) {
		if(degreey > 360) {
			degreey = 0;
		}
		Graphics2D g2 = (Graphics2D)g;
		int x;
		int y;
		for(int i = 0; i < width; i++) {
			x = this.x;
			y = this.y;
			x += i*Math.cos(Math.toRadians(degreey));
			y += i*Math.sin(Math.toRadians(degreey));
			for(int i1 = 0; i1 < height; i1++) {
				x += i*Math.sin(Math.toRadians(degreey));
				y += i*Math.cos(Math.toRadians(degreey));
				g2.drawLine(x, y, x+1, y+1);
			}
		}
		
		//This method only worked on 1 rectangle
		//g2.setColor(c);
		//g2.fill(new Polygon(new int[]{x,(int) (x+Math.sin(degreey)*width),(int) (x+Math.cos(degreey-1.5)*width)}, new int[]{y,(int) (y+(Math.cos(degreey)*height)), (int) (y+Math.sin(degreey-1.5)*height)}, 3));
	}
}
