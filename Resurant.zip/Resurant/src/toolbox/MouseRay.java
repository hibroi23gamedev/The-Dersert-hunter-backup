package toolbox;

import org.lwjgl.util.vector.*;

import entitys.Camera;
import entitys.Entity;
import render.Loader;
import render.MasterRenderer;
import terrains.Terrain;

public class MouseRay {
	static Vector3f mousepos = new Vector3f(0, 0, 0);
	public static int length = 0;
	
	public static void findmousepos(Camera camera, Terrain terrain) {
		Vector3f curmousepos = new Vector3f(camera.getPosition().x, camera.getPosition().y, camera.getPosition().z);
		Vector3f dir = new Vector3f(camera.getPitch(), camera.getYaw(), camera.getRoll());
		length = 0;
		while(terrain.getHeightOfTerrain(curmousepos.x, curmousepos.z) < curmousepos.y && length < 20000) {
			curmousepos.x += (4-(Math.cos(Math.toRadians(180-dir.y))));
			curmousepos.y += 0-(Math.sin(Math.toRadians(dir.y)));
			curmousepos.z += 0-(Math.tan(Math.toRadians(dir.x)));
			//curmousepos.x += 0f;
			//curmousepos.y += -0.2f;
			//curmousepos.z += 0f;
			length++;
		}
		if(length < 20000) {
			mousepos = curmousepos;
		}
	}
	
	public static Vector3f getMousepos() {
		return mousepos;
	}
}
