package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_PAN_SAND extends SuperObect{
	GamePanel gp;
	public OBJ_PAN_SAND(GamePanel gp) {
		this.gp = gp;
		name = "pansand";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/pansand.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = false;
	}
}
