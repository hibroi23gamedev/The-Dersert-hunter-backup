package items;

import java.util.ArrayList;

public class SuperItem {
   public ArrayList<Item> items = new ArrayList();

   public void additem(String name, int texture, ItemPro itemprotecties) {
      this.items.add(new Item(name, texture, itemprotecties));
   }
}
