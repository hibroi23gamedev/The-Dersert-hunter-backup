package render;

import entitys.Camera;
import entitys.Entity;
import entitys.Light;
import extra.Rig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import models.TexturedModel;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Matrix4f;
import shaders.StaticShader;
import shaders.TerrainShader;
import shadows.ShadowMapMasterRenderer;
import skybox.SkyboxRenderer;
import terrains.Terrain;
import textures.ModelTexture;

public class MasterRenderer {
   private StaticShader shader = new StaticShader();
   private Matrix4f projectionMatrix;
   private EntityRenderer renderer;
   public static final float FOV = 120.0F;
   public static final float NEAR_PLANE = 0.1F;
   private static final float FAR_PLANE = 1.0F;
   private static final float sRED = 0.5444F;
   private static final float sGREEN = 0.62F;
   private static final float sBLUE = 0.69F;
   private SkyboxRenderer skybox;
   private ShadowMapMasterRenderer shadow;
   private TerrainRenderer terrainRenderer;
   private TerrainShader terrainShader = new TerrainShader();
   private Map<TexturedModel, List<Entity>> entites = new HashMap();
   private List<Terrain> terrains = new ArrayList();

   public MasterRenderer(ModelTexture g, Loader loader, Camera camera) {
      enableCulling();
      this.createProjectionMatrix();
      this.renderer = new EntityRenderer(this.shader, this.projectionMatrix);
      this.terrainRenderer = new TerrainRenderer(this.terrainShader, this.projectionMatrix, g);
      this.skybox = new SkyboxRenderer(loader, this.projectionMatrix);
      this.shadow = new ShadowMapMasterRenderer(camera);
   }

   public static void enableCulling() {
      GL11.glEnable(2884);
      GL11.glCullFace(1029);
   }

   public static void disableCulling() {
      GL11.glDisable(2884);
   }

   public void render(List<Light> lights, Camera camera) {
      this.prepare();
      this.shader.start();
      this.shader.loadLights(lights);
      this.shader.loadViewMatrix(camera);
      this.shader.loadSkyColour(0.5444F, 0.62F, 0.69F);
      this.renderer.render(this.entites);
      this.shader.stop();
      this.terrainShader.start();
      this.terrainShader.loadSkyColour(0.5444F, 0.62F, 0.69F);
      this.terrainShader.loadLights(lights);
      this.terrainShader.loadViewMatrix(camera);
      this.terrainRenderer.render(this.terrains, this.shadow.getToShadowMapSpaceMatrix());
      this.terrainShader.stop();
      this.skybox.render(camera, 0.5444F, 0.62F, 0.69F);
      this.terrains.clear();
      this.entites.clear();
   }

   public void processTerrain(Terrain terrain) {
      this.terrains.add(terrain);
   }

   private void createProjectionMatrix() {
      this.projectionMatrix = new Matrix4f();
      float aspectRatio = (float)Display.getWidth() / (float)Display.getHeight();
      float y_scale = (float)(1.0D / Math.tan(Math.toRadians(35.0D)));
      float x_scale = y_scale / aspectRatio;
      float frustum_length = 999.9F;
      this.projectionMatrix.m00 = x_scale;
      this.projectionMatrix.m11 = y_scale;
      this.projectionMatrix.m22 = -(1000.1F / frustum_length);
      this.projectionMatrix.m23 = -1.0F;
      this.projectionMatrix.m32 = -(200.0F / frustum_length);
      this.projectionMatrix.m33 = 0.0F;
   }

   public void processEntity(Entity entity) {
      TexturedModel entityModel = entity.getModel();
      List<Entity> batch = (List)this.entites.get(entityModel);
      if (batch != null) {
         batch.add(entity);
      } else {
         List<Entity> newBatch = new ArrayList();
         newBatch.add(entity);
         this.entites.put(entityModel, newBatch);
      }

   }

   public Matrix4f getProjectionMatrix() {
      return this.projectionMatrix;
   }

   public void renderShadowMap(List<Entity> entity, Light sun) {
      Iterator var4 = entity.iterator();

      while(var4.hasNext()) {
         Entity entity2 = (Entity)var4.next();
         this.processEntity(entity2);
      }

      this.shadow.render(this.entites, sun);
      this.entites.clear();
   }

   public int getShadow() {
      return this.shadow.getShadowMap();
   }

   public void cleanUp() {
      this.shader.cleanUp();
      this.terrainShader.cleanUp();
      this.shadow.cleanUp();
   }

   public void prepare() {
      GL11.glEnable(2929);
      GL11.glClear(16640);
      GL11.glClearColor(0.5444F, 0.62F, 0.69F, 1.0F);
      GL13.glActiveTexture(33989);
      GL11.glBindTexture(3553, this.getShadow());
   }
}
