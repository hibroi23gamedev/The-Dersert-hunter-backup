package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_FENCE extends SuperObect{
	GamePanel gp;
	public OBJ_FENCE(GamePanel gp) {
		this.gp = gp;
		name = "fence";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/fence.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = true;
	}
}
