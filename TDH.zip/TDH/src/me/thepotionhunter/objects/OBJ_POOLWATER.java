package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_POOLWATER extends SuperObect{
	GamePanel gp;
	public OBJ_POOLWATER(GamePanel gp, int groupindex, int type) {
		this.gp = gp;
		name = "PoolWater1";
		counter = 5;
		extracounters[5] = type;
		try {
			if(type == 0) {
				image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_top_right.png"));
			}else {
				if(type == 1) {
					image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_top.png"));
				}else {
					if(type == 2) {
						image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_top_left.png"));
					}else {
						if(type == 3) {
							image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_middle_right.png"));
						}else {
							if(type == 4) {
								image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/middle.png"));
							}else {
								if(type == 5) {
									image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_middle_left.png"));
								}else {
									if(type == 6) {
										image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_bottom_right.png"));
									}else {
										if(type == 7) {
											image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_bottom.png"));
										}else {
											if(type == 8) {
												image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/corner_bottom_left.png"));
											}else {
												image = ImageIO.read(getClass().getResourceAsStream("/objects/water/depth1/middle.png"));
											}
										}
									}
								}
							}
						}
					}
				}
			}
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = true;
		group = groupindex;
	}
}
