package me.thepoitionhunter.net;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.List;

import javax.imageio.ImageIO;

import java.util.ArrayList;


import me.thepoitionhunter.entity.playermp;
import me.thepoitionhunter.main.GamePanel;
import me.thepoitionhunter.net.packet.*;
import me.thepoitionhunter.net.packet.Packet.PacketTypes;
import me.thepotionhunter.objects.OBJ_PAN;
import me.thepotionhunter.objects.SuperObect;

public class GameServer extends Thread{
	public DatagramSocket socket;
	private GamePanel gp;
	private List<playermp> connectedPlayers = new ArrayList<playermp>();
	
	public GameServer(GamePanel gp) {
		this.gp = gp;
		try {
			this.socket = new DatagramSocket(gp.port);
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		while(true) {
			byte[] data = new byte[1024];
			DatagramPacket packet = new DatagramPacket(data, data.length);
			try {
				socket.receive(packet);
			} catch (IOException e) {
				e.printStackTrace();
			}
			parsePacket(packet.getData(), packet.getAddress(), packet.getPort());
			String message = new String(packet.getData());
			System.out.println("CLIENT ["+packet.getAddress().getHostAddress()+":"+packet.getPort()+"]>"+message);
//			if(message.trim().equalsIgnoreCase("ping")) {
//				System.out.println("Returning pong");
//				sendData("ping".getBytes(), packet.getAddress(),packet.getPort());
//			}
		}
	}
	
	private void parsePacket(byte[] data, InetAddress address, int port) {
		String message = new String(data).trim();
		PacketTypes type = Packet.lookupPacket(message.substring(0,2));
		switch (type) {
		default:
		case INVAILD:
			break;
		case LOGIN:
			Packet00Login packet = new Packet00Login(data);
			System.out.println("["+address.getHostAddress()+":"+port+"] "+packet.getUsername() + " has Connected...");
			playermp playerm = null;
			if(address.getHostAddress().equalsIgnoreCase("127.0.0.1")) {
				playerm = new playermp(gp, gp.keyH, address, port);
			}else {
				playerm = new playermp(gp, gp.keyH, address, port);
			}
			this.connectedPlayers.add(playerm);
			int index = gp.utool.findLengthofList(gp.obj, null);
			gp.aSetter.addObject("player", 23, 21);
			break;
		case DISCONNECT:
			Packet01Disconnect packet1 = new Packet01Disconnect(data);
			System.out.println("["+address.getHostAddress()+":"+port+"] "+packet1.getUsername() + " didn't want to live in the dersert...");
			playermp playerm1 = null;
			this.connectedPlayers.remove(playerm1);
			
			break;
		case MOVEUP:
			for(int i = 0; i < gp.obj.length; i++) {
				if(gp.obj[i].name == "player") {
					gp.obj[i].worldX -= gp.Player.speed;
				}
			}
			break;
		}
	}

	public void removeConnection(Packet01Disconnect packet) {
		playermp player = getPlayerMP(packet.getUsername()); 
		this.connectedPlayers.remove(getPlayerMPIndex(packet.getUsername()));
		packet.writeData(this);
	}
	
	public playermp getPlayerMP(String username) {
		for(playermp player : this.connectedPlayers) {
			if(player.getUsername().equals(username)) {
				return player;
			}
		}
		return null;
	}
	public int getPlayerMPIndex(String username) {
		int index = 0;
		for(playermp player : this.connectedPlayers) {
			if(player.getUsername().equals(username)) {
				break;
			}
			index++;
		}
		return index;
	}
	
	public void sendData(byte[] data, InetAddress ipAddress, int port) {
		DatagramPacket packet = new DatagramPacket(data, data.length, ipAddress, port); 
		try {
			this.socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendDataToAllClients(byte[] data) {
		for (playermp p : connectedPlayers) {
			sendData(data, p.ipAddress, p.port);
		}
	}
}
