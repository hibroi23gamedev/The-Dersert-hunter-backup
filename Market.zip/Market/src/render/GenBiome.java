package render;

public class GenBiome {
	int x;
	int y;
	int type;
}
