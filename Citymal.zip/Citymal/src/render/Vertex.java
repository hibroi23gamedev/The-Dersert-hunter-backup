package render;

import org.lwjgl.util.vector.Vector3f;

public class Vertex {
   private static final int NO_INDEX = -1;
   private Vector3f position;
   private int textureIndex = -1;
   private int normalIndex = -1;
   private Vertex duplicateVertex = null;
   private int index;
   private float length;

   public Vertex(int index, Vector3f position) {
      this.index = index;
      this.position = position;
      this.length = position.length();
   }

   public int getIndex() {
      return this.index;
   }

   public float getLength() {
      return this.length;
   }

   public boolean isSet() {
      return this.textureIndex != -1 && this.normalIndex != -1;
   }

   public boolean hasSameTextureAndNormal(int textureIndexOther, int normalIndexOther) {
      return textureIndexOther == this.textureIndex && normalIndexOther == this.normalIndex;
   }

   public void setTextureIndex(int textureIndex) {
      this.textureIndex = textureIndex;
   }

   public void setNormalIndex(int normalIndex) {
      this.normalIndex = normalIndex;
   }

   public Vector3f getPosition() {
      return this.position;
   }

   public int getTextureIndex() {
      return this.textureIndex;
   }

   public int getNormalIndex() {
      return this.normalIndex;
   }

   public Vertex getDuplicateVertex() {
      return this.duplicateVertex;
   }

   public void setDuplicateVertex(Vertex duplicateVertex) {
      this.duplicateVertex = duplicateVertex;
   }
}
