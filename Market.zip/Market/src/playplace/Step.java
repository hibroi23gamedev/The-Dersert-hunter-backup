package playplace;

public class Step {
	double startx;
	double starty;
	double startz;
	public double endx;
	public double endy;
	public double endz;
	public Step(double x, double y, double z, double x2, double y2 , double z2) {
		this.startx = x;
		this.starty = y;
		this.startz = z;
		this.endx = x2;
		this.endy = y2;
		this.endz = z2;
	}
}
