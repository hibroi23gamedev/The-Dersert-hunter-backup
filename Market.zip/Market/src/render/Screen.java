package render;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import java.awt.Dimension;

import java.util.Random;

import playplace.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.imageio.ImageIO;
import javax.swing.JButton;

import fruits.*;
import falling_fruits.*;
import placing.*;
import extra.*;

public class Screen extends JPanel implements KeyListener, MouseListener, MouseMotionListener, MouseWheelListener{
	
	//ArrayList of all the 3D polygons - each 3D polygon has a 2D 'PolygonObject' inside called 'DrawablePolygon'
	public static ArrayList<DPolygon> DPolygons = new ArrayList<DPolygon>();
	
	public static ArrayList<Cube> Cubes = new ArrayList<Cube>();
	public static ArrayList<Prism> Prisms = new ArrayList<Prism>();
	public static ArrayList<Pyramid> Pyramids = new ArrayList<Pyramid>();
	public static ArrayList<Person> People = new ArrayList<Person>();
	public static ArrayList<Kid> kids = new ArrayList<Kid>();
	
	static ArrayList<Shelf> Shelfs = new ArrayList<Shelf>();
	public static ArrayList<Fruit> fruits = new ArrayList<Fruit>();
	
	public static ArrayList<Apple> fapple = new ArrayList<Apple>();
	
	public static ArrayList<Conveyer> cvey = new ArrayList<Conveyer>();
	
	public static ArrayList<Table> tables = new ArrayList<Table>();
	
	public static ArrayList<Toy> toys = new ArrayList<Toy>();
	
	public int apples = 96;
	
	public int unareaselx = 0;
	public int unareasely = 0;
	public byte unareaseltype = 0;
	
	public ArrayList<Thought> custhoughts = new ArrayList<Thought>();
	
	//The polygon that the mouse is currently over
	static PolygonObject PolygonOver = null;
	
	public boolean unlockingarea = false;
	
	public JFrame frame;
	
	public BufferedImage shopimg;
	public BufferedImage outimg;
	
	public double money = 2000;
	
	public ArrayList<Integer> unareax = new ArrayList<Integer>();
	public ArrayList<Integer> unareay = new ArrayList<Integer>();
	public ArrayList<Byte> unareatype = new ArrayList<Byte>();
	
	public boolean fpressed = false;
	
	public boolean isshelf = false;
	
	public Placing[] place = new Placing[8];
	public int placingindex = 0;
	
	//Used for keeping mouse in center
	Robot r;

	static double[] ViewFrom = new double[] { 1200, 1200, 300},	
					ViewTo = new double[] {0, 14, 0},
					LightDir = new double[] {1, 1, 1};
	
	boolean mp = false;

	public byte shopwidth = 2;
	public byte shopheight = 2;
	
	
	//The smaller the zoom the more zoomed out you are and visa versa, although altering too far from 1000 will make it look pretty weird
	static double zoom = 1000, MinZoom = 500, MaxZoom = 2500, MouseX = 0, MouseY = 0, MovementSpeed = 2;
	
	//FPS is a bit primitive, you can set the MaxFPS as high as u want
	double drawFPS = 0, MaxFPS = 1000, SleepTime = 1000.0/MaxFPS, LastRefresh = 0, StartTime = System.currentTimeMillis(), LastFPSCheck = 0, Checks = 0;
	//VertLook goes from 0.999 to -0.999, minus being looking down and + looking up, HorLook takes any number and goes round in radians
	//aimSight changes the size of the center-cross. The lower HorRotSpeed or VertRotSpeed, the faster the camera will rotate in those directions
	double VertLook = -0.5, HorLook = 0, aimSight = 4, HorRotSpeed = 900, VertRotSpeed = 3200, SunPos = 0;
	boolean las = false;
	int lasi = 0;
	//will hold the order that the polygons in the ArrayList DPolygon should be drawn meaning DPolygon.get(NewOrder[0]) gets drawn first
	int[] NewOrder;
	
	int applec = 0;
	
	boolean placing = false;
	int placingx = 0;
	int placingy = 0;
	int placingareax = 0;
	int placingareay = 0;
	int placingareaindex = 0;

	static boolean OutLines = false;
	boolean PlayMode = true;
	public double daychange = 0.01;
	public boolean inshop = false;
	boolean[] Keys = new boolean[4];
	public int chance = 100;
	
	long repaintTime = 0;
	
	public Screen(JFrame frame)
	{		
		this.frame = frame;
		this.addKeyListener(this);
		setFocusable(true);		
		
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.addMouseWheelListener(this);
		
		Cubes.add(new Cube(1400,1200,8,300,200,200,Color.gray));
		Pyramids.add(new Pyramid(1400,1200,208,300,200,150,Color.red));
		
		cvey.add(new Conveyer(80100,1300,8, Color.black));
		
		unlockarea(0,0,(byte)0);
		unlockarea(0,1,(byte)0);
		unlockarea(1,0,(byte)0);
		unlockarea(1,1,(byte)1);
		unlockarea(2,0,(byte)2);
		unlockarea(2,1,(byte)0);
		
		toys.add(new Toy(80375, 1300, 8, 50, 20, 50, 1, Color.gray));
		
		Shelfs.add(new Shelf(80050,1250, 8, Color.white, 4, 0, true));
		
		Shelfs.add(new Shelf(400000,1230, 8, Color.white, 0, 21000000, false));
		
		//PLACING
		place[0] = new Placing();
		place[0].name = "Apple";
		place[0].type = 0;
		place[0].artype = 0;
		place[1] = new Placing();
		place[1].name = "Orange";
		place[1].type = 1;
		place[1].artype = 0;
		place[2] = new Placing();
		place[2].name = "Banana";
		place[2].type = 2;
		place[2].artype = 0;
		place[3] = new Placing();
		place[3].name = "Cumba";
		place[3].type = 3;
		place[3].artype = 0;
		place[4] = new Placing();
		place[4].name = "Tomato";
		place[4].type = 4;
		place[4].artype = 0;
		
		place[5] = new Placing();
		place[5].name = "Table";
		place[5].type = 0;
		place[5].artype = 1;
		
		place[6] = new Placing();
		place[6].name = "Slide";
		place[6].type = 0;
		place[6].artype = 2;
		
		place[7] = new Placing();
		place[7].name = "Slide+BallPit";
		place[7].type = 1;
		place[7].artype = 2;
		
		invisibleMouse();	
		new GenerateTerrain();
		//Cubes.add(new Cube(0, -5, 0, 2, 2, 2, Color.red));
		//Prisms.add(new Prism(6, -5, 0, 2, 2, 2, Color.green));
		//Pyramids.add(new Pyramid(12, -5, 0, 2, 2, 2, Color.blue));
		//Cubes.add(new Cube(18, -5, 0, 2, 2, 2, Color.red));
		//Cubes.add(new Cube(20, -5, 0, 2, 2, 2, Color.red));
		//Cubes.add(new Cube(22, -5, 0, 2, 2, 2, Color.red));
		//Cubes.add(new Cube(20, -5, 2, 2, 2, 2, Color.red));
		//Prisms.add(new Prism(18, -5, 2, 2, 2, 2, Color.green));
		//Prisms.add(new Prism(22, -5, 2, 2, 2, 2, Color.green));
		//Pyramids.add(new Pyramid(20, -5, 4, 2, 2, 2, Color.blue));
		try {
			shopimg = ImageIO.read(getClass().getResourceAsStream("/ui/shop.png"));
			outimg = ImageIO.read(getClass().getResourceAsStream("/ui/outside.png"));
		} catch (IOException e) {
			System.out.println("SHOULDN'T HAVE DELELTED OR RENAMED THE FILES LOL");
		}
	}	
	
	public void paintComponent(Graphics g)
	{
		
		for(int i = 0; i < fruits.size(); i++) {
			if(fruits.get(i).conv) {
				Fruit fruit = fruits.get(i);
				if(fruit.timelasted < 100) {
					new Fruit_Type(fruit.x, fruit.y+fruit.speed, fruit.z, -1, null, null, fruit.type, true, fruit.timelasted+1, fruit.remove, fruit.aftertime);
				}else {
					if(fruit.timelasted < 200) {
						if(fruit.timelasted < 150) {
							new Fruit_Type(fruit.x, fruit.y+((150-fruit.timelasted)/(100-(fruit.speed*20))), fruit.z-0.2, -1, null, null, fruit.type, true, fruit.timelasted+1, fruit.remove, fruit.aftertime);
						}else {
							new Fruit_Type(fruit.x, fruit.y, fruit.z, -1, null, null, fruit.type, true, fruit.timelasted+1, fruit.remove, fruit.aftertime);
						}
					}
				}
				fruits.get(i).removeCube();
			}
			
			try {
				if(fruits.get(i).remove) {
					fruits.get(i).timelasted += 1;
					if(fruits.get(i).timelasted > fruits.get(i).aftertime) {
						fruits.get(i).removeCube();
					}
				}
			}catch(IndexOutOfBoundsException e) {
				System.out.println("WTF HAPPENED UGHHHH");
			}
		}
		
		for(int i = 0; i < tables.size(); i++) {
			tables.get(i).update_false();
		}
		for(int i = 0; i < kids.size(); i++) {
			kids.get(i).update(this);
		}
		Random random = new Random();
		if(random.nextInt(chance) == 0) {
			int x = 1000;
			int y = 0;
			int z = 8;
			Random random2 = new Random();
			if(random2.nextInt(24) == 0) {
				People.add(new Person(x, y, z, Color.green));
				if(chance > 5) {
					chance -= 5;
				}
			}else {
				Random random3 = new Random();
				if(random3.nextInt(80-custhoughts.size()) == 0) {
					if(custhoughts.size() > 0) {
						Random random4 = new Random();
						int rand = random4.nextInt(custhoughts.size());
						if(custhoughts.get(rand).rating < 3) {
							People.add(new Person(x, y, z, Color.red));
						}else if(custhoughts.get(rand).rating > 15) {
							People.add(new Person(x, y, z, Color.blue));
						}else {
							People.add(new Person(x, y, z, Color.yellow));
						}
					}else {
						People.add(new Person(x, y, z, Color.yellow));
					}
				}else {
					People.add(new Person(x, y, z, Color.yellow));
				}
			}
			kids.add(new Kid(Color.yellow, People.size()-1, true, new Dimension(40,15)));
		}
		
		if(custhoughts.size() > 60) {
			custhoughts.remove(0);
		}
		
		if(las) {
			if(lasi < DPolygons.size()) {
				DPolygons.get(lasi).draw = false;
			}
		}
		for(int i = 0; i < People.size(); i++) {
			People.get(i).update(this);
		}
		isshelf = false;
		for(int i = 0; i < Shelfs.size(); i++) {
			 Shelfs.get(i).update(this);
		}
		for(int i = 0; i < fapple.size(); i++) {
			fapple.get(i).update();
		}
		applec += 1;
		if(applec >= 1) {
			applec = 0;
			apples += 1;
		}
		
		//Clear screen and draw background color
		g.setColor(new Color(140, 180, 180));
		g.fillRect(0, 0, (int)Main.ScreenSize.getWidth(), (int)Main.ScreenSize.getHeight());

		CameraMovement();
		
		//Calculated all that is general for this camera position
		Calculator.SetPrederterminedInfo();

		ControlSunAndLight();

		//Updates each polygon for this camera position
		for(int i = 0; i < DPolygons.size(); i++)
			DPolygons.get(i).updatePolygon();
		
		//rotate and update shape examples
		//Cubes.get(0).rotation+=.01;
		//Cubes.get(0).updatePoly();

		//Prisms.get(0).rotation+=.01;
		//Prisms.get(0).updatePoly();
		
		//Pyramids.get(0).rotation+=.01;
		//Pyramids.get(0).updatePoly();

		//Set drawing order so closest polygons gets drawn last
		setOrder();
			
		//Set the polygon that the mouse is currently over
		setPolygonOver();
			
		//draw polygons in the Order that is set by the 'setOrder' function
		for(int i = 0; i < NewOrder.length; i++)
			DPolygons.get(NewOrder[i]).DrawablePolygon.drawPolygon(g);
			
		//draw the cross in the center of the screen
		drawMouseAim(g);			
		
		//FPS display
		g.drawString("FPS: " + (int)drawFPS + " V1.0 DEV", 40, 40);
		
		if(!PlayMode) {
			g.drawString("day_speed: " + (double)daychange + " per frame", 40, 80);
		}
		if(las) {
			g.drawString("looking at index: " + lasi, 40, 60);
		}
		
//		repaintTime = System.currentTimeMillis() - repaintTime; 
//		System.out.println(repaintTime);
		SleepAndRefresh();
		
		//UI
		g.setColor(Color.cyan);
		g.fillRect(50, 200, 250, 100);
		if(inshop) {
			g.drawImage(outimg, 50, 200, 96, 96, null);
		}else {
			g.drawImage(shopimg, 50, 200, 96, 96, null);
		}
		g.setFont(new Font("Arial",Font.BOLD, 20));
		g.setColor(Color.BLACK);
		g.drawString("<- Press M", 150, 250);
		
		g.drawString("Apples: "+apples, 60, 400);
		
		g.drawString("Money: "+money, 60, 200);
		
		if(isshelf) {
			g.setFont(new Font("Arial", Font.BOLD, 100));
			g.drawString("Press F to restock", getXforCenterText("Press F to restock", g), 200);
		}
		
		if(placing) {
			g.setColor(Color.cyan);
			g.fillRect(0, frame.getHeight()-150, frame.getWidth(), 150);
			int ri = 0;
			for(int i = 0; i < place.length; i++) {
				if(place[i].artype == unareatype.get(placingareaindex)) {
					if(placingindex == ri) {
						g.setColor(Color.green);
					}else {
						g.setColor(Color.blue);
					}
					g.fillRect(20+(ri*120), frame.getHeight()-125, 100, 100);
					g.setColor(Color.black);
					g.drawString(place[i].name, 20+(ri*120), frame.getHeight()-75);
				}else {
					ri--;
				}
				ri++;
			}
		}
		g.drawString(String.valueOf(placingareaindex), 80, 900);
		g.setFont(new Font("Arial", Font.BOLD, 40));
		g.drawString("U to unlock areas",20,350);
		
		if(unlockingarea) {
			g.setColor(Color.CYAN);
			g.fillRect((frame.getWidth()/2)-(200), (frame.getHeight()/2)-(200), 400, 400);
			boolean selected = false;
			for(int i = 0; i < unareatype.size(); i++) {
				boolean clicked = false;
				if(unareax.get(i) == unareaselx) {
					if(unareay.get(i) == unareasely) {
						clicked = true;
					}
				}
				if(unareatype.get(i) == 0) {
					if(clicked) {
						g.setColor(Color.WHITE);
						selected = true;
					}else {
						g.setColor(Color.GRAY);
					}
				}else {
					if(unareatype.get(i) == 1) {
						if(clicked) {
							g.setColor(Color.YELLOW);
							selected = true;
						}else {
							g.setColor(Color.ORANGE);
						}
					}else {
						if(clicked) {
							g.setColor(new Color(146, 255, 146));
							selected = true;
						}else {
							g.setColor(Color.GREEN);
						}
					}
				}
				if(clicked) {
					placingareaindex = i;
				}
				g.fillRect(((frame.getWidth()/2)+(unareax.get(i)*40))-(200), ((frame.getHeight()/2)+(unareay.get(i)*40))-(200), 40, 40);
				g.setColor(Color.black);
				g.drawRect(((frame.getWidth()/2)+(unareax.get(i)*40))-(200), ((frame.getHeight()/2)+(unareay.get(i)*40))-(200), 40, 40);
			}
			g.setColor(Color.BLACK);
			String text = "Unlock Areas";
			g.drawString(text, getXforCenterText(text, g), (frame.getHeight()/2)+(180));
			g.setColor(Color.GRAY);
			
			g.setFont(new Font("Arial", Font.BOLD, 25));
			String text2 = "0 - Market";
			g.drawString(text2, getXforCenterText(text2, g)-126, (frame.getHeight()/2)+(130));
			g.setColor(Color.ORANGE);
			String text3 = "1 - Cafe";
			g.drawString(text3, getXforCenterText(text3, g)+-16, (frame.getHeight()/2)+(130));
			
			g.setColor(Color.GREEN);
			String text4 = "2 - PlayPlace";
			g.drawString(text4, getXforCenterText(text4, g)+116, (frame.getHeight()/2)+(130));
			if(!selected) {
				if(money > 50) {
					unlockarea(unareaselx, unareasely, unareaseltype);
				}
			}
		}
		if(placing) {
			g.setColor(Color.CYAN);
			g.fillRect((frame.getWidth()/2)-(350), (frame.getHeight()/2)-(350), 700, 640);
			switch(unareatype.get(placingareaindex)) {
			case 0:
				g.setColor(Color.GRAY);
				g.fillRect(((frame.getWidth()/2)-(350))+(placingx*4), ((frame.getHeight()/2)-(350))+(placingy*4), 20, 260);
				break;
			case 1:
				g.setColor(Color.ORANGE);
				g.fillRect(((frame.getWidth()/2)-(350))+(placingx*4), ((frame.getHeight()/2)-(350))+(placingy*4), 40, 40);
				break;
			case 2:
				g.setColor(Color.RED);
				g.fillRect(((frame.getWidth()/2)-(350))+(placingx*4), ((frame.getHeight()/2)-(350))+(placingy*4), 80, 80);
				break;
			}
			g.setColor(Color.BLACK);
			String text = "Press C to Place, Press Enter to close";
			g.drawString(text,getXforCenterText(text,g), ((frame.getHeight()/2)+(350)));
		}
	}
	public int getXforCenterText(String text, Graphics g2) {
		int length = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
		int x = frame.getWidth()/2 - length/2;
		return x;
	}
	void setOrder()
	{
		double[] k = new double[DPolygons.size()];
		NewOrder = new int[DPolygons.size()];
		
		for(int i=0; i<DPolygons.size(); i++)
		{
			k[i] = DPolygons.get(i).AvgDist;
			NewOrder[i] = i;
		}
		
	    double temp;
	    int tempr;	    
		for (int a = 0; a < k.length-1; a++)
			for (int b = 0; b < k.length-1; b++)
				if(k[b] < k[b + 1])
				{
					temp = k[b];
					tempr = NewOrder[b];
					NewOrder[b] = NewOrder[b + 1];
					k[b] = k[b + 1];
					   
					NewOrder[b + 1] = tempr;
					k[b + 1] = temp;
				}
	}
		
	void invisibleMouse()
	{
		 Toolkit toolkit = Toolkit.getDefaultToolkit();
		 BufferedImage cursorImage = new BufferedImage(1, 1, BufferedImage.TRANSLUCENT); 
		 Cursor invisibleCursor = toolkit.createCustomCursor(cursorImage, new Point(0,0), "InvisibleCursor");        
		 setCursor(invisibleCursor);
	}
	
	void drawMouseAim(Graphics g)
	{
		if(PlayMode) {
			g.setColor(Color.black);
			g.drawLine((int)(Main.ScreenSize.getWidth()/2 - aimSight), (int)(Main.ScreenSize.getHeight()/2), (int)(Main.ScreenSize.getWidth()/2 + aimSight), (int)(Main.ScreenSize.getHeight()/2));
			g.drawLine((int)(Main.ScreenSize.getWidth()/2), (int)(Main.ScreenSize.getHeight()/2 - aimSight), (int)(Main.ScreenSize.getWidth()/2), (int)(Main.ScreenSize.getHeight()/2 + aimSight));		
		}
	}

	void SleepAndRefresh()
	{
		long timeSLU = (long) (System.currentTimeMillis() - LastRefresh); 

		Checks ++;			
		if(Checks >= 15)
		{
			drawFPS = Checks/((System.currentTimeMillis() - LastFPSCheck)/1000.0);
			LastFPSCheck = System.currentTimeMillis();
			Checks = 0;
		}
		
		if(timeSLU < 1000.0/MaxFPS)
		{
			try {
				Thread.sleep((long) (1000.0/MaxFPS - timeSLU));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}	
		}
				
		LastRefresh = System.currentTimeMillis();
		
		repaint();
	}
	
	void ControlSunAndLight()
	{
		SunPos += daychange;		
		double mapSize = GenerateTerrain.mapSize * GenerateTerrain.Size;
		LightDir[0] = mapSize/2 - (mapSize/2 + Math.cos(SunPos) * mapSize * 10);
		LightDir[1] = mapSize/2 - (mapSize/2 + Math.sin(SunPos) * mapSize * 10);
		LightDir[2] = -200;
	}
	
	void CameraMovement()
	{
		Vector ViewVector = new Vector(ViewTo[0] - ViewFrom[0], ViewTo[1] - ViewFrom[1], ViewTo[2] - ViewFrom[2]);
		double xMove = 0, yMove = 0, zMove = 0;
		Vector VerticalVector = new Vector (0, 0, 1);
		Vector SideViewVector = ViewVector.CrossProduct(VerticalVector);
		
		if(Keys[0])
		{
			xMove += ViewVector.x ;
			yMove += ViewVector.y ;
			if(!PlayMode) {
				zMove += ViewVector.z;
			}
		}

		if(Keys[2])
		{
			xMove -= ViewVector.x ;
			yMove -= ViewVector.y ;
			if(!PlayMode) {
				zMove -= ViewVector.z;
			}
		}
			
		if(Keys[1])
		{
			xMove += SideViewVector.x ;
			yMove += SideViewVector.y ;
			if(!PlayMode) {
				zMove += SideViewVector.z;
			}
		}

		if(Keys[3])
		{
			xMove -= SideViewVector.x ;
			yMove -= SideViewVector.y ;
			if(!PlayMode) {
				zMove -= SideViewVector.z;
			}
		}
		
		Vector MoveVector = new Vector(xMove, yMove, zMove);
		MoveTo(ViewFrom[0] + MoveVector.x * MovementSpeed, ViewFrom[1] + MoveVector.y * MovementSpeed, ViewFrom[2] + MoveVector.z * MovementSpeed);
	}

	void MoveTo(double x, double y, double z)
	{
		ViewFrom[0] = x;
		ViewFrom[1] = y;
		ViewFrom[2] = z;
		updateView();
	}

	void setPolygonOver()
	{
		if(PlayMode) {
			las = false;
			PolygonOver = null;
			for(int i = NewOrder.length-1; i >= 0; i--)
				if(DPolygons.get(NewOrder[i]).DrawablePolygon.MouseOver() && DPolygons.get(NewOrder[i]).draw 
						&& DPolygons.get(NewOrder[i]).DrawablePolygon.visible)
				{
					PolygonOver = DPolygons.get(NewOrder[i]).DrawablePolygon;
					if(mp) {
						DPolygons.get(i).clicked = true;
					}else {
						DPolygons.get(i).clicked = false;
					}
					las = true;
					lasi = i;
					break;
				}
		}
	}

	void MouseMovement(double NewMouseX, double NewMouseY)
	{
			double difX = (NewMouseX - Main.ScreenSize.getWidth()/2);
			double difY = (NewMouseY - Main.ScreenSize.getHeight()/2);
			difY *= 6 - Math.abs(VertLook) * 5;
			VertLook -= difY  / VertRotSpeed;
			HorLook += (difX / HorRotSpeed)*2;
			
			/*
			if(VertLook>0.999)
				VertLook = 0.999;
			*/
			if(VertLook<-0.999)
				VertLook = -0.999;
			
			updateView();
			/*
			*/	
		}
	
	void updateView()
	{
		double r = Math.sqrt(1 - (VertLook * VertLook));
		ViewTo[0] = ViewFrom[0] + r * Math.cos(HorLook);
		ViewTo[1] = ViewFrom[1] + r * Math.sin(HorLook);		
		ViewTo[2] = ViewFrom[2] + VertLook;
	}
	
	void CenterMouse() 
	{
			try {
				r = new Robot();
				r.mouseMove((int)Main.ScreenSize.getWidth()/2, (int)Main.ScreenSize.getHeight()/2);
			} catch (AWTException e) {
				e.printStackTrace();
			}
	}
	
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_W)
			Keys[0] = true;
		if(e.getKeyCode() == KeyEvent.VK_A)
			Keys[1] = true;
		if(e.getKeyCode() == KeyEvent.VK_S)
			Keys[2] = true;
		if(e.getKeyCode() == KeyEvent.VK_D)
			Keys[3] = true;
		if(e.getKeyCode() == KeyEvent.VK_O)
			PlayMode = !PlayMode;
		if(!PlayMode) {
			if(e.getKeyCode() == KeyEvent.VK_K) {
				daychange -= 0.01;
			}
			if(e.getKeyCode() == KeyEvent.VK_L) {
				daychange += 0.01;
			}
		}
		if(placing) {
			if(e.getKeyCode() == KeyEvent.VK_W) {
				if(placingy > 0) {
					placingy -= 1;
				}
			}
			if(e.getKeyCode() == KeyEvent.VK_S) {
				if(placingy < 150) {
					placingy += 1;
				}
			}
			if(e.getKeyCode() == KeyEvent.VK_A) {
				if(placingx > 0) {
					placingx -= 1;
				}
			}
			if(e.getKeyCode() == KeyEvent.VK_D) {
				if(placingx < 150) {
					placingx += 1;
				}
			}
			if(e.getKeyCode() == KeyEvent.VK_C) {
				switch(unareatype.get(placingareaindex)) {
				case 0:
					Random random = new Random();
					Shelfs.add(new Shelf((((placingareax*150)+placingx)+80000)-65, ((placingareay*150)+placingy)+1200, 8, Color.gray, placingindex, random.nextInt(2000000), true));
					break;
				case 1:
					Random random2 = new Random();
					tables.add(new Table((((placingareax*150)+placingx)+80000)-65, ((placingareay*150)+placingy)+1200, 8, random2.nextInt(2000000)));
					break;
				case 2:
					toys.add(new Toy((((placingareax*150)+placingx)+80000)-65, ((placingareay*150)+placingy)+1200, 8, 50, 20, 50, placingindex, Color.gray));
					break;
				}
			}
			if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				placing = false;
			}
		}
		if(unlockingarea) {
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				unareasely -= 1;
			}
			if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				unareasely += 1;
			}
			if(e.getKeyCode() == KeyEvent.VK_LEFT) {
				unareaselx -= 1;
			}
			if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
				unareaselx += 1;
			}
			if(e.getKeyCode() == KeyEvent.VK_C) {
				placing = true;
				placingindex = 0;
				placingx = 100;
				placingy = 45;
				placingareax = unareaselx;
				placingareay = unareasely;
				unlockingarea = false;
			}
			if(e.getKeyCode() == KeyEvent.VK_0) {
				unareaseltype = 0;
			}
			if(e.getKeyCode() == KeyEvent.VK_1) {
				unareaseltype = 1;
			}
			if(e.getKeyCode() == KeyEvent.VK_2) {
				unareaseltype = 2;
			}
		}
		
		if(e.getKeyCode() == KeyEvent.VK_M) {
			if(inshop) {
				MoveTo(1200,1200,300);
			}else {
				MoveTo(80000,1200,80);
			}
			inshop = !inshop;
		}
		if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
			System.exit(0);
		if(e.getKeyCode() == KeyEvent.VK_F) {
			fpressed = true;
		}
		if(placing) {
			if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
				placingindex++;
			}
			if(e.getKeyCode() == KeyEvent.VK_LEFT) {
				placingindex--;
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_U) {
			unlockingarea = !unlockingarea;
		}
	}

	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_W)
			Keys[0] = false;
		if(e.getKeyCode() == KeyEvent.VK_A)
			Keys[1] = false;
		if(e.getKeyCode() == KeyEvent.VK_S)
			Keys[2] = false;
		if(e.getKeyCode() == KeyEvent.VK_D)
			Keys[3] = false;
		if(e.getKeyCode() == KeyEvent.VK_F) {
			fpressed = false;
		}
	}

	public void keyTyped(KeyEvent e) {
	}

	public void mouseDragged(MouseEvent arg0) {
		MouseMovement(arg0.getX(), arg0.getY());
		MouseX = arg0.getX();
		MouseY = arg0.getY();
		CenterMouse();
	}
	
	public void mouseMoved(MouseEvent arg0) {
		MouseMovement(arg0.getX(), arg0.getY());
		MouseX = arg0.getX();
		MouseY = arg0.getY();
		CenterMouse();
	}
	
	public void mouseClicked(MouseEvent arg0) {
	}

	public void mouseEntered(MouseEvent arg0) {
	}

	public void mouseExited(MouseEvent arg0) {
	}

	public void mousePressed(MouseEvent arg0) {
		mp = true;
	}

	public void mouseReleased(MouseEvent arg0) {
		mp = false;
	}

	public void mouseWheelMoved(MouseWheelEvent arg0) {
		if(arg0.getUnitsToScroll()>0)
		{
			if(zoom > MinZoom)
				zoom -= 25 * arg0.getUnitsToScroll();
		}
		else
		{
			if(zoom < MaxZoom)
				zoom -= 25 * arg0.getUnitsToScroll();
		}	
	}
	
	public void unlockarea(int x, int y, byte type) {
		unareax.add(x);
		unareay.add(y);
		unareatype.add(type);
		switch(type) {
		case 0:
			Cubes.add(new Cube(80000+(x*150), 1200+(y*150), 8, 50, 50, 5, Color.gray));
			Cubes.add(new Cube(80050+(x*150), 1200+(y*150), 8, 50, 50, 5, Color.gray));
			Cubes.add(new Cube(80100+(x*150), 1200+(y*150), 8, 50, 50, 5, Color.gray));
			Cubes.add(new Cube(80000+(x*150), 1250+(y*150), 8, 50, 50, 5, Color.gray));
			Cubes.add(new Cube(80050+(x*150), 1250+(y*150), 8, 50, 50, 5, Color.gray));
			Cubes.add(new Cube(80100+(x*150), 1250+(y*150), 8, 50, 50, 5, Color.gray));
			Cubes.add(new Cube(80000+(x*150), 1300+(y*150), 8, 50, 50, 5, Color.gray));
			Cubes.add(new Cube(80050+(x*150), 1300+(y*150), 8, 50, 50, 5, Color.gray));
			Cubes.add(new Cube(80100+(x*150), 1300+(y*150), 8, 50, 50, 5, Color.gray));
			break;
		case 1:
			Cubes.add(new Cube(80000+(x*150), 1200+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Cubes.add(new Cube(80050+(x*150), 1200+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Cubes.add(new Cube(80100+(x*150), 1200+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Cubes.add(new Cube(80000+(x*150), 1250+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Cubes.add(new Cube(80050+(x*150), 1250+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Cubes.add(new Cube(80100+(x*150), 1250+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Cubes.add(new Cube(80000+(x*150), 1300+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Cubes.add(new Cube(80050+(x*150), 1300+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Cubes.add(new Cube(80100+(x*150), 1300+(y*150), 8, 50, 50, 5, new Color(60,60,0)));
			Random random = new Random();
			tables.add(new Table(80050+(x*150), 1225+(y*150), 8, random.nextInt(2000000)));
			Random random2 = new Random();
			tables.add(new Table(80050+(x*150), 1300+(y*150), 8, random2.nextInt(2000000)));
			break;
		case 2:
			Cubes.add(new Cube(80000+(x*150), 1200+(y*150), 8, 50, 50, 5, Color.green));
			Cubes.add(new Cube(80050+(x*150), 1200+(y*150), 8, 50, 50, 5, Color.cyan));
			Cubes.add(new Cube(80100+(x*150), 1200+(y*150), 8, 50, 50, 5, Color.green));
			Cubes.add(new Cube(80000+(x*150), 1250+(y*150), 8, 50, 50, 5, Color.cyan));
			Cubes.add(new Cube(80050+(x*150), 1250+(y*150), 8, 50, 50, 5, Color.cyan));
			Cubes.add(new Cube(80100+(x*150), 1250+(y*150), 8, 50, 50, 5, Color.cyan));
			Cubes.add(new Cube(80000+(x*150), 1300+(y*150), 8, 50, 50, 5, Color.green));
			Cubes.add(new Cube(80050+(x*150), 1300+(y*150), 8, 50, 50, 5, Color.cyan));
			Cubes.add(new Cube(80100+(x*150), 1300+(y*150), 8, 50, 50, 5, Color.green));
			break;
		}
	}
}
