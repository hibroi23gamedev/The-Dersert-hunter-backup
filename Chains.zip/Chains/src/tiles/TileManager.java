package tiles;

public class TileManager {
	public static int tileSize = 48;
	public static int length = 300;
	public static Tile[][] tiles = new Tile[length][length];
}
