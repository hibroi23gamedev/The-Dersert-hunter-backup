package particles;

import java.util.Random;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;
import render.DisplayManager;

public class ParticleSystem {
   private float pps;
   private float averageSpeed;
   private float gravityComplient;
   private float averageLifeLength;
   private float averageScale;
   private float speedError;
   private float lifeError;
   private float scaleError = 0.0F;
   private boolean randomRotation = false;
   private Vector3f direction;
   private float directionDeviation = 0.0F;
   private ParticleTexture texture;
   private Random random = new Random();

   public ParticleSystem(ParticleTexture texture, float pps, float speed, float gravityComplient, float lifeLength, float scale) {
      this.pps = pps;
      this.averageSpeed = speed;
      this.gravityComplient = gravityComplient;
      this.averageLifeLength = lifeLength;
      this.averageScale = scale;
      this.texture = texture;
   }

   public void setDirection(Vector3f direction, float deviation) {
      this.direction = new Vector3f(direction);
      this.directionDeviation = (float)((double)deviation * 3.141592653589793D);
   }

   public void randomizeRotation() {
      this.randomRotation = true;
   }

   public void setSpeedError(float error) {
      this.speedError = error * this.averageSpeed;
   }

   public void setLifeError(float error) {
      this.lifeError = error * this.averageLifeLength;
   }

   public void setScaleError(float error) {
      this.scaleError = error * this.averageScale;
   }

   public void generateParticles(Vector3f systemCenter) {
      float delta = (float)DisplayManager.getFrameTimeSeconds();
      float particlesToCreate = this.pps * delta;
      int count = (int)Math.floor((double)particlesToCreate);
      float partialParticle = particlesToCreate % 1.0F;

      for(int i = 0; i < count; ++i) {
         this.emitParticle(systemCenter);
      }

      if (Math.random() < (double)partialParticle) {
         this.emitParticle(systemCenter);
      }

   }

   private void emitParticle(Vector3f center) {
      Vector3f velocity = null;
      if (this.direction != null) {
         velocity = generateRandomUnitVectorWithinCone(this.direction, this.directionDeviation);
      } else {
         velocity = this.generateRandomUnitVector();
      }

      velocity.normalise();
      velocity.scale(this.generateValue(this.averageSpeed, this.speedError));
      float scale = this.generateValue(this.averageScale, this.scaleError);
      float lifeLength = this.generateValue(this.averageLifeLength, this.lifeError);
      new Particle(this.texture, new Vector3f(center), velocity, this.gravityComplient, lifeLength, this.generateRotation(), scale);
   }

   private float generateValue(float average, float errorMargin) {
      float offset = (this.random.nextFloat() - 0.5F) * 2.0F * errorMargin;
      return average + offset;
   }

   private float generateRotation() {
      return this.randomRotation ? this.random.nextFloat() * 360.0F : 0.0F;
   }

   private static Vector3f generateRandomUnitVectorWithinCone(Vector3f coneDirection, float angle) {
      float cosAngle = (float)Math.cos((double)angle);
      Random random = new Random();
      float theta = (float)((double)(random.nextFloat() * 2.0F) * 3.141592653589793D);
      float z = cosAngle + random.nextFloat() * (1.0F - cosAngle);
      float rootOneMinusZSquared = (float)Math.sqrt((double)(1.0F - z * z));
      float x = (float)((double)rootOneMinusZSquared * Math.cos((double)theta));
      float y = (float)((double)rootOneMinusZSquared * Math.sin((double)theta));
      Vector4f direction = new Vector4f(x, y, z, 1.0F);
      if (coneDirection.x == 0.0F && coneDirection.y == 0.0F && (coneDirection.z == 1.0F || coneDirection.z == -1.0F)) {
         if (coneDirection.z == -1.0F) {
            direction.z *= -1.0F;
         }
      } else {
         Vector3f rotateAxis = Vector3f.cross(coneDirection, new Vector3f(0.0F, 0.0F, 1.0F), (Vector3f)null);
         rotateAxis.normalise();
         float rotateAngle = (float)Math.acos((double)Vector3f.dot(coneDirection, new Vector3f(0.0F, 0.0F, 1.0F)));
         Matrix4f rotationMatrix = new Matrix4f();
         rotationMatrix.rotate(-rotateAngle, rotateAxis);
         Matrix4f.transform(rotationMatrix, direction, direction);
      }

      return new Vector3f(direction);
   }

   private Vector3f generateRandomUnitVector() {
      float theta = (float)((double)(this.random.nextFloat() * 2.0F) * 3.141592653589793D);
      float z = this.random.nextFloat() * 2.0F - 1.0F;
      float rootOneMinusZSquared = (float)Math.sqrt((double)(1.0F - z * z));
      float x = (float)((double)rootOneMinusZSquared * Math.cos((double)theta));
      float y = (float)((double)rootOneMinusZSquared * Math.sin((double)theta));
      return new Vector3f(x, y, z);
   }
}
