package guis;

import java.util.Iterator;
import java.util.List;
import models.RawModel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Matrix4f;
import render.Loader;
import toolbox.Maths;

public class GuiRenderer {
   private final RawModel quad;
   private GuiShader shader;

   public GuiRenderer(Loader loader) {
      float[] positions = new float[]{-1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, 1.0F, -1.0F};
      this.quad = loader.loadToVAO(positions, 2, null);
      this.shader = new GuiShader();
   }

   public void render(List<GuiTexture> guis) {
      this.shader.start();
      GL30.glBindVertexArray(this.quad.getVaoID());
      GL20.glEnableVertexAttribArray(0);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(2929);
      Iterator var3 = guis.iterator();

      while(var3.hasNext()) {
         GuiTexture gui = (GuiTexture)var3.next();
         GL13.glActiveTexture(33984);
         GL11.glBindTexture(3553, gui.getTexture());
         Matrix4f matrix = Maths.createTransformationMatrix(gui.getPostiion(), gui.getScale());
         this.shader.loadTransformation(matrix);
         GL11.glDrawArrays(5, 0, this.quad.getVertexCount());
      }

      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GL20.glDisableVertexAttribArray(0);
      GL30.glBindVertexArray(0);
      this.shader.stop();
   }

   public void cleanUp() {
      this.shader.cleanUp();
   }

    //public void render(List<GuiButton> placement_guis) {
    //	
    //}
}
