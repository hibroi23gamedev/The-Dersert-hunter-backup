package items;

import java.awt.Graphics;
import java.awt.MouseInfo;

import draw.Image;
import draw.Light;
import entities.Entity;
import main.GamePanel;

public abstract class Item extends Entity{
	
	public Item(int x, int y, int z) {
		super(x, y, z);
	}
	
	public String name;
	public int id;
	public Image img;
	public Image outLineimg;
	
	public boolean hasOutline = false;
	
	public abstract void onPickup();
	
	@Override
	public void update(GamePanel gp) {
		int mouseX = MouseInfo.getPointerInfo().getLocation().x - GamePanel.frame.getLocation().x;
		int mouseY = MouseInfo.getPointerInfo().getLocation().y - GamePanel.frame.getLocation().y;
		int relativeX = mouseX+GamePanel.camX;
		int relativeY = mouseY+GamePanel.camY;
		//System.out.println("X: "+gp.player.x+"| Y: "+gp.player.y+"| THIS.X: "+relativeX+"| THIS.Y: "+relativeY);
		//System.out.println(x > gp.player.x);
		if(x-img.width < relativeX && y-img.height < relativeY && x+img.width > relativeX && y+img.height > relativeY) {
			if(gp.mouseClicked) {
				this.id = -1;
				onPickup();
			}
			hasOutline = true;
		}else {
			hasOutline = false;
		}
	}
	
	@Override
	public void draw(Graphics g, Light light) {
		img.draw(g, light);
		if(hasOutline) {
			outLineimg.draw(g, light);
		}
	}
}
