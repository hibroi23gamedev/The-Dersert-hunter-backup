package me.thepoitionhunter.extra;
import java.util.Random;

public class SuperRain {
	Random random = new Random();
	public int X = random.nextInt(1000);
	public int Y = 0;
}
