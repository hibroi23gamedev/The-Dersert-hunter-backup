package particles;

import org.lwjgl.util.vector.Matrix4f;
import shaders.ShaderProgram;

public class ParticleShader extends ShaderProgram {
   private static final String VERTEX_FILE = "/particles/particleVShader.txt";
   private static final String FRAGMENT_FILE = "/particles/particleFShader.txt";
   private int location_numberOfRows;
   private int location_projectionMatrix;

   public ParticleShader() {
      super("/particles/particleVShader.txt", "/particles/particleFShader.txt");
   }

   protected void getAllUniformLocations() {
      this.location_numberOfRows = super.getUniformLocation("numberOfRows");
      this.location_projectionMatrix = super.getUniformLocation("projectionMatrix");
   }

   protected void bindATTR() {
      super.bindATTR(0, "position");
      super.bindATTR(1, "modelViewMatrix");
      super.bindATTR(5, "texOffset");
      super.bindATTR(6, "blend");
   }

   protected void loadNumberOfRows(float numberOfRows) {
      super.loadFloat(this.location_numberOfRows, numberOfRows);
   }

   protected void loadProjectionMatrix(Matrix4f projectionMatrix) {
      super.loadMatrix(this.location_projectionMatrix, projectionMatrix);
   }
}
