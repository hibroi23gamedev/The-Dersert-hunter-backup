package entitys;

import models.TexturedModel;
import render.Loader;
import render.ModelData;

import java.util.ArrayList;

import org.lwjgl.util.vector.Vector3f;

import engineTester.MainGameLoop;
import terrains.Terrain;

import extra.Rig;

import java.util.Random;

public class Tree extends Entity{
   public ArrayList<Rig> tree_blocks = new ArrayList<Rig>();
   
   public ArrayList<Float> tree_int = new ArrayList<Float>();
   public ArrayList<Float> tree_intx = new ArrayList<Float>();
   public ArrayList<Float> tree_intz = new ArrayList<Float>();
   public ArrayList<Float> tree_intd = new ArrayList<Float>();
   public ArrayList<Boolean> tree_start = new ArrayList<Boolean>();
   public int last_tree_index_model = -1;
   
   int tree_max = 30;
   int tree_index = 0;
   
   int tree_brach;
   int tree_brach_f;
   
   public int health = 300;

   public Tree(TexturedModel model, Vector3f position, float rotX, float rotY, float rotZ, float scale) {
	  super(model, position, rotX, rotY, rotZ, scale);
      super.position = position;
      this.rotX = rotX;
      this.rotY = rotY;
      this.rotZ = rotZ;
      super.scale = scale;
      tree_int.add(0f);
      tree_intx.add(0f);
      tree_intz.add(0f);
      tree_intd.add(5f);
      tree_start.add(true);
      
      Random random = new Random();
      tree_brach = random.nextInt(13)+2;
      tree_brach_f = tree_brach + random.nextInt(4)+2;
      
      tree_max = random.nextInt(10)+30;
      //tree_max = 1020;
      
      updateModelPositionandDirection();
   }
   
   public void updateModelPositionandDirection() {
	   for(int i = 0; i < tree_blocks.size(); i++) {
		   tree_blocks.get(i).position.z = position.getX()+tree_blocks.get(i).offset.x;
		   tree_blocks.get(i).position.y = position.getY()+tree_blocks.get(i).offset.y;
		   tree_blocks.get(i).position.x = position.getZ()+tree_blocks.get(i).offset.z;
		   
		   tree_blocks.get(i).rotation.x = rotX + tree_blocks.get(i).or_rotation.x;
		   tree_blocks.get(i).rotation.y = rotY + tree_blocks.get(i).or_rotation.y;
		   tree_blocks.get(i).rotation.z = rotZ + tree_blocks.get(i).or_rotation.z;
	   }
   }
   
   public void increasePosition(float dx, float dy, float dz) {
      Vector3f var10000 = this.position;
      var10000.x += dx;
      var10000 = this.position;
      var10000.y += dy;
      var10000 = this.position;
      var10000.z += dz;
      updateModelPositionandDirection();
   }
   
   public void slizeTree(int y) {
	   for(int i = 0; i < tree_blocks.size(); i++) {
		   if(tree_blocks.get(i).offset.y > y) {
			   Rig rig = tree_blocks.get(i);
			   Random random = new Random();
			   if(random.nextInt(5) == 0) {
				   MainGameLoop.pickup.add(new Entity(tree_blocks.get(i).model, new Vector3f(rig.position.x, rig.position.y, rig.position.z), rig.rotation.x,
						   rig.rotation.y, rig.rotation.z, tree_blocks.get(i).scale));
				   if(rig.type == 0) {
					   MainGameLoop.pickup_inv.add(4);
				   }else {
					   MainGameLoop.pickup_inv.add(5);
				   }
				   MainGameLoop.pickup_phy.add(true);
			   }
			   tree_blocks.remove(i);
		   }
	   }
   }
   
   public void grow_rig_tree(TexturedModel[] models) {
	   
	   if(tree_index < tree_max) {
		   Random random = new Random();
		   if(random.nextInt(2) == 0) {
			   //rigs.add(new Rig(model, new Vector3f(-1f, tree_int, 0), new Vector3f(position.x, position.y, position.z), 0.4f, new Vector3f(90, 0, 0)));
		   }
		   //rigs.add(new Rig(models[0], new Vector3f(tree_intx, tree_int, tree_intz), new Vector3f(position.x, position.y, position.z), 1, new Vector3f(0, 0, 0)));
		   float effect = 0.5f;
		   for(int i = 0; i < tree_int.size(); i++) {
			   Random random3 = new Random();
			   int model_index = 0;
			   int type = 0;
			   if(random3.nextInt(2) == 0 && !tree_start.get(i)) {
				   model_index = 4;
			   }else {
				   if(last_tree_index_model != -1 && !tree_start.get(i)) {
					   if(tree_blocks.get(last_tree_index_model-1).position.y < tree_blocks.get(i).position.y) {
						   model_index = 3;
					   }else if(tree_blocks.get(last_tree_index_model-1).position.y > tree_blocks.get(i).position.y) {
						   model_index = 2;
					   }
				   }
				   if(tree_start.get(i)) {
					   model_index = 0;
				   }
			   }
			   if(model_index == 4) {
				   type = 1;
			   }
			   if(i != 0) {
				   if(tree_intd.get(i) == 0) {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 0.7f, new Vector3f(90, 0, 90), type));
					   last_tree_index_model = tree_blocks.size();
				   }else if(tree_intd.get(i) == 1) {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 0.7f, new Vector3f(90, 0, 180), type));
					   last_tree_index_model = tree_blocks.size();
				   }else if(tree_intd.get(i) == 2) {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 0.7f, new Vector3f(90, 0, 270), type));
					   last_tree_index_model = tree_blocks.size();
				   }else if(tree_intd.get(i) == 3) {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 0.7f, new Vector3f(90, 0, 0), type));
					   last_tree_index_model = tree_blocks.size();
				   }else {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 0.7f, new Vector3f(0, 0, 0), type));
					   last_tree_index_model = tree_blocks.size();
				   }
			   }else {
				   if(tree_intd.get(i) == 0) {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 1f, new Vector3f(90, 0, 90), type));
					   last_tree_index_model = tree_blocks.size();
				   }else if(tree_intd.get(i) == 1) {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 1f, new Vector3f(90, 0, 180), type));
					   last_tree_index_model = tree_blocks.size();
				   }else if(tree_intd.get(i) == 2) {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 1f, new Vector3f(90, 0, 270), type));
					   last_tree_index_model = tree_blocks.size();
				   }else if(tree_intd.get(i) == 3) {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 1f, new Vector3f(90, 0, 0), type));
					   last_tree_index_model = tree_blocks.size();
				   }else {
					   tree_blocks.add(new Rig(models[model_index], new Vector3f(tree_intx.get(i), tree_int.get(i), tree_intz.get(i)), 
							   new Vector3f(position.x, position.y, position.z), 1f, new Vector3f(0, 0, 0), type));
					   last_tree_index_model = tree_blocks.size();
				   }
			   }
			   if(tree_start.get(i)) {
				   tree_int.set(i, (tree_int.get(i)+0.312f));
			   }else {
				   Random random2 = new Random();
				   int divide = 3;
				   if(tree_intd.get(i) == 0) {
					   tree_int.set(i, (tree_int.get(i) + random2.nextFloat()/divide));
					   tree_intx.set(i, (tree_intx.get(i) + effect));
					   tree_intz.set(i, (tree_intz.get(i)));
				   }else if(tree_intd.get(i) == 1) {
					   tree_int.set(i, (tree_int.get(i) + random2.nextFloat()/divide));
					   tree_intx.set(i, (tree_intx.get(i) - effect));
					   tree_intz.set(i, (tree_intz.get(i)));
				   }else if(tree_intd.get(i) == 2) {
					   tree_int.set(i, (tree_int.get(i) + random2.nextFloat()/divide));
					   tree_intx.set(i, (tree_intx.get(i)));
					   tree_intz.set(i, (tree_intz.get(i) + effect));
				   }else if(tree_intd.get(i) == 3) {
					   tree_int.set(i, (tree_int.get(i) + random2.nextFloat()/divide));
					   tree_intx.set(i, (tree_intx.get(i)));
					   tree_intz.set(i, (tree_intz.get(i) - effect));
				   }else if(tree_intd.get(i) == 5) {
					   tree_int.set(i, (tree_int.get(i)+0.312f));
					   tree_intx.set(i, (tree_intx.get(i)));
					   tree_intz.set(i, (tree_intz.get(i)));
				   }
			   }
			   int randomamount = tree_brach;
			   if(i != 0) {
				   randomamount = tree_brach_f;
			   }
			   if(tree_index < 9) {
				   randomamount = 2000000;
			   }
			   int randoma = random.nextInt(randomamount);
			   int rand2 = randoma-(randoma*2);
			   if(rand2 == 0) {
				   tree_int.add(tree_int.get(i)+0);
				   
				   int rand = random.nextInt(5);
				   
				   if(rand == 4) {
					   tree_intd.add(5f);
				   }else {
					   tree_intd.add((float) rand);
				   }
				   
				   switch(rand) {
				   case 0:
					   tree_intx.add(tree_intx.get(i) + effect);
					   tree_intz.add(tree_intz.get(i));
					   tree_start.add(false);
					   break;
				   case 1:
					   tree_intx.add(tree_intx.get(i) - effect);
					   tree_intz.add(tree_intz.get(i));
					   tree_start.add(false);
					   break;
				   case 2:
					   tree_intx.add(tree_intx.get(i));
					   tree_intz.add(tree_intz.get(i) + effect);
					   tree_start.add(false);
					   break;
				   case 3:
					   tree_intx.add(tree_intx.get(i));
					   tree_intz.add(tree_intz.get(i) - effect);
					   tree_start.add(false);
					   break;
				   case 4:
					   tree_intx.add(tree_intx.get(i));
					   tree_intz.add(tree_intz.get(i));
					   tree_start.add(true);
					   break;
				   }
			   }
		   }
		   tree_index += 1;
	   }
	   
	   updateModelPositionandDirection();
   }

   public void increaseRotation(float dx, float dy, float dz) {
      this.rotX += dx;
      this.rotY += dy;
      this.rotZ += dz;
      updateModelPositionandDirection();
   }

   public Vector3f getPosition() {
	     updateModelPositionandDirection();
      return this.position;
   }

   public void setPosition(Vector3f position) {
      this.position = position;
      updateModelPositionandDirection();
   }

   public float getRotX() {
	  updateModelPositionandDirection();
      return this.rotX;
   }

   public void setRotX(float rotX) {
      this.rotX = rotX;
      updateModelPositionandDirection();
   }

   public float getRotY() {
	  updateModelPositionandDirection();
      return this.rotY;
   }

   public void setRotY(float rotY) {
      this.rotY = rotY;
      updateModelPositionandDirection();
   }

   public float getRotZ() {
	  updateModelPositionandDirection();
      return this.rotZ;
   }

   public void setRotZ(float rotZ) {
      this.rotZ = rotZ;
      updateModelPositionandDirection();
   }

   public float getScale() {
      return this.scale;
   }

   public void setScale(float scale) {
      this.scale = scale;
   }
}
