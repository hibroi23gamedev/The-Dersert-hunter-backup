package engineTester;

import audio.AudioMaster;
import audio.Source;
import entitys.Animal;
import entitys.Camera;
import entitys.Entity;
import entitys.Light;
import entitys.Player;
import entitys.Sheep;
import extra.Crafting_Recipe;
import extra.ItemGroup;
import extra.ItemL;
import extra.*;
import extra_entity_types.AntiFact;
import fontMeshCreator.FontType;
import fontMeshCreator.GUIText;
import fontRendering.TextMaster;
import guis.GuiButton;
import guis.GuiRenderer;
import guis.GuiTexture;
import items.Item;
import items.ItemPro;
import items.SuperItem;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import models.RawModel;
import models.TexturedModel;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.openal.AL10;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import particles.ParticleMaster;
import postProcessing.Fbo;
import postProcessing.PostProcessing;
import render.DisplayManager;
import render.Loader;
import render.MasterRenderer;
import render.ModelData;
import render.OBJFileLoader;
import terrains.Terrain;
import textures.ModelTexture;
import textures.TerrainTexture;
import textures.TerrainTexturePack;
import toolbox.MouseRay;
import water.WaterFrameBuffers;
import water.WaterRenderer;
import water.WaterShader;
import water.WaterTile;

import extra_entity_types.*;

public class MainGameLoop {
   static int inventorysel = 0;
   public static ArrayList<Entity> entities = new ArrayList();
   public static Light light = new Light(new Vector3f(1000000.0F, 1500000.0F, -1000000.0F), new Vector3f(1.0F, 1.0F, 1.0F));
   public static boolean blood_moon = false;
   static boolean shadows = true;
   public static List<GuiTexture> guis = new ArrayList();
   public static SuperItem itemmanager = new SuperItem();
   
   public static int mapSize = 100;
   public static int tileSize = 2;
   public static Tile[][] tiles = new Tile[mapSize][mapSize];


   public static void main(String[] args) {
      boolean usingitem = false;
      boolean placing = false;
      int placing_index = 0;
      int usingitemtime = 0;
      short craftcount = 0;
      //AudioMaster.init();
      //AudioMaster.setListenerData(0.0F, 0.0F, 0.0F);
      //AL10.alDistanceModel(53252);
      //int buffer = AudioMaster.loadSound("audio/bounce.wav");
      //Source source = new Source();
      //source.setLooping(true);
      //source.play(buffer);
      //source.setPosition(0.0F, 0.0F, 0.0F);
      ArrayList<Integer> crafted = new ArrayList();
      ArrayList<Integer> crafted_type = new ArrayList();
      ArrayList<Crafting_Recipe> crafting = new ArrayList();
      DisplayManager.createDisplay();
      ArrayList<Entity> floor = new ArrayList();
      ArrayList<AntiFact> antifacts = new ArrayList();
      List<Light> lights = new ArrayList();
      Loader loader = new Loader();
      TextMaster.init(loader);
      ModelData data = OBJFileLoader.loadOBJ("grass06");
      RawModel model = loader.loadtoVAO(data.getVertices(), data.getTextureCoords(), data.getNormals(), data.getIndices(), data);
      ModelTexture texture = new ModelTexture(loader.loadTexture("grassTexture"));
      TerrainTexture backtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backrtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backgtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backbtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexturePack texturepack = new TerrainTexturePack(backtexture, backrtexture, backgtexture, backbtexture);
      TerrainTexture blendMap = new TerrainTexture(loader.loadTexture("blend_map"));
      texture.setHasTransparency(true);
      texture.setShineDamper(10.0F);
      texture.setRfi(0.0F);
      texture.setUseFakeLighting(true);
      GuiTexture gui3 = new GuiTexture(loader.loadTexture("health_bar"), new Vector2f(-0.7F, -0.75F), new Vector2f(0.15F, 0.03F));
      GuiTexture gui2 = new GuiTexture(loader.loadTexture("health_outline"), new Vector2f(-0.66F, -0.75F), new Vector2f(0.19F, 0.03F));
      GuiTexture gui = new GuiTexture(loader.loadTexture("heart"), new Vector2f(-0.85F, -0.75F), new Vector2f(0.07F, 0.13F));
      int sinecounter = 0;
      int inv = loader.loadTexture("inventory");
      int invs = loader.loadTexture("inventory_sel");
      int trans = loader.loadTexture("transparent");
      FontType font = new FontType(loader.loadTexture("segoe"), new File("res/segoe.fnt"));
      new GUIText("HELLO", 1.0F, font, new Vector2f(0.2F, 0.2F), 0.2F, true);
      ModelData data2 = OBJFileLoader.loadOBJ("fern");
      RawModel model2 = loader.loadtoVAO(data2.getVertices(), data2.getTextureCoords(), data2.getNormals(), data2.getIndices(), data2);
      ModelTexture texture2 = new ModelTexture(loader.loadTexture("fern"));
      texture.setHasTransparency(true);
      texture.setShineDamper(10.0F);
      texture.setRfi(0.0F);
      texture.setUseFakeLighting(true);
      Crafting_Recipe med_kit_craft = new Crafting_Recipe();
      med_kit_craft.recipe = new int[2];
      med_kit_craft.recipe[0] = 2;
      med_kit_craft.recipe[1] = 3;
      med_kit_craft.crafted = 1;
      crafting.add(med_kit_craft);
      GuiRenderer guiRenderer = new GuiRenderer(loader);
      TexturedModel texturedModel = new TexturedModel(model, texture);
      TexturedModel texturedfern = new TexturedModel(model2, texture2);
      Entity entity = new Entity(texturedModel, new Vector3f(80.0F, 0.0F, 50.0F), 0.0F, 180.0F, 0.5F, 1.0F);
      Entity entity2 = new Entity(texturedfern, new Vector3f(80.0F, 0.0F, 50.0F), 0.0F, 180.0F, 0.5F, 0.2F);
      lights.add(light);
      Terrain terrain = new Terrain(0, 0, loader, texturepack, blendMap, "heightmap");
      ModelData playerm = OBJFileLoader.loadOBJ("person");
      RawModel playermm = loader.loadtoVAO(playerm.getVertices(), playerm.getTextureCoords(), playerm.getNormals(), playerm.getIndices(), playerm);
      TexturedModel playert = new TexturedModel(playermm, new ModelTexture(loader.loadTexture("person")));
      Player player = new Player(playert, new Vector3f(140.0F, terrain.getHeightOfTerrain(140.0F, 140.0F) + 4.0F, 140.0F), 0.0F, 0.0F, 0.0F, 0.3F);
      player.phy = false;
      Camera camera = new Camera(player);
      MasterRenderer renderer = new MasterRenderer(texture2, loader, camera);
      Player phy_player = new Player((TexturedModel)null, new Vector3f(9999.0F, 9999.0F, 9999.0F), 0.0F, 0.0F, 0.0F, 0.0F);
      ModelData data3 = OBJFileLoader.loadOBJ("med_kit_model");
      RawModel model3 = loader.loadtoVAO(data3.getVertices(), data3.getTextureCoords(), data3.getNormals(), data3.getIndices(), data3);
      ModelTexture texture3 = new ModelTexture(loader.loadTexture("med_kit_model"));
      TexturedModel med_kit_model = new TexturedModel(model3, texture3);
      ModelData data9 = OBJFileLoader.loadOBJ("string");
      RawModel model9 = loader.loadtoVAO(data9.getVertices(), data9.getTextureCoords(), data9.getNormals(), data9.getIndices(), data9);
      ModelTexture texture9 = new ModelTexture(loader.loadTexture("med_kit_model"));
      TexturedModel stringmodel = new TexturedModel(model9, texture9);
      new Entity(stringmodel, new Vector3f(140.0F, 30.0F, 140.0F), 0.0F, 0.0F, 0.0F, 5.0F);
      new Entity(med_kit_model, new Vector3f(80.0F, 0.0F, 70.0F), 0.0F, 0.0F, 0.0F, 1.0F);
      ModelData data6 = OBJFileLoader.loadOBJ("cube");
      RawModel model6 = loader.loadtoVAO(data6.getVertices(), data6.getTextureCoords(), data6.getNormals(), data6.getIndices(), data6);
      ModelTexture texture6 = new ModelTexture(loader.loadTexture("f_to_grab"));
      TexturedModel f_to_grab_model = new TexturedModel(model6, texture6);
      Entity f_to_grab = new Entity(f_to_grab_model, new Vector3f(80.0F, -2.0F, 70.0F), 0.0F, 0.0F, 0.0F, 0.1F);
      camera.setPosition(80.0F, 2.5F, 80.0F);
      Random random = new Random();
      
      ModelData resurant_floor_data = OBJFileLoader.loadOBJ("resurant/floor");
      RawModel resurant_floor_model = loader.loadtoVAO(resurant_floor_data.getVertices(), resurant_floor_data.getTextureCoords(), resurant_floor_data.getNormals(), resurant_floor_data.getIndices(), resurant_floor_data);
      ModelTexture resurant_floor_textured = new ModelTexture(loader.loadTexture("placement_texture"));
      TexturedModel resurant_floor_tmodel = new TexturedModel(resurant_floor_model, resurant_floor_textured);
      ModelData resurant_one_data = OBJFileLoader.loadOBJ("resurant/one-wall");
      RawModel resurant_one_model = loader.loadtoVAO(resurant_one_data.getVertices(), resurant_one_data.getTextureCoords(), resurant_one_data.getNormals(), resurant_one_data.getIndices(), resurant_floor_data);
      ModelTexture resurant_one_textured = new ModelTexture(loader.loadTexture("placement_texture"));
      TexturedModel resurant_one_tmodel = new TexturedModel(resurant_one_model, resurant_one_textured);
      ModelData resurant_two_data = OBJFileLoader.loadOBJ("resurant/two-wall");
      RawModel resurant_two_model = loader.loadtoVAO(resurant_two_data.getVertices(), resurant_two_data.getTextureCoords(), resurant_two_data.getNormals(), resurant_two_data.getIndices(), resurant_floor_data);
      ModelTexture resurant_two_textured = new ModelTexture(loader.loadTexture("placement_texture"));
      TexturedModel resurant_two_tmodel = new TexturedModel(resurant_two_model, resurant_two_textured);
      ModelData resurant_three_data = OBJFileLoader.loadOBJ("resurant/three-wall");
      RawModel resurant_three_model = loader.loadtoVAO(resurant_three_data.getVertices(), resurant_three_data.getTextureCoords(), resurant_three_data.getNormals(), resurant_three_data.getIndices(), resurant_floor_data);
      ModelTexture resurant_three_textured = new ModelTexture(loader.loadTexture("placement_texture"));
      TexturedModel resurant_three_tmodel = new TexturedModel(resurant_three_model, resurant_three_textured);
      ModelData resurant_four_data = OBJFileLoader.loadOBJ("resurant/four-wall");
      RawModel resurant_four_model = loader.loadtoVAO(resurant_four_data.getVertices(), resurant_four_data.getTextureCoords(), resurant_four_data.getNormals(), resurant_four_data.getIndices(), resurant_floor_data);
      ModelTexture resurant_four_textured = new ModelTexture(loader.loadTexture("placement_texture"));
      TexturedModel resurant_four_tmodel = new TexturedModel(resurant_four_model, resurant_four_textured);
      
      for(int i = 0; i < random.nextInt(340) + 1500; ++i) {
         Random random2 = new Random();
         Random random3 = new Random();
         Random random4 = new Random();
         int x = random2.nextInt(200) + 10;
         int z = random3.nextInt(200) + 10;
         if (random4.nextInt(4) == 0) {
            floor.add(new Entity(texturedfern, new Vector3f((float)x, terrain.getHeightOfTerrain((float)x, (float)z), (float)z), 0.0F, 180.0F, 0.5F, 0.3F));
         } else {
            floor.add(new Entity(texturedModel, new Vector3f((float)x, terrain.getHeightOfTerrain((float)x, (float)z) + 0.7F, (float)z), 180.0F, 180.0F, 0.0F, 0.9F));
         }
      }
      
      for(int i = 0; i < tiles.length; i++) {
     	 for(int i1 = 0; i1 < tiles.length; i1++) {
     		 tiles[i][i1] = new Tile();
     	 }
      }
      
      tiles[mapSize/2][mapSize/2].type = 1;

      WaterShader waterS = new WaterShader();
      WaterRenderer waterR = new WaterRenderer(loader, waterS, renderer.getProjectionMatrix());
      List<WaterTile> waters = new ArrayList();
      waters.add(new WaterTile(player.getPosition().x, player.getPosition().y - 2.0F, player.getPosition().z));
      WaterFrameBuffers fbos = new WaterFrameBuffers();

      ModelData data7 = OBJFileLoader.loadOBJ("stone");
      RawModel model7 = loader.loadtoVAO(data7.getVertices(), data7.getTextureCoords(), data7.getNormals(), data7.getIndices(), data7);
      ModelTexture texture7 = new ModelTexture(loader.loadTexture("stone"));
      TexturedModel stone_model = new TexturedModel(model7, texture7);
      ItemPro med_kit_pro = new ItemPro();
      med_kit_pro.setHeal(true);
      med_kit_pro.setHealamount(0.07F);
      med_kit_pro.setTimetouse(200);
      med_kit_pro.setIsuseable(true);
      itemmanager.additem("Med Kit", loader.loadTexture("med_kit"), med_kit_pro);
      ItemPro stick_pro = new ItemPro();
      itemmanager.additem("Stick", loader.loadTexture("stick"), stick_pro);
      ItemPro stone_pro = new ItemPro();
      itemmanager.additem("Stone", loader.loadTexture("stone_inv"), stone_pro);
      ItemPro bark_pro = new ItemPro();
      itemmanager.additem("Bark", loader.loadTexture("bark"), bark_pro);
      ItemPro leaf_pro = new ItemPro();
      itemmanager.additem("Leaf", loader.loadTexture("leaf"), leaf_pro);
      ItemPro axe_pro = new ItemPro();
      itemmanager.additem("Basic Axe", loader.loadTexture("axe"), axe_pro);
      ItemPro anti_covers_pro = new ItemPro();
      itemmanager.additem("Anti Cover", loader.loadTexture("anti_cover"), anti_covers_pro);
      ParticleMaster.init(loader, renderer.getProjectionMatrix());

      Fbo multisampleFbo = new Fbo(Display.getWidth(), Display.getHeight(), 2);
      new Fbo(Display.getWidth(), Display.getHeight(), 1);
      PostProcessing.init(loader);

      while(!Display.isCloseRequested()) {
         guis.clear();
         MouseRay.findmousepos(camera, terrain);
         if (shadows) {
            entities.clear();

            for(int i = 0; i < floor.size(); ++i) {
               entities.add((Entity)floor.get(i));
            }

            entities.add(player);
         }

         ++craftcount;
         ++sinecounter;
         if (sinecounter > 360) {
            sinecounter = 0;
         }
         ParticleMaster.update(camera);
         renderer.renderShadowMap(entities, light);
         f_to_grab.rotY = (float)((double)f_to_grab.rotY + 0.5D);
         if ((double)player.health > 0.15D) {
            player.health = 0.15F;
         }

         for(int i = 0; i < antifacts.size(); ++i) {
            antifacts.get(i).update(terrain, renderer, player, camera);
            renderer.processEntity((Entity)antifacts.get(i));
         }
         
         for(int i = 0; i < tiles.length; i++) {
        	 for(int i1 = 0; i1 < tiles.length; i1++) {
        		 if(tiles[i][i1].type == 1) {
        			 int how_many_around = 0;
        			 int[] ones_around = new int[4];
        			 if(tiles[i-1][i1].type == 1) {
        				 how_many_around++;
        				 ones_around[0] = 1;
        			 }if(tiles[i+1][i1].type == 1) {
        				 how_many_around++;
        				 ones_around[1] = 1;
        			 }if(tiles[i][i1-1].type == 1) {
        				 how_many_around++;
        				 ones_around[2] = 1;
        			 }if(tiles[i][i1+1].type == 1) {
        				 how_many_around++;
        				 ones_around[3] = 1;
        			 }
        			 TexturedModel resurant_model = resurant_floor_tmodel;
        			 if(how_many_around == 3) {
        				resurant_model = resurant_one_tmodel;
        			 }if(how_many_around == 2) {
         				resurant_model = resurant_two_tmodel;
         			 }if(how_many_around == 1) {
         				resurant_model = resurant_three_tmodel;
         			 }if(how_many_around == 0) {
         				resurant_model = resurant_four_tmodel;
         			 }
        			 Entity resurant_part = new Entity(resurant_model, new Vector3f(i*tileSize, 0, i1*tileSize), 0, 0, 0, tileSize/2);
        			 renderer.processEntity(resurant_part);
        		 }
        	 }
         }
         
         //renderer.processEntity(truck);
         checkInvInputs();
         renderer.processTerrain(terrain);
         renderer.processEntity(entity);
         renderer.processEntity(entity2);
         player.move(terrain, loader, camera);
         player.processPhysics(terrain, phy_player, false, renderer);

         renderer.processEntity((Entity)player);
         if (Keyboard.isKeyDown(34)) {
            player.phy = !player.phy;
         }

         for(int i = 0; i < crafted.size(); ++i) {
         }

         for(int i = 0; i < ((Crafting_Recipe)crafting.get(0)).recipe.length; ++i) {
         }

         for(int i = 0; i < floor.size(); ++i) {
            renderer.processEntity((Entity)floor.get(i));
         }

         fbos.bindReflectionFrameBuffer();
         multisampleFbo.bindFrameBuffer();
         renderer.render(lights, camera);
         fbos.unbindCurrentFrameBuffer();
         ParticleMaster.renderParticles(camera);
         waterR.render(waters, camera);
         multisampleFbo.unbindFrameBuffer();
         PostProcessing.doPostProcessing(multisampleFbo.getColourTexture());
         guiRenderer.render(guis);
         gui3.getScale().x = player.health * 0.6F;
         TextMaster.render();
         DisplayManager.updateDisplay();
      }

      multisampleFbo.cleanUp();
      guiRenderer.cleanUp();
      renderer.cleanUp();
      loader.cleanUp();
      ParticleMaster.cleanUp();
      waterS.cleanUp();
      fbos.cleanUp();
      TextMaster.cleanUp();
      PostProcessing.cleanUp();
      //source.delete();
      //AudioMaster.cleanUp();
      DisplayManager.closeDisplay();
   }

   public static Vector2f mousePosition() {
      float mx = 2.0F * (float)Mouse.getX() / (float)Display.getWidth() - 1.0F;
      float my = 2.0F * (float)Mouse.getY() / (float)Display.getHeight() - 1.0F;
      return new Vector2f(mx, my);
   }

   public static void checkInvInputs() {
      if (Keyboard.isKeyDown(2)) {
         inventorysel = 0;
      }

      if (Keyboard.isKeyDown(3)) {
         inventorysel = 1;
      }

      if (Keyboard.isKeyDown(4)) {
         inventorysel = 2;
      }

      if (Keyboard.isKeyDown(5)) {
         inventorysel = 3;
      }

      if (Keyboard.isKeyDown(6)) {
         inventorysel = 4;
      }

   }

   public static boolean isInRange(Vector3f position1, Vector3f position2, float rangex, float rangey, float rangez) {
      return position1.x - rangex < position2.x && position1.x + rangex > position2.x && position1.z - rangez < position2.z && position1.z + rangez > position2.z && position1.y - rangey < position2.y && position1.y + rangey > position2.y;
   }
}