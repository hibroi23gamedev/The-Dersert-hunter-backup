package me.thepoitionhunter.main;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import me.thepotionhunter.objects.SuperObect;

public class UtilityTool {
	public UtilityTool() {
		
	}
	public BufferedImage scaleImage(BufferedImage original, int width, int height) {
		BufferedImage scaledImage = new BufferedImage(width, height, original.getType());
		Graphics2D g2 = scaledImage.createGraphics();
		g2.drawImage(original, 0, 0, width, height, null);
		g2.dispose();
		return scaledImage;
	}
	public int findLengthofList(int[] inventory, int notvalue) {
		int length = 0;
		for(int i = 0; i < inventory.length; i++) {
			if(inventory[i] == notvalue) {
				length = i;
			}
		}
		return length;
	}
	
	public int findLengthofList(SuperObect[] list, String notvalue) {
		int length = 0;
		for(int i = 0; i < list.length; i++) {
			if(list[i] == null) {
				length = i;
			}
		}
		return length;
	}
	
	public void changeworldto(int world, GamePanel gp) {
		for(int i = 0; i < gp.obj.length; i++) {
			if(gp.worlds[gp.world] != null) {
				gp.worlds[gp.world].obj[i] = gp.obj[i];
			}
		}
		for(int i1 = 0; i1 < gp.worlds[world].obj.length; i1++) {
			gp.obj[i1] = gp.worlds[world].obj[i1];
		}
		gp.world = world;
		gp.tileM.loadMap("/maps/world"+gp.world+".txt");
	}
	public BufferedImage brighten(BufferedImage img, int percentage) {
		int r=0, g=0, b=0, rgb=0, p=0;
		int amount = (int)(percentage * 255/100);
		BufferedImage newImage = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
		for(int y = 0; y < img.getHeight(); y++) {
			for(int x = 0; x < img.getWidth(); x++) {
				rgb = img.getRGB(x, y); 
				r = ((rgb >> 16) & 0xFF) + amount;
				g = ((rgb >> 8) & 0xFF) + amount;
				b = (rgb & 0xFF) + amount;
				if(r > 255) r=255;
				if(g > 255) g=255;
				if(b > 255) b=255;
				p = (255<<24) | (r<<16) | (g<<8) | b;
				newImage.setRGB(x, y, p);
			}
		}
		return newImage;
	}
}
