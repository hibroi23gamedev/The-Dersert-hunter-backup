package pathfinding;

import java.util.ArrayList;

import org.lwjgl.util.vector.*;

import engineTester.MainGameLoop;

public class CityPathfinder {
	public int path_x;
	public int path_y;
	
	public ArrayList<Vector2f> path = new ArrayList<Vector2f>();
	public ArrayList<Integer> indir = new ArrayList<Integer>();
	
	public ArrayList<Vector2f> setPath(int startgridx, int startgridy, int endgridx, int endgridy) {
		path_x = startgridx;
		path_y = startgridy;
		path.clear();
		ArrayList<Node> checked = new ArrayList<Node>();
		ArrayList<Node> open = new ArrayList<Node>();
		checked.add(new Node(startgridx, startgridy));
		open.add(new Node(startgridx, startgridy));
		int p = 0;
		int old_index = -1;
		boolean hasfound = false;
		int hasfoundindex = -1;
		while(hasfound || p < 200) {
			int ogsize = open.size();
			for(int i = 0; i < ogsize; i++) {
				Vector2f[] paths = new Vector2f[4];
				paths[0] = new Vector2f(open.get(i).x-1, open.get(i).y);
				paths[1] = new Vector2f(open.get(i).x+1, open.get(i).y);
				paths[2] = new Vector2f(open.get(i).x, open.get(i).y-1);
				paths[3] = new Vector2f(open.get(i).x, open.get(i).y+1);
				if(path_x > 1 && path_y > 1) {
					if(MainGameLoop.tiles[(int)paths[0].x][(int)paths[0].y].type == 0 || old_index == 1) {
						paths[0] = null;
					}
					if(MainGameLoop.tiles[(int)paths[1].x][(int)paths[1].y].type == 0 || old_index == 0) {
						paths[1] = null;
					}
					if(MainGameLoop.tiles[(int)paths[2].x][(int)paths[2].y].type == 0 || old_index == 3) {
						paths[2] = null;
					}
					if(MainGameLoop.tiles[(int)paths[3].x][(int)paths[3].y].type == 0 || old_index == 2) {
						paths[3] = null;
					}
				}
				for(int i1 = 0; i1 < paths.length; i1++) {
					if(paths[i1] != null) {
						Node node = new Node((int)paths[i1].x, (int)paths[i1].y);
						node.parent = open.get(i);
						checked.add(node);
						open.add(node);
					}
				}
				if(open.get(i).x == endgridx && open.get(i).y == endgridy) {
					hasfound = true;
					hasfoundindex = i;
				}
				open.remove(i);
			}
			p++;
		}
		
		if(hasfound) {
			p = 0;
			Node current = checked.get(hasfoundindex);
			while(p < 1600 || current.parent != null) {
				if(current != null) {
					path.add(new Vector2f(current.x, current.y));
				}
				current = current.parent;
				p++;
			}
		}
		
		return path;
	}
	
	public float finddistance(float x1, float y1, float x2, float y2) {
		float x_dis = x1 - x2;
		float y_dis = y1 - y2;
		return (float) Math.sqrt(Math.pow(x_dis, 2)+Math.pow(y_dis, 2));
	}
}
