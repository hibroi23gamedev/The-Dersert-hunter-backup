package guis;

import org.lwjgl.util.vector.Vector2f;

public class GuiTexture {
   protected int texture;
   private Vector2f postiion;
   private Vector2f scale;

   public GuiTexture(int texture, Vector2f postiion, Vector2f scale) {
      this.texture = texture;
      this.postiion = postiion;
      this.scale = scale;
   }

   public int getTexture() {
      return this.texture;
   }

   public Vector2f getPostiion() {
      return this.postiion;
   }

   public Vector2f getScale() {
      return this.scale;
   }

   public void setTexture(int texture) {
      this.texture = texture;
   }

   public void setPostiion(Vector2f postiion) {
      this.postiion = postiion;
   }

   public void setScale(Vector2f scale) {
      this.scale = scale;
   }
}
