package me.thepotionhunter.objects;

import me.thepoitionhunter.main.*;

public class OBJ_SPRAY extends SuperObect{
	GamePanel gp;
	public OBJ_SPRAY(GamePanel gp) {
		this.gp = gp;
		name = "spray";
		image = null;
		collision = false;
	}
}
