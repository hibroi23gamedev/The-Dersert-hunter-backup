package me.thepoitionhunter.main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import me.thepoitionhunter.entity.player;
import me.thepoitionhunter.extra.SuperCustom;

public class KeyHandler implements KeyListener{

	GamePanel gp;
	Crafting cr;
	public boolean upPressed, downPressed, leftPressed, rightPressed, zpressed, xpressed, vpressed, epressed, onepressed,
	twopressed, threepressed, fourpressed, fivepressed, enterpressed;
	public boolean checkDraw = false;
	
	public KeyHandler(GamePanel gp, Crafting cr) {
		this.gp = gp;
		this.cr = cr;
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		
		
	}

	@SuppressWarnings("deprecation")
	public void keyPressed(KeyEvent e) {
		 int code = e.getKeyCode();
		 
		 if(code == KeyEvent.VK_W) {
			 upPressed = true;
		 }
		 if(code == KeyEvent.VK_S) {
			 downPressed = true;
		 }
		 if(code == KeyEvent.VK_A) {
			 leftPressed = true;
		 }
		 if(code == KeyEvent.VK_D) {
			 rightPressed = true;
		 }
		 if(code == KeyEvent.VK_Z) {
			 zpressed = true;
		 }
		 if(code == KeyEvent.VK_X) {
			 xpressed = true;
		 }
		 if(code == KeyEvent.VK_V) {
			 vpressed = true;
		 }
		 if(code == KeyEvent.VK_ENTER) {
			 enterpressed = true;
		 }
		 if(gp.gameState == gp.playState) {
			 if(!gp.Player.cutting) {
				 if(code == KeyEvent.VK_1) {
					 gp.Player.insel = 1;
				 }
				 if(code == KeyEvent.VK_2) {
					 gp.Player.insel = 2;
				 }
				 if(code == KeyEvent.VK_3) {
					 gp.Player.insel = 3;
				 }
				 if(code == KeyEvent.VK_4) {
					 gp.Player.insel = 4;
				 }
				 if(code == KeyEvent.VK_0) {
					 gp.Player.insel = 0;
				 }
			 }
		 }else {
			 if(code == KeyEvent.VK_1) {
				 onepressed = true;
			 }
			 if(code == KeyEvent.VK_2) {
				 twopressed = true;
			 }
			 if(code == KeyEvent.VK_3) {
				 threepressed = true;
			 }
			 if(code == KeyEvent.VK_4) {
				 fourpressed = true;
			 }
			 if(code == KeyEvent.VK_5) {
				 fivepressed = true;
			 }
		 }
		 if(code == KeyEvent.VK_E) {
			 if(gp.gameState != gp.deadState) {
				 if(gp.gameState != gp.inventorystate) {
					 gp.gameState = gp.inventorystate;
				 }else {
					 gp.gameState = gp.playState;
				 }
			 }else {
				 gp.gameState = gp.deadState;
			 }
		 }
		 if(code == KeyEvent.VK_K) {
			 if(gp.gameState == gp.playState) {
				 gp.gameState = gp.pauseState;
				 
			 }else if(gp.gameState == gp.pauseState) {
				 gp.gameState = gp.playState;
			 }else if(gp.gameState == gp.deadState) {
				 
			 }
		 }
		 if(code == KeyEvent.VK_P) {
			 if(checkDraw == false) {
				 checkDraw = true;
			 }else {
				 checkDraw = false;
			 }
		 }
		 if(gp.gameState == gp.inventorystate) {
			 if(code == KeyEvent.VK_DOWN) {
				 cr.selcrindex += 1;
			 }
			 if(code == KeyEvent.VK_UP) {
				 cr.selcrindex -= 1;
			 }
			 if(code == KeyEvent.VK_M) {
				 if(gp.startinv > 0) {
					 gp.startinv -= 1;
				 }
			 }
			 if(code == KeyEvent.VK_N) {
				 if(gp.startinv < cr.craftingnames.length-9) {
					 gp.startinv += 1;
				 }
			 }
		 }
		 if(gp.Player.placing_type != 0) {
			 if(code == KeyEvent.VK_R) {
				 if(!gp.Player.placing_other) {
					 gp.Player.placing_rotation += 1;
				 }
				 gp.Player.oplacing_rotation += 1;
				 if(gp.Player.placing_rotation > gp.cobj[gp.Player.placing_type].max_place) {
					 gp.Player.placing_rotation = 0;
				 }
				 if(gp.Player.oplacing_rotation > gp.cobj[gp.Player.placing_type].max_place) {
					 gp.Player.oplacing_rotation = 0;
				 }
			 }
			 if(code == KeyEvent.VK_Z) {
				 if(!gp.Player.placing_other) {
					 gp.Player.placing_other = true;
					 gp.Player.oplacing_rotation = 0;
				 }else {
					 boolean a = false;
					 for(int i = 0; i < gp.sobj.length; i++) {
							if(gp.sobj[i] == null) {
								if(!a) {
									Random random4 = new Random();
									Random random5 = new Random();
									gp.sobj[i] = new SuperCustom();
									gp.sobj[i].type_index = 1;
									gp.sobj[i].x = gp.Player.worldX;
									gp.sobj[i].y = gp.Player.worldY;
									gp.sobj[i].width = 96;
									gp.sobj[i].height = 96;
									gp.sobj[i].frame = gp.Player.placing_rotation;
									gp.sobj[i].target = gp.Player.oplacing_rotation;
									gp.sobj[i].oldtarget = gp.Player.placing_rotation;
									gp.Player.placing_type = 0;
									a = true;
								}
							}
					 }
					 gp.Player.Inventory[gp.Player.insel] = 0;
				 }
			 }
		 }
		 
		 if(gp.gameState == gp.spraystate) {
			 if(code == KeyEvent.VK_UP) {
				 gp.Player.sprayingcount -= 1;
			 }
			 if(code == KeyEvent.VK_DOWN) {
				 gp.Player.sprayingcount += 1;
			 }
			 if(code == KeyEvent.VK_LEFT) {
				 gp.Player.sprayingcount -= gp.Player.spraywidth;
			 }
			 if(code == KeyEvent.VK_RIGHT) {
				 gp.Player.sprayingcount += gp.Player.spraywidth;
			 }
			 if(code == KeyEvent.VK_ENTER) {
				 if(gp.Player.spraying[gp.Player.sprayingcount] == 0) {
					 gp.Player.spraying[gp.Player.sprayingcount] = 1;
				 }else {
					 if(gp.Player.spraying[gp.Player.sprayingcount] == 1) {
						 gp.Player.spraying[gp.Player.sprayingcount] = 2;
					 }else {
						 if(gp.Player.spraying[gp.Player.sprayingcount] == 2) {
							 gp.Player.spraying[gp.Player.sprayingcount] = 0;
						 }else {
							 
						 }
					 }
				 }
			 }
			 if(code == KeyEvent.VK_V) {
				 gp.gameState = gp.playState;
				 gp.aSetter.addObject("spray", gp.Player.worldX/gp.tileSize, gp.Player.worldY/gp.tileSize);
				 System.out.println(gp.Player.worldX/gp.tileSize);
				 System.out.println(gp.Player.worldY/gp.tileSize);
			 }
		 }
		 if(gp.gameState == gp.mapstate) {
			 if(code == KeyEvent.VK_LEFT) {
				 gp.mapselect -= 1;
			 }
			 if(code == KeyEvent.VK_RIGHT) {
				 gp.mapselect += 1;
			 }
			 if(code == KeyEvent.VK_ENTER) {
				 gp.utool.changeworldto(gp.mapselect, gp);
				 System.out.println(gp.mapselect);
				 System.out.println(gp.world);
				 gp.gameState = gp.playState;
			 }
		 }
		 
		 if(gp.gameState == gp.menustate) {
			 if(code == KeyEvent.VK_UP) {
				 gp.menupick -= 1;
			 }
			 if(code == KeyEvent.VK_DOWN) {
				 gp.menupick += 1;
			 }
			 if(code == KeyEvent.VK_ENTER) {
				 if(gp.menuon == 0) {
					 if(gp.menupick == 0) {
						 gp.menuon = 1;
						 gp.menupick = 0;
						 //gp.gameState = gp.playState;
					 }else if(gp.menupick == 1) {
						 gp.gameThread.stop();
					 }
				 }else {
					 if(gp.menuon == 1) {
						 if(gp.menupick == 0) {
							 gp.menuon = 2;
							 gp.menupick = 0;
							 gp.onmultiplayer = 1;
							 //gp.gameState = gp.playState;
						 }else if(gp.menupick == 1) {
							gp.menuon = 3;
							gp.menupick = 0;
							gp.onmultiplayer = 0;
						 }
					 }else {
						 if(gp.menuon == 2) {
							 if(gp.menupick == 0) {
								 gp.host = 1;
								 gp.gameState = gp.playState;
								 gp.startclienthost();
							 }else if(gp.menupick == 1) {
								gp.gameState = gp.playState;
								gp.host = 0;
								gp.startserverhost();
								gp.startclienthost();
							 }
						 }else {
							 if(gp.menuon == 3) {
								 if(gp.menupick == 0) {
									 gp.Player.hardness = 1;
									 gp.gameState = gp.playState;
								 }else{
									 if(gp.menupick == 1) {
										 gp.Player.hardness = 2;
										 gp.gameState = gp.playState;
									 }else{
										 if(gp.menupick == 2) {
											 gp.Player.hardness = 3;
											 gp.gameState = gp.playState;
										 }else{
											 if(gp.menupick == 3) {
												 gp.Player.hardness = 8;
												 gp.gameState = gp.playState;
											 }else{
												 if(gp.menupick == 4) {
													 gp.Player.hardness = 16;
													 gp.gameState = gp.playState;
												 }else{
													 
												 }
											 }
										 }
									 }
								 }
							 }else {
							 }
						 }
					 }
				 }
			 }
		 }
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		int code = e.getKeyCode();
		if(code == KeyEvent.VK_W) {
			 upPressed = false;
		 }
		 if(code == KeyEvent.VK_S) {
			 downPressed = false;
		 }
		 if(code == KeyEvent.VK_A) {
			 leftPressed = false;
		 }
		 if(code == KeyEvent.VK_D) {
			 rightPressed = false;
		 }
		 if(code == KeyEvent.VK_Z) {
			 zpressed = false;
		 }
		 if(code == KeyEvent.VK_X) {
			 xpressed = false;
		 }
		 if(code == KeyEvent.VK_V) {
			 vpressed = false;
		 }
		 if(code == KeyEvent.VK_1) {
			 onepressed = false;
		 }
		 if(code == KeyEvent.VK_2) {
			 twopressed = false;
		 }
		 if(code == KeyEvent.VK_3) {
			 threepressed = false;
		 }
		 if(code == KeyEvent.VK_4) {
			 fourpressed = false;
		 }
		 if(code == KeyEvent.VK_5) {
			 fivepressed = false;
		 }
		 if(code == KeyEvent.VK_ENTER) {
			 enterpressed = false;
		 }
	}


}
