package fontRendering;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import shaders.ShaderProgram;

public class FontShader extends ShaderProgram{

	private static final String VERTEX_FILE = "/fontRendering/fontVertex.txt";
	private static final String FRAGMENT_FILE = "/fontRendering/fontFragment.txt";
	
	private int lc;
	private int lt;
	
	public FontShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}

	@Override
	protected void getAllUniformLocations() {
		lc = super.getUniformLocation("colour");
		lt = super.getUniformLocation("translation");
	}

	@Override
	protected void bindATTR() {
		super.bindATTR(0, "position");
		super.bindATTR(1, "textureCoords");
	}
	
	protected void loadColour(Vector3f colour) {
		super.loadVector(lc, colour);
	}
	protected void loadTranslation(Vector2f translation) {
		super.load2DVector(lt, translation);
	}

}
