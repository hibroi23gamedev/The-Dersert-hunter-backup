package skybox;

import entitys.Camera;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import shaders.ShaderProgram;
import toolbox.Maths;

public class SkyboxShader extends ShaderProgram {
   private static final String VERTEX_FILE = "/skybox/skyboxVertexShader.txt";
   private static final String FRAGMENT_FILE = "/skybox/skyboxFragmentShader.txt";
   private static final float ROTATE_SPEED = 0.02F;
   private int location_projectionMatrix;
   private int location_viewMatrix;
   private int location_fogColour;
   private int location_cubeMap;
   private int location_cubeMap2;
   private int location_blendFactor;
   private float rotation = 0.0F;

   public SkyboxShader() {
      super("/skybox/skyboxVertexShader.txt", "/skybox/skyboxFragmentShader.txt");
   }

   public void loadProjectionMatrix(Matrix4f matrix) {
      super.loadMatrix(this.location_projectionMatrix, matrix);
   }

   public void loadFogColour(float r, float g, float b) {
      super.loadVector(this.location_fogColour, new Vector3f(r, g, b));
   }

   public void connectTextureUnits() {
      super.loadInt(this.location_cubeMap, 0);
      super.loadInt(this.location_cubeMap2, 1);
   }

   public void loadBlendFactor(float blend) {
      super.loadFloat(this.location_blendFactor, blend);
   }

   public void loadViewMatrix(Camera camera) {
      Matrix4f matrix = Maths.createView(camera);
      matrix.m30 = 0.0F;
      matrix.m31 = 0.0F;
      matrix.m32 = 0.0F;
      this.rotation += 0.02F;
      Matrix4f.rotate((float)Math.toRadians((double)this.rotation), new Vector3f(0.0F, 1.0F, 0.0F), matrix, matrix);
      super.loadMatrix(this.location_viewMatrix, matrix);
   }

   protected void getAllUniformLocations() {
      this.location_projectionMatrix = super.getUniformLocation("projectionMatrix");
      this.location_viewMatrix = super.getUniformLocation("viewMatrix");
      this.location_fogColour = super.getUniformLocation("fogColour");
      this.location_blendFactor = super.getUniformLocation("blendFactor");
      this.location_cubeMap = super.getUniformLocation("cubeMap");
      this.location_cubeMap2 = super.getUniformLocation("cubeMap2");
   }

   protected void bindATTR() {
      super.bindATTR(0, "position");
   }
}
