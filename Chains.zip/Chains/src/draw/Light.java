package draw;

public class Light {
	public int x;
	public int y;
	public double range;
}
