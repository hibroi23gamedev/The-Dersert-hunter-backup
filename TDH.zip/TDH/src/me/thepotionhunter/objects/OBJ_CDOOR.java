package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_CDOOR extends SuperObect{
	GamePanel gp;
	public OBJ_CDOOR(GamePanel gp) {
		this.gp = gp;
		name = "cdoor";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/tiles/cstone.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = true;
	}
}
