package me.thepoitionhunter.extra;

public class TutorialSpeech {
	public String Speech;
	public int time;
}
