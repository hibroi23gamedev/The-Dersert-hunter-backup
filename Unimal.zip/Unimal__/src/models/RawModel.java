package models;

import render.ModelData;

public class RawModel {
   public int vaoID;
   private int vertexCount;
   
   public ModelData data;

   public RawModel(int vaoID, int vertexCount, ModelData data) {
      this.vaoID = vaoID;
      this.vertexCount = vertexCount;
      this.data = data;
   }

   public int getVaoID() {
      return this.vaoID;
   }

   public int getVertexCount() {
      return this.vertexCount;
   }
}
