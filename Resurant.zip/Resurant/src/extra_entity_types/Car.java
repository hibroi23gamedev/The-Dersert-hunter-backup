package extra_entity_types;

import org.lwjgl.util.vector.Vector3f;

import engineTester.MainGameLoop;
import entitys.Camera;
import entitys.Entity;
import entitys.Player;
import models.TexturedModel;
import render.MasterRenderer;
import terrains.Terrain;

public class Car extends AntiFact{
	
	Player fake_player;
	
	public Car(TexturedModel model, Vector3f position, float rotX, float rotY, float rotZ, float scale, Player fake) {
		super(model, position, rotX, rotY, rotZ, scale);
		this.fake_player = fake;
	}
	
	public void update(Terrain terrain, MasterRenderer renderer, Player player, Camera camera) {
		if (terrain.getHeightOfTerrain(getPosition().x, getPosition().z) <= getPosition().y) {
            processPhysics(terrain, fake_player, false, renderer);
         }
	}

}
