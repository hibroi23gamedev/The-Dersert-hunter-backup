package me.thepoitionhunter.extra;
import java.util.ArrayList;

import me.thepoitionhunter.main.GamePanel;

public class Inventory {
	public int type;
	public int stack;
	public int counter;
	
	public void update(GamePanel gp, int index) {
		if(stack <= 0) {
			gp.fullinventory[index] = null;
		}
		switch(type) {
		case 18:
			counter += 1;
			if(counter >= 300) {
				if(gp.fullinventory[index+1] == null) {
					gp.fullinventory[index+1] = new Inventory();
					gp.fullinventory[index+1].type = 1;
					gp.fullinventory[index+1].stack = 1;
				}
				if(gp.fullinventory[index+16] == null) {
					gp.fullinventory[index+16] = new Inventory();
					gp.fullinventory[index+16].type = 2;
					gp.fullinventory[index+16].stack = 1;
				}
				type = 17;
			}
			break;
		}
	}
}
