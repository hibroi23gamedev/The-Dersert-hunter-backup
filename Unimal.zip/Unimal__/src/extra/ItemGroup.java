package extra;

import java.util.ArrayList;

public class ItemGroup {
	public ArrayList<ItemL> items = new ArrayList<ItemL>();
}
