package me.thepoitionhunter.extra;

import me.thepoitionhunter.main.GamePanel;
import java.util.Random;

public class FrameChanger {
	public static String target = "The Derset Hunter";
	
	static String current = "#<>;@#'@:#@";
	
	static int current_length = 0;
	
	public static void changeFrameName(String name) {
		target = name;
		current = "";
		current_length = name.length();
		Random random = new Random();
		for(int i = 0; i < name.length(); i++) {
			int rand = random.nextInt(7);
			if(rand == 0) {
				current = current + "#";
			}if(rand == 1) {
				current = current + "<";
			}if(rand == 2) {
				current = current + ">";
			}if(rand == 3) {
				current = current + ";";
			}if(rand == 4) {
				current = current + "@";
			}if(rand == 5) {
				current = current + ":";
			}if(rand == 6) {
				current = current + "'";
			}
		}
	}
	
	public static void update(GamePanel gp) {
		//System.out.println("CURRENT: "+current+"| TARGET: "+target);
		
		gp.frame.setTitle(current);
		if(current_length > 0) {
			current_length--;
			String lengthen = "";
			for(int i = 0; i < current.length(); i++) {
				if(i != current_length) {
					if(i > current_length) {
						lengthen = lengthen + current.charAt(i);
					}else {
						Random random = new Random();
						int rand = random.nextInt(7);
						char cchar = ' ';
						if(rand == 0) {
							cchar = '#';
						}if(rand == 1) {
							cchar = '<';
						}if(rand == 2) {
							cchar = '>';
						}if(rand == 3) {
							cchar = ';';
						}if(rand == 4) {
							cchar = '@';
						}if(rand == 5) {
							cchar = ':';
						}if(rand == 6) {
							cchar = '\'';
						}
						lengthen = lengthen + cchar;
					}
				}else {
					lengthen = lengthen + target.charAt(i);
				}
			}
			current = lengthen;
		}
	}
	
	public static boolean hasReachedTarget() {
		if(current_length <= 0) {
			return true;
		}else {
			return false;
		}
	}
}
