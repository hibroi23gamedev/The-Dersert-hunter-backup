package entities;

import java.awt.Graphics;

import draw.Image;
import draw.Light;
import main.GamePanel;

public abstract class Entity {
	public int x;
	public int y;
	public int z;
	
	public Image img;
	
	public Entity(int x, int y, int z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public abstract void update();
	public abstract void draw(Graphics g, Light light);

	public abstract void update(GamePanel gp);
}
