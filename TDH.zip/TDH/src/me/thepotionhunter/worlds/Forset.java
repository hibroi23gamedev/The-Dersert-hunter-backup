package me.thepotionhunter.worlds;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.extra.SuperWorld;

public class Forset extends SuperWorld{
	public Forset(int idd) {
		name = "Forset";
		id = idd;
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/worlds/test.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
