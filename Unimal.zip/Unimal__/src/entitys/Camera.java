package entitys;

import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Vector3f;

public class Camera {
   private float distanceFromPlayer = 80F;
//private float distanceFromPlayer = 30F;
   private float angleAroundPlayer = 0.0F;
   private Vector3f position = new Vector3f(0.0F, 0.0F, 0.0F);
   private float pitch = 0.0F;
   private float yaw = 90.0F;
   private float roll = 0;
   private Player player;

   public Camera(Player player) {
      this.player = player;
   }

   public void move() {
      this.calculateZoom();
      this.calculatePitch();
      this.calculateAngleAroundPlayer();
      float horizontalDistance = this.calculateDis();
      float verticalDistance = this.calculateDisV();
      this.calculateCameraPosition(horizontalDistance * 0.1F, verticalDistance * 0.1F);
      this.yaw = 180.0F - (this.player.getRotY() + this.angleAroundPlayer);
   }

   public Vector3f getPosition() {
      return this.position;
   }

   public void setPosition(float x, float y, float z) {
      this.position.x = x;
      this.position.y = y;
      this.position.z = z;
   }

   private void calculateCameraPosition(float h, float v) {
      this.position.y = this.player.getPosition().y + (v+1.44f);
      float theta = this.player.getRotY() + this.angleAroundPlayer;
      float offsetX = (float)((double)h * Math.sin(Math.toRadians((double)theta)));
      float offsetZ = (float)((double)h * Math.cos(Math.toRadians((double)theta)));
      this.position.x = this.player.getPosition().x - offsetX;
      this.position.z = this.player.getPosition().z - offsetZ;
   }

   private float calculateDis() {
      return (float)((double)this.distanceFromPlayer * Math.cos(Math.toRadians((double)this.pitch)));
   }

   private float calculateDisV() {
      return (float)((double)this.distanceFromPlayer * Math.sin(Math.toRadians((double)this.pitch)));
   }

   public float getPitch() {
      return this.pitch;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getRoll() {
      return this.roll;
   }

   private void calculateZoom() {
      float zoomLevel = (float)Mouse.getDWheel() * 0.1F;
      this.distanceFromPlayer -= zoomLevel;
   }

   private void calculatePitch() {
      if (Mouse.isButtonDown(1)) {
         float pitchChange = (float)Mouse.getDY() * 0.1F;
         this.pitch -= pitchChange;
      }

   }

   private void calculateAngleAroundPlayer() {
      if (Mouse.isButtonDown(1)) {
         float angleChange = (float)Mouse.getDX() * 0.3F;
         this.angleAroundPlayer -= angleChange;
      }

   }
}
