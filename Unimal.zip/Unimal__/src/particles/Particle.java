package particles;

import entitys.Camera;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

public class Particle {
   private Vector3f position;
   private Vector3f velocity;
   private float gravityEffect;
   private float lifeLength;
   private float rotation;
   private float scale;
   private Vector2f texOffset1 = new Vector2f();
   private Vector2f texOffset2 = new Vector2f();
   private float blend;
   private ParticleTexture texture;
   private float elapsedTime = 0.0F;
   private float distance;
   private float time = 0.01F;

   public Particle(ParticleTexture texture, Vector3f position, Vector3f velocity, float gravityEffect, float lifeLength, float rotation, float scale) {
      this.position = position;
      this.texture = texture;
      this.velocity = velocity;
      this.gravityEffect = gravityEffect;
      this.lifeLength = lifeLength;
      this.rotation = rotation;
      this.scale = scale;
      ParticleMaster.addParticle(this);
   }

   public float getDistance() {
      return this.distance;
   }

   public Vector2f getTexOffset1() {
      return this.texOffset1;
   }

   public Vector2f getTexOffset2() {
      return this.texOffset2;
   }

   public float getBlend() {
      return this.blend;
   }

   public ParticleTexture getTexture() {
      return this.texture;
   }

   protected Vector3f getPosition() {
      return this.position;
   }

   protected float getRotation() {
      return this.rotation;
   }

   protected float getScale() {
      return this.scale;
   }

   protected boolean update(Camera camera) {
      Vector3f var10000 = this.velocity;
      var10000.y += -50.0F * this.gravityEffect * this.time;
      Vector3f change = new Vector3f(this.velocity);
      change.scale(this.time);
      Vector3f.add(change, this.position, this.position);
      this.distance = Vector3f.sub(camera.getPosition(), this.position, (Vector3f)null).lengthSquared();
      this.updateTextureCoordsInfo();
      this.elapsedTime += this.time;
      return this.elapsedTime < this.lifeLength;
   }

   private void updateTextureCoordsInfo() {
      float lifeFactor = this.elapsedTime / this.lifeLength;
      int stageCount = this.texture.getNumberofRows() * this.texture.getNumberofRows();
      float atlasProgression = lifeFactor * (float)stageCount;
      int index1 = (int)Math.floor((double)atlasProgression);
      int index2 = index1 < stageCount - 1 ? index1 + 1 : index1;
      this.blend = atlasProgression % 1.0F;
      this.setTextureOffset(this.texOffset1, index1);
      this.setTextureOffset(this.texOffset2, index2);
   }

   private void setTextureOffset(Vector2f offset, int index) {
      int column = index % this.texture.getNumberofRows();
      int row = index / this.texture.getNumberofRows();
      offset.x = (float)column / (float)this.texture.getNumberofRows();
      offset.y = (float)row / (float)this.texture.getNumberofRows();
   }
}
