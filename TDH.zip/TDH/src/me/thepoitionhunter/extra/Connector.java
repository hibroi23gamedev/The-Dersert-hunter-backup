package me.thepoitionhunter.extra;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.GamePanel;

public class Connector {
	public int password;
	public int x;
	public int y;
	
	boolean isTouching = false;
	boolean isPanelOpen = false;
	
	BufferedImage img;
	
	public Connector(int password, int x, int y) {
		this.password = password;
		this.x = x;
		this.y = y;
		
		try {
			this.img = ImageIO.read(getClass().getResourceAsStream("/objects/volt/connector.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update(GamePanel gp) {
		if(x < gp.Player.worldX+(gp.tileSize/2) && y < gp.Player.worldY+(gp.tileSize/2) &&
				x+gp.tileSize > gp.Player.worldX+(gp.tileSize/2) && y+gp.tileSize > gp.Player.worldY+(gp.tileSize/2)) {
			isTouching = true;
			if(gp.keyH.zpressed) {
				isPanelOpen = true;
			}else {
				isPanelOpen = false;
			}
		}else {
			isTouching = false;
			isPanelOpen = false;
		}
	}
	
	public void draw(Graphics2D g2, GamePanel gp) {
		int screenX = x - gp.Player.worldX + gp.Player.ScreenX;
		int screenY = y - gp.Player.worldY + gp.Player.ScreenY;
		g2.drawImage(img, screenX, screenY, gp.tileSize, gp.tileSize, null);
		g2.setFont(new Font("Arial", Font.BOLD, 16));
		g2.setColor(Color.white);
		g2.drawString(""+password, screenX+gp.tileSize/6, (int) (screenY+gp.tileSize/1.1));
		g2.setFont(new Font("Arial", Font.BOLD, 6));
		g2.drawString("Password: ", screenX+gp.tileSize/6, (int) (screenY+gp.tileSize/1.7));
		if(isPanelOpen) {
			g2.setColor(Color.orange);
			g2.setStroke(new BasicStroke(5));
			g2.fillRect(200, 150, 400, 300);
			g2.setColor(Color.black);
			g2.drawRect(200, 150, 400, 300);
			g2.setColor(Color.black);
			g2.setFont(new Font("Arial", Font.BOLD, 20));
			g2.drawString("Wifi Box Settings", 210, 180);
			g2.drawLine(204, 184, 596, 184);
			g2.drawString("Password: "+password, 210, 210);
			g2.drawString("Requests Processing: ", 210, 240);
		}else {
			if(isTouching) {
				g2.setFont(new Font("Arial", Font.BOLD, 30));
				g2.drawString("Press Z to open", 200, 400);
			}
		}
	}
}
