package render;

import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Random;
import extra.*;
import fruits.Fruit_Type;

public class Kid {
	double x, y, z, width, length, height, rotation = Math.PI*0.75;
	double[] RotAdd = new double[4];
	Color c;
	double x1, x2, x3, x4, y1, y2, y3, y4;
	DPolygon[] Polys = new DPolygon[6];
	double[] angle;
	int counter;
	double speed = 1;
	
	public Thought custhought = new Thought();
	
	public ArrayList<Integer> colitems = new ArrayList<Integer>();
	
	boolean fruit = false;
	
	public int price;
	
	public int parentindex = 0;
	
	public int fruitcounter = 0;
	public int fruitindex = 0;
	
	boolean gotoplay = false;
	boolean playing = false;
	int playindex = 0;
	int playindexi = 0;
	
	public short cusfoodtime = 0;
	
	public Dimension offsetpos;
	
	
	public Kid(Color c, int parentindex, boolean gotoplay, Dimension offsetpos)
	{
		this.gotoplay = gotoplay;
		this.offsetpos = offsetpos;
		this.parentindex = parentindex;
		Random random = new Random();
		if(gotoplay) {
			this.playindex = random.nextInt(Screen.toys.size());
		}
		playing = true;
		custhought.rating = 10;
		int width = 10;
		int height = 20;
		int length = 10;
		this.width = 10;
		this.height = 20;
		this.length = 10;
		Polys[0] = new DPolygon(new double[]{x, x+width, x+width, x}, new double[]{y, y, y+length, y+length},  new double[]{z, z, z, z}, c, false);
		Screen.DPolygons.add(Polys[0]);
		Polys[1] = new DPolygon(new double[]{x, x+width, x+width, x}, new double[]{y, y, y+length, y+length},  new double[]{z+height, z+height, z+height, z+height}, c, false);
		Screen.DPolygons.add(Polys[1]);
		Polys[2] = new DPolygon(new double[]{x, x, x+width, x+width}, new double[]{y, y, y, y},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(Polys[2]);
		Polys[3] = new DPolygon(new double[]{x+width, x+width, x+width, x+width}, new double[]{y, y, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(Polys[3]);
		Polys[4] = new DPolygon(new double[]{x, x, x+width, x+width}, new double[]{y+length, y+length, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(Polys[4]);
		Polys[5] = new DPolygon(new double[]{x, x, x, x}, new double[]{y, y, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(Polys[5]);
		
		this.c = c;
		this.x = x;
		this.y = y;
		this.z = z;
		
		setRotAdd();
		updatePoly();
	}
	
	void setRotAdd()
	{
		angle = new double[4];
		
		double xdif = - width/2 + 0.00001;
		double ydif = - length/2 + 0.00001;
		
		angle[0] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[0] += Math.PI;
		
/////////
		xdif = width/2 + 0.00001;
		ydif = - length/2 + 0.00001;
		
		angle[1] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[1] += Math.PI;
/////////
		xdif = width/2 + 0.00001;
		ydif = length/2 + 0.00001;
		
		angle[2] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[2] += Math.PI;
		
/////////
		xdif = - width/2 + 0.00001;
		ydif = length/2 + 0.00001;
		
		angle[3] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[3] += Math.PI;	
		
		RotAdd[0] = angle[0] + 0.25 * Math.PI;
		RotAdd[1] =	angle[1] + 0.25 * Math.PI;
		RotAdd[2] = angle[2] + 0.25 * Math.PI;
		RotAdd[3] = angle[3] + 0.25 * Math.PI;

	}
	
	public void update(Screen sc) {
		boolean removechild = false;
		if(parentindex > Screen.People.size()) {
			removechild = true;
		}
		if(!removechild) {
			try {
				if(Screen.People.get(parentindex).inshop) {
					if(x < 8000) {
						x = 80000;
						y = 1200;
					}
				}
				if(Screen.People.get(parentindex).inshop) {
					width = 3;
					height = 6;
					length = 3;
					speed = 1.5;
				}else {
					width = 10;
					height = 20;
					length = 10;
					speed = 2;
				}
				if(!gotoplay || !Screen.People.get(parentindex).inshop) {
					if(parentindex < Screen.People.size()) {
						if(Screen.People.get(parentindex).inshop) {
							this.x = Screen.People.get(parentindex).x+(offsetpos.width/4);
							this.y = Screen.People.get(parentindex).y+(offsetpos.height/4);
							this.z = Screen.People.get(parentindex).z;
							width = 3;
							height = 6;
							length = 3;
						}else {
							this.x = Screen.People.get(parentindex).x+(offsetpos.width);
							this.y = Screen.People.get(parentindex).y+(offsetpos.height);
							this.z = Screen.People.get(parentindex).z;
							width = 10;
							height = 20;
							length = 10;
						}
					}else {
						removeKid();
					}
				}else {
					if(!playing) {
						if(Screen.toys.get(playindex).x > x) {
							x += speed;
						}
						if(Screen.toys.get(playindex).x < x) {
							x -= speed;
						}
						if(Screen.toys.get(playindex).y > y) {
							y += speed;
						}
						if(Screen.toys.get(playindex).y < y) {
							y -= speed;
						}
						if(Screen.toys.get(playindex).x == x) {
							if(Screen.toys.get(playindex).y == y) {
								playing = true;
							}
						}
					}
				}
				
				if(playing) {
					if(Screen.toys.get(playindex).steps.get(playindexi).endx > x) {
						x += speed;
					}
					if(Screen.toys.get(playindex).steps.get(playindexi).endx < x) {
						x -= speed;
					}
					if(Screen.toys.get(playindex).steps.get(playindexi).endy > y) {
						y += speed;
					}
					if(Screen.toys.get(playindex).steps.get(playindexi).endy < y) {
						y -= speed;
					}
					
					if(Screen.toys.get(playindex).steps.get(playindexi).endz > z) {
						z += speed;
					}
					if(Screen.toys.get(playindex).steps.get(playindexi).endz < z) {
						z -= speed;
					}
					if(Screen.toys.get(playindex).steps.get(playindexi).endx > x-4
							&& Screen.toys.get(playindex).steps.get(playindexi).endx < x+4) {
						if(Screen.toys.get(playindex).steps.get(playindexi).endy > y-4 &&
								Screen.toys.get(playindex).steps.get(playindexi).endy < y+4) {
							if(Screen.toys.get(playindex).steps.get(playindexi).endz > z-4 &&
									Screen.toys.get(playindex).steps.get(playindexi).endz < z+4) {
								if(Screen.toys.get(playindex).steps.size() > playindexi) {
									playindexi += 1;
								}
							}
						}
					}
				}
				
				updatePoly();
			}catch(IndexOutOfBoundsException e) {
				
			}
		}
		if(removechild) {
			removeKid();
		}
	}
	
	void UpdateDirection(double toX, double toY)
	{
		double xdif = toX - (x + width/2) + 0.00001;
		double ydif = toY - (y + length/2) + 0.00001;
		
		double anglet = Math.atan(ydif/xdif) + 0.75 * Math.PI;

		if(xdif<0)
			anglet += Math.PI;

		rotation = anglet;
		updatePoly();		
	}

	void updatePoly()
	{
		for(int i = 0; i < 6; i++)
		{
			Screen.DPolygons.add(Polys[i]);
			Screen.DPolygons.remove(Polys[i]);
		}
		
		double radius = Math.sqrt(width*width + length*length);
		
			   x1 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[0]);
			   x2 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[1]);
			   x3 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[2]);
			   x4 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[3]);
			   
			   y1 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[0]);
			   y2 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[1]);
			   y3 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[2]);
			   y4 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[3]);
   
		Polys[0].x = new double[]{x1, x2, x3, x4};
		Polys[0].y = new double[]{y1, y2, y3, y4};
		Polys[0].z = new double[]{z, z, z, z};

		Polys[1].x = new double[]{x4, x3, x2, x1};
		Polys[1].y = new double[]{y4, y3, y2, y1};
		Polys[1].z = new double[]{z+height, z+height, z+height, z+height};
			   
		Polys[2].x = new double[]{x1, x1, x2, x2};
		Polys[2].y = new double[]{y1, y1, y2, y2};
		Polys[2].z = new double[]{z, z+height, z+height, z};

		Polys[3].x = new double[]{x2, x2, x3, x3};
		Polys[3].y = new double[]{y2, y2, y3, y3};
		Polys[3].z = new double[]{z, z+height, z+height, z};

		Polys[4].x = new double[]{x3, x3, x4, x4};
		Polys[4].y = new double[]{y3, y3, y4, y4};
		Polys[4].z = new double[]{z, z+height, z+height, z};

		Polys[5].x = new double[]{x4, x4, x1, x1};
		Polys[5].y = new double[]{y4, y4, y1, y1};
		Polys[5].z = new double[]{z, z+height, z+height, z};
		
	}

	void removeKid()
	{
		for(int i = 0; i < 6; i ++)
			Screen.DPolygons.remove(Polys[i]);
		Screen.People.remove(this);
	}
}
