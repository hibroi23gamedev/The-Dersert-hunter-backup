package shadows;

import entitys.Camera;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

public class ShadowBox {
   private static final float OFFSET = 30.0F;
   private static final Vector4f UP = new Vector4f(0.0F, 1.0F, 0.0F, 0.0F);
   private static final Vector4f FORWARD = new Vector4f(0.0F, 0.0F, -1.0F, 0.0F);
   private static final float SHADOW_DISTANCE = 30.0F;
   private float minX;
   private float maxX;
   private float minY;
   private float maxY;
   private float minZ;
   private float maxZ;
   private Matrix4f lightViewMatrix;
   private Camera cam;
   private float farHeight;
   private float farWidth;
   private float nearHeight;
   private float nearWidth;

   protected ShadowBox(Matrix4f lightViewMatrix, Camera camera) {
      this.lightViewMatrix = lightViewMatrix;
      this.cam = camera;
      this.calculateWidthsAndHeights();
   }

   protected void update() {
      Matrix4f rotation = this.calculateCameraRotationMatrix();
      Vector3f forwardVector = new Vector3f(Matrix4f.transform(rotation, FORWARD, (Vector4f)null));
      Vector3f toFar = new Vector3f(forwardVector);
      toFar.scale(30.0F);
      Vector3f toNear = new Vector3f(forwardVector);
      toNear.scale(0.1F);
      Vector3f centerNear = Vector3f.add(toNear, this.cam.getPosition(), (Vector3f)null);
      Vector3f centerFar = Vector3f.add(toFar, this.cam.getPosition(), (Vector3f)null);
      Vector4f[] points = this.calculateFrustumVertices(rotation, forwardVector, centerNear, centerFar);
      boolean first = true;
      Vector4f[] var12 = points;
      int var11 = points.length;

      for(int var10 = 0; var10 < var11; ++var10) {
         Vector4f point = var12[var10];
         if (first) {
            this.minX = point.x;
            this.maxX = point.x;
            this.minY = point.y;
            this.maxY = point.y;
            this.minZ = point.z;
            this.maxZ = point.z;
            first = false;
         } else {
            if (point.x > this.maxX) {
               this.maxX = point.x;
            } else if (point.x < this.minX) {
               this.minX = point.x;
            }

            if (point.y > this.maxY) {
               this.maxY = point.y;
            } else if (point.y < this.minY) {
               this.minY = point.y;
            }

            if (point.z > this.maxZ) {
               this.maxZ = point.z;
            } else if (point.z < this.minZ) {
               this.minZ = point.z;
            }
         }
      }

      this.maxZ += 30.0F;
   }

   protected Vector3f getCenter() {
      float x = (this.minX + this.maxX) / 2.0F;
      float y = (this.minY + this.maxY) / 2.0F;
      float z = (this.minZ + this.maxZ) / 2.0F;
      Vector4f cen = new Vector4f(x, y, z, 1.0F);
      Matrix4f invertedLight = new Matrix4f();
      Matrix4f.invert(this.lightViewMatrix, invertedLight);
      return new Vector3f(Matrix4f.transform(invertedLight, cen, (Vector4f)null));
   }

   protected float getWidth() {
      return this.maxX - this.minX;
   }

   protected float getHeight() {
      return this.maxY - this.minY;
   }

   protected float getLength() {
      return this.maxZ - this.minZ;
   }

   private Vector4f[] calculateFrustumVertices(Matrix4f rotation, Vector3f forwardVector, Vector3f centerNear, Vector3f centerFar) {
      Vector3f upVector = new Vector3f(Matrix4f.transform(rotation, UP, (Vector4f)null));
      Vector3f rightVector = Vector3f.cross(forwardVector, upVector, (Vector3f)null);
      Vector3f downVector = new Vector3f(-upVector.x, -upVector.y, -upVector.z);
      Vector3f leftVector = new Vector3f(-rightVector.x, -rightVector.y, -rightVector.z);
      Vector3f farTop = Vector3f.add(centerFar, new Vector3f(upVector.x * this.farHeight, upVector.y * this.farHeight, upVector.z * this.farHeight), (Vector3f)null);
      Vector3f farBottom = Vector3f.add(centerFar, new Vector3f(downVector.x * this.farHeight, downVector.y * this.farHeight, downVector.z * this.farHeight), (Vector3f)null);
      Vector3f nearTop = Vector3f.add(centerNear, new Vector3f(upVector.x * this.nearHeight, upVector.y * this.nearHeight, upVector.z * this.nearHeight), (Vector3f)null);
      Vector3f nearBottom = Vector3f.add(centerNear, new Vector3f(downVector.x * this.nearHeight, downVector.y * this.nearHeight, downVector.z * this.nearHeight), (Vector3f)null);
      Vector4f[] points = new Vector4f[]{this.calculateLightSpaceFrustumCorner(farTop, rightVector, this.farWidth), this.calculateLightSpaceFrustumCorner(farTop, leftVector, this.farWidth), this.calculateLightSpaceFrustumCorner(farBottom, rightVector, this.farWidth), this.calculateLightSpaceFrustumCorner(farBottom, leftVector, this.farWidth), this.calculateLightSpaceFrustumCorner(nearTop, rightVector, this.nearWidth), this.calculateLightSpaceFrustumCorner(nearTop, leftVector, this.nearWidth), this.calculateLightSpaceFrustumCorner(nearBottom, rightVector, this.nearWidth), this.calculateLightSpaceFrustumCorner(nearBottom, leftVector, this.nearWidth)};
      return points;
   }

   private Vector4f calculateLightSpaceFrustumCorner(Vector3f startPoint, Vector3f direction, float width) {
      Vector3f point = Vector3f.add(startPoint, new Vector3f(direction.x * width, direction.y * width, direction.z * width), (Vector3f)null);
      Vector4f point4f = new Vector4f(point.x, point.y, point.z, 1.0F);
      Matrix4f.transform(this.lightViewMatrix, point4f, point4f);
      return point4f;
   }

   private Matrix4f calculateCameraRotationMatrix() {
      Matrix4f rotation = new Matrix4f();
      rotation.rotate((float)Math.toRadians((double)(-this.cam.getYaw())), new Vector3f(0.0F, 1.0F, 0.0F));
      rotation.rotate((float)Math.toRadians((double)(-this.cam.getPitch())), new Vector3f(1.0F, 0.0F, 0.0F));
      return rotation;
   }

   private void calculateWidthsAndHeights() {
      this.farWidth = (float)(30.0D * Math.tan(Math.toRadians(70.0D)));
      this.nearWidth = (float)(0.10000000149011612D * Math.tan(Math.toRadians(70.0D)));
      this.farHeight = this.farWidth / this.getAspectRatio();
      this.nearHeight = this.nearWidth / this.getAspectRatio();
   }

   private float getAspectRatio() {
      return (float)Display.getWidth() / (float)Display.getHeight();
   }
}
