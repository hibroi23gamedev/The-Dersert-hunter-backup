package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_PORTAL extends SuperObect{
	GamePanel gp;
	public OBJ_PORTAL(GamePanel gp, int world) {
		this.gp = gp;
		name = "portal";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/portal.png"));
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = false;
		counter = world;
	}
}
