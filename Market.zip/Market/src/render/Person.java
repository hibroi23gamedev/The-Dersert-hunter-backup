package render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import extra.*;
import fruits.Fruit_Type;

public class Person {
	double x, y, z, width, length, height, rotation = Math.PI*0.75;
	double[] RotAdd = new double[4];
	Color c;
	double x1, x2, x3, x4, y1, y2, y3, y4;
	DPolygon[] Polys = new DPolygon[6];
	double[] angle;
	int counter;
	double speed = 8;
	int shelf_target[];
	int table_seat[];
	int shelf_on = 0;
	boolean inshop = false;
	boolean walkingtoshop = false;
	
	public Thought custhought = new Thought();
	
	public ArrayList<Integer> colitems = new ArrayList<Integer>();
	
	boolean fruit = false;
	
	public int price;
	
	public boolean cafe = false;
	public boolean alreadygot = false;
	
	public int fruitcounter = 0;
	public int fruitindex = 0;
	
	public short cusfoodtime = 0;
	
	
	public Person(double x, double y, double z, Color c)
	{
		
		Random random3 = new Random();
		walkingtoshop = random3.nextBoolean();
		
		custhought.rating = 10;
		int width = 30;
		int height = 70;
		int length = 30;
		this.width = 30;
		this.height = 70;
		this.length = 30;
		this.speed = 4;
		Polys[0] = new DPolygon(new double[]{x, x+width, x+width, x}, new double[]{y, y, y+length, y+length},  new double[]{z, z, z, z}, c, false);
		Screen.DPolygons.add(Polys[0]);
		Polys[1] = new DPolygon(new double[]{x, x+width, x+width, x}, new double[]{y, y, y+length, y+length},  new double[]{z+height, z+height, z+height, z+height}, c, false);
		Screen.DPolygons.add(Polys[1]);
		Polys[2] = new DPolygon(new double[]{x, x, x+width, x+width}, new double[]{y, y, y, y},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(Polys[2]);
		Polys[3] = new DPolygon(new double[]{x+width, x+width, x+width, x+width}, new double[]{y, y, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(Polys[3]);
		Polys[4] = new DPolygon(new double[]{x, x, x+width, x+width}, new double[]{y+length, y+length, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(Polys[4]);
		Polys[5] = new DPolygon(new double[]{x, x, x, x}, new double[]{y, y, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(Polys[5]);
		Random random4 = new Random();
		if(random4.nextInt(3) == 0) {
			cafe = true;
		}
		Random random = new Random();
		shelf_target = new int[1];
		table_seat = new int[1];
		boolean xx = false;
		for(int i = 0; i < Screen.tables.size(); i++) {
			for(int i1 = 0; i1 < Screen.tables.get(i).used_seats.length; i1++) {
				if(!Screen.tables.get(i).used_seats[i1]) {
					xx = true;
				}
			}
		}
		if(!xx) {
			cafe = false;
		}
		if(cafe) {
			for(int i = 0; i < shelf_target.length; i++) {
				shelf_target[i] = random.nextInt(Screen.tables.size());
				table_seat[i] = random.nextInt(4);
				int le = 0;
				while(Screen.tables.get(shelf_target[i]).used_seats[table_seat[i]] && le < 2000) {
					shelf_target[i] = random.nextInt(Screen.tables.size());
					table_seat[i] = random.nextInt(4);
					le += 1;
					if(le == 1999) {
						//cafe = false;
					}
				}
			}
			Screen.tables.get(shelf_target[0]).used_seats[table_seat[0]] = true;
		}else {
			Random random2 = new Random();
			shelf_target = new int[random2.nextInt(Screen.Shelfs.size()*4)+1];
			for(int i = 0; i < shelf_target.length; i++) {
				shelf_target[i] = random2.nextInt(Screen.Shelfs.size());
				while(!Screen.Shelfs.get(shelf_target[i]).jacob) {
					Random random5 = new Random();
					shelf_target[i] = random5.nextInt(Screen.Shelfs.size());
				}
			}
		}
		
		this.c = c;
		this.x = x;
		this.y = y;
		this.z = z;
		
		setRotAdd();
		updatePoly();
	}
	
	void setRotAdd()
	{
		angle = new double[4];
		
		double xdif = - width/2 + 0.00001;
		double ydif = - length/2 + 0.00001;
		
		angle[0] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[0] += Math.PI;
		
/////////
		xdif = width/2 + 0.00001;
		ydif = - length/2 + 0.00001;
		
		angle[1] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[1] += Math.PI;
/////////
		xdif = width/2 + 0.00001;
		ydif = length/2 + 0.00001;
		
		angle[2] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[2] += Math.PI;
		
/////////
		xdif = - width/2 + 0.00001;
		ydif = length/2 + 0.00001;
		
		angle[3] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[3] += Math.PI;	
		
		RotAdd[0] = angle[0] + 0.25 * Math.PI;
		RotAdd[1] =	angle[1] + 0.25 * Math.PI;
		RotAdd[2] = angle[2] + 0.25 * Math.PI;
		RotAdd[3] = angle[3] + 0.25 * Math.PI;

	}
	
	public void update(Screen sc) {
		if(!inshop) {
			if(walkingtoshop) {
				if(y == 1300) {
					x += speed;
				}else {
					y += speed;
				}
			}else {
				y += speed;
			}
			if(y > 2000) {
				removePerson();
			}
		}
		updatePoly();
		if(x > 1400) {
			if(!inshop) {
				inshop = true;
				x = 80000;
				y = 1300;
				this.width = 8;
				this.height = 16;
				this.length = 8;
				this.speed = 1;
				updatePoly();
			}
		}
		
		if(inshop) {
			if(shelf_target[shelf_on] == -1) {
				if(80000 > x) {
					x += speed;
				}
				if(80000 < x) {
					x -= speed;
				}
				if(1300 > y) {
					y += speed;
				}
				if(1300 < y) {
					y -= speed;
				}
				if(80000 == x && 1300 == y) {
					sc.custhoughts.add(custhought);
					sc.money += price;
					removePerson();
				}
			}else {
				if(shelf_target[shelf_on] < -1) {
					if(Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).x > x) {
						x += speed;
					}
					if(Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).x < x) {
						x -= speed;
					}
					if(Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).y > y) {
						y += speed;
					}
					if(Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).y < y) {
						y -= speed;
					}
					if(Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).x == x) {
						if(Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).y == y) {
							if(!Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).used || Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).used_by == Screen.People.indexOf(this)) {
								fruitcounter += 1;
								Random random2 = new Random();
								if(fruitcounter > random2.nextInt(25)+4) {
									fruitcounter = 0;
									
									if(fruitindex < colitems.size()) {
										Random random = new Random();
										new Fruit_Type(x+(random.nextInt(20)),y,z+20, -1, null, null, colitems.get(fruitindex), true, 0, false, (short)0);
										Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).used = true;
										Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).used_by = Screen.People.indexOf(this);
									}else {
										new Fruit_Type(x+(10),y,z+20, -1, null, null, 8000, true, 0, false, (short)0);
										Screen.cvey.get(Math.abs(shelf_target[shelf_on]+2)).used = false;
										shelf_target[shelf_on] = -1;
									}
									
									fruitindex += 1;
								}
							}
						}
					}
				}else {
					if(!cafe) {
						if(Screen.Shelfs.get(shelf_target[shelf_on]).x > x) {
							x += speed;
						}
						if(Screen.Shelfs.get(shelf_target[shelf_on]).x < x) {
							x -= speed;
						}
						if(Screen.Shelfs.get(shelf_target[shelf_on]).y > y) {
							y += speed;
						}
						if(Screen.Shelfs.get(shelf_target[shelf_on]).y < y) {
							y -= speed;
						}
						if(Screen.Shelfs.get(shelf_target[shelf_on]).x == x &&
								Screen.Shelfs.get(shelf_target[shelf_on]).y == y) {
									boolean x = false;
									for(int i = 0; i < Screen.fruits.size(); i++) {
										if(Screen.fruits.get(i).shelfid == Screen.Shelfs.get(shelf_target[shelf_on]).id) {
											if(!x) {
												custhought.rating += 1;
												if(custhought.rating > 20) {
													custhought.rating = 20;
												}
												colitems.add(Screen.fruits.get(i).type);
												price += 1;
												Screen.Shelfs.get(shelf_target[shelf_on]).amount -= 1;
												Screen.fruits.get(i).removeCube();
												fruit = true;
												x = true;
											}
										}
									}
									shelf_target[shelf_on] = -2;
									if(shelf_on < shelf_target.length-1) {
										shelf_on += 1;
									}
									if(!x) {
										custhought.rating -= 1;
										if(custhought.rating < 0) {
											custhought.rating = 0;
										}
									}
									return;
						}
					}else {
						boolean there = false;
						byte x = 0;
						byte y = 0;
						byte l = 0;
						if(table_seat[shelf_on] == 0) {
							if(Screen.tables.get(shelf_target[shelf_on]).x > this.x-10) {
								this.x += speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).x < this.x-10) {
								this.x -= speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).y > this.y+12) {
								this.y += speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).y < this.y+12) {
								this.y -= speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).x == this.x-10) {
								if(Screen.tables.get(shelf_target[shelf_on]).y == this.y+12) {
									there = true;
									x = 0;
									y = 10;
									l = 0;
								}
							}
						}
						if(table_seat[shelf_on] == 1) {
							if(Screen.tables.get(shelf_target[shelf_on]).x > this.x-10) {
								this.x += speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).x < this.x-10) {
								this.x -= speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).y > this.y-18) {
								this.y += speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).y < this.y-18) {
								this.y -= speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).x == this.x-10) {
								if(Screen.tables.get(shelf_target[shelf_on]).y == this.y-18) {
									there = true;
									x = 0;
									y = -10;
									l = 1;
								}
							}
						}
						if(table_seat[shelf_on] == 2) {
							if(Screen.tables.get(shelf_target[shelf_on]).x > this.x-40) {
								this.x += speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).x < this.x-40) {
								this.x -= speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).y > this.y+12) {
								this.y += speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).y < this.y+12) {
								this.y -= speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).x == this.x-40) {
								if(Screen.tables.get(shelf_target[shelf_on]).y == this.y+12) {
									there = true;
									x = 0;
									y = 10;
									l = 2;
								}
							}
						}
						if(table_seat[shelf_on] == 3) {
							if(Screen.tables.get(shelf_target[shelf_on]).x > this.x-40) {
								this.x += speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).x < this.x-40) {
								this.x -= speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).y > this.y-18) {
								this.y += speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).y < this.y-18) {
								this.y -= speed;
							}
							if(Screen.tables.get(shelf_target[shelf_on]).x == this.x-40) {
								if(Screen.tables.get(shelf_target[shelf_on]).y == this.y-18) {
									there = true;
									x = 0;
									y = -10;
									l = 3;
								}
							}
						}
						if(there) {
							if(!alreadygot) {
								Random random = new Random();
								new Fruit_Type(this.x+x,this.y+y, 20, -1, null, null, random.nextInt(sc.place.length), false, 0, true, (short)300);
								price += 1;
								alreadygot = true;
							}else {
								cusfoodtime += 1;
								if(cusfoodtime > 300) {
									Screen.tables.get(shelf_target[shelf_on]).used_seats[l] = false;
									shelf_target[shelf_on] = -1;
									if(shelf_on < shelf_target.length-1) {
										shelf_on += 1;
									}
								}
							}
						}
					}
				}
			}
		}
		
	}
	
	void UpdateDirection(double toX, double toY)
	{
		double xdif = toX - (x + width/2) + 0.00001;
		double ydif = toY - (y + length/2) + 0.00001;
		
		double anglet = Math.atan(ydif/xdif) + 0.75 * Math.PI;

		if(xdif<0)
			anglet += Math.PI;

		rotation = anglet;
		updatePoly();		
	}

	void updatePoly()
	{
		for(int i = 0; i < 6; i++)
		{
			Screen.DPolygons.add(Polys[i]);
			Screen.DPolygons.remove(Polys[i]);
		}
		
		double radius = Math.sqrt(width*width + length*length);
		
			   x1 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[0]);
			   x2 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[1]);
			   x3 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[2]);
			   x4 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[3]);
			   
			   y1 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[0]);
			   y2 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[1]);
			   y3 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[2]);
			   y4 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[3]);
   
		Polys[0].x = new double[]{x1, x2, x3, x4};
		Polys[0].y = new double[]{y1, y2, y3, y4};
		Polys[0].z = new double[]{z, z, z, z};

		Polys[1].x = new double[]{x4, x3, x2, x1};
		Polys[1].y = new double[]{y4, y3, y2, y1};
		Polys[1].z = new double[]{z+height, z+height, z+height, z+height};
			   
		Polys[2].x = new double[]{x1, x1, x2, x2};
		Polys[2].y = new double[]{y1, y1, y2, y2};
		Polys[2].z = new double[]{z, z+height, z+height, z};

		Polys[3].x = new double[]{x2, x2, x3, x3};
		Polys[3].y = new double[]{y2, y2, y3, y3};
		Polys[3].z = new double[]{z, z+height, z+height, z};

		Polys[4].x = new double[]{x3, x3, x4, x4};
		Polys[4].y = new double[]{y3, y3, y4, y4};
		Polys[4].z = new double[]{z, z+height, z+height, z};

		Polys[5].x = new double[]{x4, x4, x1, x1};
		Polys[5].y = new double[]{y4, y4, y1, y1};
		Polys[5].z = new double[]{z, z+height, z+height, z};
		
	}

	void removePerson()
	{
		for(int i = 0; i < 6; i ++)
			Screen.DPolygons.remove(Polys[i]);
		Screen.People.remove(this);
	}
}
