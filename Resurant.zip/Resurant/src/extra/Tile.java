package extra;

public class Tile {
	public int type;
}
