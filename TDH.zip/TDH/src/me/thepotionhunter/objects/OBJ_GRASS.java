package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_GRASS extends SuperObect{
	GamePanel gp;
	public OBJ_GRASS(GamePanel gp) {
		this.gp = gp;
		name = "grass";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/grass0.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = false;
	}
}
