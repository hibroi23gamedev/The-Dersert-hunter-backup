package me.thepoitionhunter.main;

import java.awt.Color;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import java.io.File;

import me.thepoitionhunter.entity.*;
import me.thepoitionhunter.entity.player;
import me.thepoitionhunter.tile.TileManager;
import me.thepotionhunter.objects.OBJ_CDOOR;
import me.thepotionhunter.objects.OBJ_PAN;
import me.thepotionhunter.objects.OBJ_PORTAL;
import me.thepotionhunter.objects.SuperObect;
import me.thepotionhunter.worlds.Dersert;
import me.thepotionhunter.worlds.Forset;
import me.thepoitionhunter.extra.*;
import me.thepoitionhunter.net.GameClient;
import me.thepoitionhunter.net.GameServer;
import me.thepoitionhunter.net.packet.*;
import me.thepotionhunter.weapon.*;
import me.thepotionhunter.saveload.*;

import java.util.Random;
public class GamePanel extends JPanel implements Runnable{
	private static final long serialVersionUID = 1L;
	final int originalTileSize = 16;
	final int scale = 3;
	
	public final int tileSize = originalTileSize * scale;
	public final int maxScreenCol = 16;
	public final int maxScreenRow = 12;
	public final int screenWidth = tileSize * maxScreenCol;
	public final int screenHeight = tileSize * maxScreenRow;
	
	public final int maxWorldCol = 50;
	public final int maxWorldRow = 50;
	public final int worldWidth = tileSize * maxWorldCol;
	public final int worldHeight = tileSize * maxWorldRow;
	public int menupick = 0;
	public JFrame frame;
	public int world = 0;
	public int worldchangecounter = 0;
	public int maxthristcounter = (12*60);
	public int maxhungercounter = (15*60);
	public String ip;
	public int port;
	
	public int startinv = 0;
	
	public int mousex = 0;
	public int mousey = 0;
	
	public int pig_number = 0;
	
	TileManager tileM = new TileManager(this);
	public UtilityTool utool = new UtilityTool();
	Thread gameThread;
	public CollisionChecker cChecker = new CollisionChecker(this);
	public AssetSetter aSetter = new AssetSetter(this);
	public SuperWorld[] worlds = new SuperWorld[4];
	Crafting cr = new Crafting(this, utool);
	public KeyHandler keyH = new KeyHandler(this, cr);
	public player Player = new player(this,keyH);
	public SuperObect obj[] = new SuperObect[1000];
	public SuperRain rain[] = new SuperRain[20];
	public Entity npc[] = new Entity[1000];
	public Custom_Object[] cobj = new Custom_Object[9];
	public SuperCustom[] sobj = new SuperCustom[50];
	public Custom_Animal[] cani = new Custom_Animal[9];
	public Super_Animal[] sani = new Super_Animal[500];
	public UI ui = new UI(this, Player, cr, keyH);
	public GameClient socketclient;
	public GameServer socketServer = new GameServer(this);
	public Inventory[] fullinventory = new Inventory[165];
	public ArrayList<Super_Weapon> weapons = new ArrayList<Super_Weapon>();
	public ArrayList<Item> items = new ArrayList<Item>();
	public BufferedImage[] throwing_stick = new BufferedImage[3];
	public SaveLoad saveL = new SaveLoad(this);
	public File[] saves;
	public int weather = 0;
	public float time = 0;
	public final int playState = 1;
	public final int pauseState = 2;
	public final int deadState = 3;
	public final int inventorystate = 4;
	public final int menustate = 5;
	public int gameState = menustate;
	public int menuon = 0;
	public int host = 0;
	public int onmultiplayer = 0;
	public final int spraystate = 6;
	public final int mapstate = 7;
	public int mapselect = 0;
	
	public mouse mouse = new mouse();
	
	Connector connector = new Connector(2000, 24*tileSize, 24*tileSize);
	
	public boolean mouse_pressed = false;
	
	int playerX = 100;
	int playerY = 100;
	int playerSpeed = 1;
	
	int FPS = 60;
	public int wind = 2;
	public int winddirection = 45;
	
	public GamePanel(JFrame frame) {
		this.setPreferredSize(new Dimension(screenWidth, screenHeight));
		this.setBackground(Color.gray);
		this.setDoubleBuffered(true);
		this.addKeyListener(keyH);
		this.addMouseListener(mouse);
		this.setFocusable(true);
		this.frame = frame;
	}
	
	public void setupGame() {
		
		File savefolder = new File("res/saves");
		saves = savefolder.listFiles();
		
		
		
		aSetter.setObject();
		worlds[0] = new Dersert(0);
		
		for(int i = 0; i < obj.length; i++) {
			worlds[0].obj[i] = obj[i];
		}
		
		
		//fullinventory[64] = new Inventory();
		//fullinventory[64].type = 18;
		//fullinventory[64].stack = 64;
		
		cani[0] = new Custom_Animal();
		try {
			cani[0].left = ImageIO.read(getClass().getResourceAsStream("/animals/pig/idle_left.png"));
			cani[0].right = ImageIO.read(getClass().getResourceAsStream("/animals/pig/idle_right.png"));
			cani[0].up = ImageIO.read(getClass().getResourceAsStream("/animals/pig/idle_up.png"));
			cani[0].down = ImageIO.read(getClass().getResourceAsStream("/animals/pig/idle_down.png"));
			cani[0].dead = ImageIO.read(getClass().getResourceAsStream("/animals/pig/pig_dead.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		cani[0].width = 48;
		cani[0].height = 48;
		cani[0].name = "pig";
		cani[0].invgive = 18;
		
		sani[0] = new Super_Animal();
		sani[0].a_type = 0;
		sani[0].worldX = 24*tileSize;
		sani[0].worldY = 24*tileSize;
		
		worlds[1] = new Forset(1);
		worlds[1].obj[0] = new OBJ_CDOOR(this);
		worlds[1].obj[0].worldX = 24*tileSize;
		worlds[1].obj[0].worldY = 8*tileSize;
		worlds[2] = new Forset(2);
		worlds[2].obj[0] = new OBJ_CDOOR(this);
		worlds[2].obj[0].worldX = 24*tileSize;
		worlds[2].obj[0].worldY = 8*tileSize;
		//Custom Objects
		cobj[0] = new Custom_Object();
		try {
			cobj[0].img[0] = ImageIO.read(getClass().getResourceAsStream("/custom/sand_storm/1.png"));
			cobj[0].img[1] = ImageIO.read(getClass().getResourceAsStream("/custom/sand_storm/2.png"));
			cobj[0].img[2] = ImageIO.read(getClass().getResourceAsStream("/custom/sand_storm/3.png"));
			cobj[0].img[3] = ImageIO.read(getClass().getResourceAsStream("/custom/sand_storm/4.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		cobj[0].name = "sand_storm";
		cobj[0].ani = true;
		cobj[0].frame_time = 60;
		
		cobj[1] = new Custom_Object();
		try {
			cobj[1].img[0] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/left.png"));
			cobj[1].img[1] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/left_up.png"));
			cobj[1].img[2] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/up.png"));
			cobj[1].img[3] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/right-up.png"));
			cobj[1].img[4] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/right.png"));
			cobj[1].img[5] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/left_filled.png"));
			cobj[1].img[6] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/left_up_filled.png"));
			cobj[1].img[7] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/up_filled.png"));
			cobj[1].img[8] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/right-up_filled.png"));
			cobj[1].img[9] = ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/right_filled.png"));
		}catch (IOException e) {
			System.out.println("...water transport...how...are...you gonna see the water transport?");
		}
		cobj[1].ani = false;
		cobj[1].name = "water_transport";
		cobj[1].default_width = 96;
		cobj[1].default_height = 96;
		cobj[1].max_place = 4;
		
		weapons.add(new Throwing_Strick(this, 10*tileSize, 20*tileSize, 2));
		
		//Setting Custom Objects
		sobj[0] = new SuperCustom();
		sobj[0].type_index = 0;
		sobj[0].x = 25*tileSize;
		sobj[0].y = 25*tileSize;
		sobj[0].width = 256;
		sobj[0].height = 256;
		
		sobj[1] = new SuperCustom();
		sobj[1].type_index = 1;
		sobj[1].x = 19*tileSize;
		sobj[1].y = 19*tileSize;
		sobj[1].width = 96;
		sobj[1].height = 96;
		
		Player.Inventory[0] = 14;
		
		fullinventory[64] = new Inventory();
		fullinventory[64].type = 19;
		fullinventory[64].stack = 2;
		
		FrameChanger.changeFrameName("The Dersert Hunter");
		
		//ITEMS
		try {
			additem("null", null, 1, 1, 1);  //For emtry items
			additem("sand", ImageIO.read(getClass().getResourceAsStream("/objects/sand.png")), 1, 1, 128);  //index 1
			additem("rock", ImageIO.read(getClass().getResourceAsStream("/objects/rock.png")), 1, 1, 128);  //index 2
			additem("emtry bottle", ImageIO.read(getClass().getResourceAsStream("/objects/emtry bottle.png")), 1, 1, 48);  //index 3
			additem("water bottle", ImageIO.read(getClass().getResourceAsStream("/objects/water bottle.png")), 1, 1, 48);  //index 4
			additem("prewater", ImageIO.read(getClass().getResourceAsStream("/objects/prewater.png")), 1, 2, 16);  //index 5
			additem("dirty water bottle", ImageIO.read(getClass().getResourceAsStream("/objects/dirty water bottle.png")), 1, 1, 48);  //index 6
			additem("stick", ImageIO.read(getClass().getResourceAsStream("/objects/stick.png")), 1,1, 128);  //index 7
			additem("wall", ImageIO.read(getClass().getResourceAsStream("/objects/wall.png")), 1, 1, 16);  //index 8
			additem("fence", ImageIO.read(getClass().getResourceAsStream("/objects/fence.png")), 1, 1, 20);  //index 9
			additem("grass0", ImageIO.read(getClass().getResourceAsStream("/objects/grass0.png")), 1, 1, 128);  //index 10
			additem("wheat", ImageIO.read(getClass().getResourceAsStream("/objects/wheat.png")), 1, 1, 128);  //index 11
			additem("bread", ImageIO.read(getClass().getResourceAsStream("/objects/bread.png")), 1, 1, 128);  //index 12
			additem("spraypaint", ImageIO.read(getClass().getResourceAsStream("/objects/spraypaint.png")), 1, 1, 32);  //index 13
			additem("map", ImageIO.read(getClass().getResourceAsStream("/objects/map.png")), 1, 1, 256);  //index 14
			additem("_swimming",ImageIO.read(getClass().getResourceAsStream("/objects/_SWIM.png")), 1, 1, 1048); // (index 15), not for use
			additem("bacon", ImageIO.read(getClass().getResourceAsStream("/objects/bacon.png")), 1, 1, 128);  //index 16
			additem("dead_pig", ImageIO.read(getClass().getResourceAsStream("/animals/pig/pig_dead.png")), 2, 1, 16);  //index 17
			additem("sandy_dead_pig", ImageIO.read(getClass().getResourceAsStream("/animals/pig/sandy_pig_dead.png")), 2, 1, 16);  //index 18
			additem("water_transport", ImageIO.read(getClass().getResourceAsStream("/objects/water_transport/right.png")), 2, 2, 1); //index 19
			additem("pole", ImageIO.read(getClass().getResourceAsStream("/objects/pole.png")), 1, 2, 4); //index 20
			additem("pole_stick", ImageIO.read(getClass().getResourceAsStream("/objects/pole_stick.png")), 2, 2, 1); //index 21
			additem("pole_sand_stick", ImageIO.read(getClass().getResourceAsStream("/objects/pole_stick_sand.png")), 2, 2, 1); //index 22
			additem("bucket_bottom", ImageIO.read(getClass().getResourceAsStream("/objects/bucket_bottom.png")), 1, 1, 8); //index 23
			additem("bucket_top", ImageIO.read(getClass().getResourceAsStream("/objects/bucket_top.png")), 1, 1, 8); //index 24
			additem("bucket", ImageIO.read(getClass().getResourceAsStream("/objects/bucket.png")), 1, 1, 4); //index 25
			additem("water_holder", ImageIO.read(getClass().getResourceAsStream("/objects/water_collecter.png")), 2, 2, 2); //index 26
			additem("sand_mat", ImageIO.read(getClass().getResourceAsStream("/objects/sand_mat.png")), 2, 2, 8); //index 27
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//WEAPONS
		//	THROWING STICK
		try {
			throwing_stick[0] = ImageIO.read(getClass().getResourceAsStream("/weapons/throwing_stick/s1.png"));
			throwing_stick[1] = ImageIO.read(getClass().getResourceAsStream("/weapons/throwing_stick/s2.png"));
			throwing_stick[2] = ImageIO.read(getClass().getResourceAsStream("/weapons/throwing_stick/s3.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		gameState = playState;
		unlock(0);
	}
	
	public void startGameThread() {
		gameThread = new Thread(this);
		gameThread.start();
		socketclient = new GameClient("localhost", this);
		socketclient.start();
	}

	@Override
	public void run() {
		
		double drawInterval = 1000000000/FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		long timer = 0;
		int drawCount = 0;
		
		gameState = menustate;
		
		while(gameThread != null) {
			currentTime = System.nanoTime();
			delta += (currentTime - lastTime) / drawInterval;
			timer += (currentTime - lastTime);
			lastTime = currentTime;
			if(delta >= 1) {
				update();
				
				repaint();
				delta--;
				drawCount++;
			}
			
			
			if(timer >= 1000000000) {
				
				drawCount = 0;
			}
		}
		
		
	}
	
	public void update() {
		File savefolder = new File("res/saves");
		saves = savefolder.listFiles();
		mousex = MouseInfo.getPointerInfo().getLocation().x-frame.getLocation().x;
		mousey = MouseInfo.getPointerInfo().getLocation().y-frame.getLocation().y;
		for(int i = 0; i < fullinventory.length; i++) {
			if(fullinventory[i] != null) {
				fullinventory[i].update(this,i);
			}
		}
		if(gameState == playState) {
			Player.update();
			time += (float)(0.02);
			for(int i = 0; i < obj.length; i++) {
				if(obj[i] != null) {
					obj[i].update(obj[i].name, i, this);
				}
			}
			
			if(weather == 1) {
				Random random = new Random();
				Random random2 = new Random();
				if(random2.nextInt(9) == 0) {
					rain[random.nextInt(rain.length - 1)] = new SuperRain();
				}			
			}else {
				for(int i = 0; i < rain.length; i++) {
					if(rain[i] != null) {
						rain[i] = null;
					}
				}
			}
			pig_number = 0;
			for(int i = 0; i < sani.length; i++) {
				if(sani[i] != null) {
					if(cani[sani[i].a_type].name == "pig") {
						pig_number += 1;
					}
				}
			}
			Random random6 = new Random();
			if(random6.nextInt(600) == 0 && pig_number < 10) {
				Random random = new Random();
				spawn_animal(0, random6.nextInt(50)*tileSize, random.nextInt(50)*tileSize);
			}
			
			if(Math.floorMod((int) (time*50), 2) == 0) {
				FrameChanger.update(this);
			}
			
			if(FrameChanger.hasReachedTarget()) {
				FrameChanger.changeFrameName("The Dersert Hunter");
			}
			
			Random random3 = new Random();
			if(random3.nextInt(800) == 0) {
				for(int i = 0; i < sobj.length; i++) {
					if(sobj[i] == null) {
						Random random4 = new Random();
						Random random5 = new Random();
						sobj[i] = new SuperCustom();
						sobj[i].type_index = 0;
						sobj[i].x = random4.nextInt(50)*tileSize;
						sobj[i].y = random5.nextInt(50)*tileSize;
						sobj[i].width = 256;
						sobj[i].height = 256;
						return;
					}
				}
			}
			for(int i = 0; i < weapons.size(); i++) {
				if(weapons.get(i) != null) {
					weapons.get(i).update(i, this);
				}
			}
			Random random = new Random();
			if(random.nextInt(400) == 0) {
				if(random.nextInt(2) == 0) {
					weather = 2;
				}else {
					if(weather == 0) {
						weather = 1;
					}else{
						weather = 0;
					}
				}
			}
			
			for(int i = 0; i < sani.length; i++) {
				if(sani[i] != null) {
					sani[i].update(this, i);
				}
			}
			
			for(int i = 0; i < cobj.length; i++) {
				if(cobj[i] != null) {
					//cobj[i].update();
				}
			}
			for(int i = 0; i < sobj.length; i++) {
				if(sobj[i] != null) {
					//sobj[i].update(i, this);
				}
			}
		}
		if(gameState == pauseState) {
			//.**.
		}
		if(gameState == inventorystate) {
			
		}
		if(gameState == menustate) {
			
		}
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		long drawStart = 0;
		drawStart = System.nanoTime();
		tileM.draw(g2);
		for(int i =0; i< obj.length; i++) {
			if(obj[i] != null) {
				if(obj[i].name != "spray") {
					obj[i].draw(obj[i].image,g2, this, obj[i].width, obj[i].height, 0, 0);
				}else {
					int x = 0;
					int y = 0;
					int width = 3;
					int height = 3;
					for(int i1 = 0; i1 < Player.spraywidth*Player.sprayheight; i1++) {
						y += 1;
						if(y > Player.sprayheight) {
							y = 0;
							x += 1;
						}
						if(obj[i].extracounters[i1] == 1) {
							try {
								obj[i].draw(ImageIO.read(getClass().getResourceAsStream("/objects/spraycolors/white.png")), g2, this, width, height, (x*width), (y*height));
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						if(obj[i].extracounters[i1] == 2) {
							try {
								obj[i].draw(ImageIO.read(getClass().getResourceAsStream("/objects/spraycolors/black.png")), g2, this, width, height, (x*width), (y*height));
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
					
					
				}
			}
		}
		if(gameState == playState) {
			for(int i = 0; i<weapons.size(); i++) {
				if(weapons.get(i) != null) {
					weapons.get(i).draw(g2, this);
				}
			}
		}
		for(int i = 0; i<sobj.length; i++) {
			if(sobj[i] != null) {
				sobj[i].draw(g2, this);
			}
		}
		for(int i = 0; i<rain.length; i++) {
			if(rain[i] != null) {
				rain[i].Y += 17;
				g2.setColor(new Color(0,0,110,170));
				g2.fillRect(rain[i].X, rain[i].Y, 16, 32);
			}
		}
		for(int i = 0; i<sani.length; i++) {
			if(sani[i] != null) {
				sani[i].draw(this, g2);
			}
		}
		for(int i = 0; i<npc.length; i++) {
			if(npc[i] != null) {
				npc[i].draw(g2);
			}
		}
		Player.draw(g2);
		
		connector.update(this);
		connector.draw(g2, this);
		
		ui.draw(g2, Player);
		long drawEnd = System.nanoTime();
		long passed = drawEnd - drawStart;
		if (keyH.checkDraw == true) {
			g2.setColor(Color.white);
			g2.drawString("Draw Time: "+passed, 25, screenHeight - 100);
			g2.drawString("Draw Time(In Seconds): "+passed / 1000000000, 25, screenHeight - 80);
			System.out.println("Draw Time: "+passed);
		}
		if(Player.itemhold != 0) {
			System.out.println("G");
			g2.drawImage(items.get(Player.itemhold).img, mousex, mousey, items.get(Player.itemhold).width*32, items.get(Player.itemhold).height*32, null);
		}
		g2.dispose();
		
	}
	public void startserverhost() {
		socketServer = new GameServer(this);
		socketServer.start();
	}
	public void startclienthost() {
		socketclient = new GameClient("localhost", this);
		//socketclient.sendData("ping".getBytes());
		String username = JOptionPane.showInputDialog("Please Enter your username");
		Packet00Login loginPacket = new Packet00Login(username);
		Player.username = username;
		System.out.println("Welcome "+username);
		loginPacket.writeData(socketclient);
		if(host == 0) {
			int port = Integer.parseInt(JOptionPane.showInputDialog("Please enter the port of the server you want to join"));
			this.port = port;
			try {
				socketclient.ipAddress = InetAddress.getByName("127.0.0.1:"+port);
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
		}else {
			int port = Integer.parseInt(JOptionPane.showInputDialog("Please enter the port of the server you are making"));
			this.port = port;
			try {
				socketServer.socket = new DatagramSocket(port);
			} catch (SocketException e) {
				e.printStackTrace();
			}
		}
		socketclient.start();
	}
	public void unlock(int type) {
		if(type == 0) {
			tileM.tile[2].collision = false;
		}
	}
	
	public void spawn_animal(int type, int worldX, int worldY) {
		int spawn = -1;
		for(int i = 0; i < sani.length; i++) {
			if(sani[i] == null) {
				if(spawn == -1) {
					spawn = i;
				}
			}
		}
		sani[spawn] = new Super_Animal();
		sani[spawn].a_type = 0;
		sani[spawn].worldX = 24*tileSize;
		sani[spawn].worldY = 24*tileSize;
	}
	
	public void additem(String name, BufferedImage img, int width, int height, int maxstack) {
		items.add(new Item(name,width,height,img, maxstack));
	}
	
	public class mouse implements MouseListener{

		@Override
		public void mouseClicked(MouseEvent e) {
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			mouse_pressed = true;
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			mouse_pressed = false;
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			
		}
		
	}
}
































