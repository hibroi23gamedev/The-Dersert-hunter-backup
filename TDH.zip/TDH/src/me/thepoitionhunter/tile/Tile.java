package me.thepoitionhunter.tile;

import java.awt.image.BufferedImage;

public class Tile {
	public BufferedImage image;
	public String name;
	public boolean collision = false;
}
