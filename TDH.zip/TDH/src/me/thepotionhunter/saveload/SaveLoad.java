package me.thepotionhunter.saveload;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import me.thepoitionhunter.main.GamePanel;
public class SaveLoad {
	GamePanel gp;
	
	public SaveLoad(GamePanel gp) {
		this.gp = gp;
	}
	public void save(String file) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(file)));
			Data ds = new Data();
			ds.obj = gp.obj;
			oos.writeObject(ds);
			
		} catch (FileNotFoundException e) {
			
		} catch (IOException e) {
			
		}
	}
	public void load(String file) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(file)));
			Data ds = (Data)ois.readObject();
			gp.obj = ds.obj;
		}catch(Exception e) {
			
		}
	}
}
