package building_cs;

public class Owning extends Building_Componment{
	public Owning() {
		
	}

	@Override
	public void update() {
		
	}
	
}
