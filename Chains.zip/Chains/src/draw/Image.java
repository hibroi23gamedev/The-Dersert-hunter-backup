package draw;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;

import main.GamePanel;

import java.awt.geom.AffineTransform;

public class Image {
	public BufferedImage c;
	public int x;
	public int y;
	public int z;
	public int width;
	public int height;
	public int length = 1;
	public int direction;
	public int RES = 2;
	public boolean floor = false;
	public Image(BufferedImage c, int x, int y, int width, int height) {
		this.c = c;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	public Image() {
	}
	
	public void init() {
		if(floor) {
			BufferedImage newC = new BufferedImage(width*2, length*2, BufferedImage.TYPE_INT_ARGB);
			Graphics2D g2 = newC.createGraphics();
			g2.drawImage(c, 0, 0, width*2, length*2, null);
			c = newC;
		}else {
			BufferedImage newC = new BufferedImage(width*2, height*2, BufferedImage.TYPE_INT_ARGB);
			Graphics2D g2 = newC.createGraphics();
			g2.drawImage(c, 0, 0, width*2, height*2, null);
			c = newC;
		}
	}
	
	public void draw(Graphics g, Light light) {
		if(direction > 360) {
			direction = 0;
		}
		Graphics2D g2 = (Graphics2D)g;
		for(int i = -(width); i < width; i+=RES) {
			for(int i1 = -(height); i1 < height; i1+=RES) {
				for(int i2 = 0; i2 < length; i2+=RES) {
					int rc = 0;
					int gc = 0;
					int bc = 0;
					int rgb = 0;
					int a = 0;
					try {
						if(floor) {
							rgb = c.getRGB(i+width, i2*2);
						}else {
							rgb = c.getRGB(i+width, i1+height);
						}
					}catch(ArrayIndexOutOfBoundsException e) {
						
					}
					int x = this.x + (int)((i*Math.sin(Math.toRadians(direction)))
							-(i1*Math.cos(Math.toRadians(direction))));
					int y = this.y + (int)((i1*Math.sin(Math.toRadians(direction)))
							+(i*Math.cos(Math.toRadians(direction))));
					int distanceX = x - light.x;
					int distanceY = y - light.y;
					int distance = (int) Math.sqrt(Math.pow(distanceX, 2) + Math.pow(distanceY, 2));
					distance = (int) Math.abs(distance/light.range);
					
					rc = ((rgb >> 16) & 0xFF);
					gc = ((rgb >> 8) & 0xFF);
					bc = ((rgb & 0xFF));
					
					if(floor) {
						y += i2;
						if(distanceX > 0) {
							x = x-((GamePanel.camZ - (z+i2))+1);
						}else {
							x = x+((GamePanel.camZ - (z+i2))+1);
						}
					}
					
					if(distance < 80*light.range) {
						if(rc != 0 || gc != 0 || bc != 0) {
							rc -= distance;
							if(rc < 1) {
								rc = 1;
							}
							gc -= distance;
							if(gc < 1) {
								gc = 1;
							}
							bc -= distance;
							if(bc < 1) {
								bc = 1;
							}
							
							Color current = new Color(rc, gc, bc);
							g2.setColor(current);
							g2.fillRect(x - GamePanel.camX, y - GamePanel.camY, RES+1, RES+1);
						}
					}
				}
			}
		}
	}
}