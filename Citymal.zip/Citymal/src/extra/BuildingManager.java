package extra;

import models.TexturedModel;
import textures.ModelTexture;
import buildings.*;

public class BuildingManager {
	public static TexturedModel getModelfromType(int id) {
		TexturedModel model = House.model;
		switch(id) {
		case 0:
			model = House.model;
			break;
		case 1:
			model = Market.model;
		}
		return model;
	}
	public static ModelTexture getTexturefromType(int id) {
		ModelTexture texture = House.texture;
		switch(id) {
		case 0:
			texture = House.texture;
			break;
		case 1:
			texture = Market.texture;
		}
		return texture;
	}
}
