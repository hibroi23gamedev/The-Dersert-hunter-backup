package me.thepotionhunter.saveload;

import java.io.Serializable;

import me.thepotionhunter.objects.*;

public class Data implements Serializable{
	public SuperObect[] obj = new SuperObect[10000];
}
