package pathfinding;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Node{

	Node parent;
	public int x;
	public int y;
	int gCost;
	int hCost;
	int fCost;
	boolean start;
	boolean goal;
	public boolean soild;
	boolean open;
	boolean checked;
	
	public Node(int col, int row) {
		this.x = col;
		this.y = row;
	}
	public void setAsStart() {
		start = true;
	}
	public void setAsGoal() {
		goal = true;
	}
	public void setAsSoild() {
		soild = true;
	}
	public void setAsOpen() {
		open = true;
	}
	public void setAsChecked() {
		checked = true;
	}
	public void setAsPath() {
	}
}
