package items;

import java.awt.Graphics;
import java.io.IOException;

import javax.imageio.ImageIO;

import draw.Image;
import draw.Light;
import main.GamePanel;

public class Battery extends Item{

	public Battery(int x, int y, int z) {
		super(x, y, z);
		try {
			this.img = new Image(ImageIO.read(getClass().getResourceAsStream("/items/battries.png")), x, y, 16, 16);
			this.outLineimg = new Image(ImageIO.read(getClass().getResourceAsStream("/items/extra/outline.png")), x, y, 16, 16);
			this.img.init();
			this.outLineimg.init();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void onPickup() {
		GamePanel.light.range += 1;
	}

	@Override
	public void update() {
		//Nothing here! This is for entities that will need non-static variables in the GamePanel! Like the player, this was the first entity
		//to use this void, and not the other one :D
	}
	
}
