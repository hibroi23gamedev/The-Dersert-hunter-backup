package people;

import engineTester.MainGameLoop;
import models.TexturedModel;

import java.util.ArrayList;
import org.lwjgl.util.vector.*;

import extra.*;

import java.util.Random;

import pathfinding.*;

public class Person {
	public TexturedModel model;
	public float x;
	public float z;
	public float ox;
	public float oz;
	public int otimer;
	
	public int money = 0;
	
	public int owned_house = -1;
	
	public int target_building;
	public Vector2f target_building_pos = new Vector2f();
	
	public ArrayList<Vector2f> ppaths = new ArrayList<Vector2f>();
	
	ArrayList<Vector2f> path = new ArrayList<Vector2f>();
	
	public int path_index;
	
	public boolean standing;
	public boolean looking;
	int looking_c;
	
	CityPathfinder finder = new CityPathfinder();
	
	public void setTarget(int x, int y) {
		this.path = finder.setPath((int)TileManager.findtilexy(this.x, this.z).x, (int)TileManager.findtilexy(this.x, this.z).y, x, y);
		for(int i = 0; i < MainGameLoop.tileSize/8; i++) {
			for(int i1 = 0; i1 < MainGameLoop.tileSize/8; i1++) {
				boolean is_path = false;
				for(int i2 = 0; i2 < path.size(); i2++) {
					if(path.get(i2).x == i) {
						if(path.get(i2).y == i1) {
							is_path = true;
						}
					}
				}
				if(MainGameLoop.tiles[i][i1].type == 0) {
					System.out.print(" ");
				}else if(i == x && i1 == y) {
					System.out.print("E");
				}else if(i == TileManager.findtilexy(this.x, this.z).x && i1 == TileManager.findtilexy(this.x, this.z).y) {
					System.out.print("S");
				}else if(is_path) {
					System.out.print("P");
				}else if(MainGameLoop.tiles[i][i1].type == 1) {
					System.out.print("R");
				}
			}
			System.out.println();
		}
		path_index = 0;
	}
	
	public void update() {
		gotoTarget();
		money += 1;
		Random random = new Random();
		if(money > random.nextInt(240)) {
			if(!MainGameLoop.buildings.isEmpty()) {
				if(owned_house == -1) {
					int rand = random.nextInt(MainGameLoop.buildings.size());
					if(!MainGameLoop.buildings.get(rand).owned) {
						MainGameLoop.buildings.get(rand).owned = true;
						this.owned_house = rand;
						money = 0;
					}
				}
			}
		}
		if(looking) {
			looking_c++;
			if(looking_c > 200) {
				looking_c = 0;
				looking = false;
				standing = false;
			}
		}
	}
	
	public void gotoTarget() {
		if(path.size() > 2 && !standing) {
			Vector2f roadpos = TileManager.findtilexy(x, z);
			int dir = 0;
			if(path.get(path_index).x > roadpos.x) {
				dir = 0;
			}else if(path.get(path_index).x < roadpos.x) {
				dir = 1;
			}else if(path.get(path_index).y > roadpos.y) {
				dir = 2;
			}else if(path.get(path_index).y < roadpos.y) {
				dir = 3;
			}else{
				dir = 4;
			}
			float speed = 0.2f;
			switch(dir) {
			case 0:
				x += speed;
				break;
			case 1:
				x -= speed;
				break;
			case 2:
				z += speed;
				break;
			case 3:
				z -= speed;
				break;
			case 4:
				path_index++;
				if(path_index >= path.size()) {
					Random random = new Random();
					int x = random.nextInt(128);
	   			 	int y = random.nextInt(128);
	   			 	while(MainGameLoop.tiles[x][y].type == 0) {
	   			 		x = random.nextInt(128);
	   			 		y = random.nextInt(128);
	   			 	}
	   			 	setTarget(x, y);
	   			 	standing = true;
	   			 	looking = true;
				}
				break;
			}
			if(path.size() == 0) {
				Random random = new Random();
				int x = random.nextInt(128);
   			 	int y = random.nextInt(128);
   			 	while(MainGameLoop.tiles[x][y].type == 0) {
   			 		x = random.nextInt(128);
   			 		y = random.nextInt(128);
   			 	}
   			 	setTarget(x, y);
			}
			ox = x;
			oz = z;
		}
	}
}
