package me.thepoitionhunter.main;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.entity.player;

public class Crafting {
	GamePanel gp;
	BufferedImage basecimage;
	BufferedImage basesimage;
	UtilityTool utool;
	KeyHandler keyH;
	public int[] craftingnames = new int[20];
	public int[] craftingfirsts = new int[20];
	public int[] craftinglasts = new int[20];
	public int[] craftingresults = new int[20];
	int indexCraft = 0;
	int selcrindex = 0;
	public Crafting(GamePanel gp, UtilityTool utool) {
		newCraft(5,1,2,5);
		newCraft(8,7,2,8);
		newCraft(9,7,1,9);
		newCraft(11,10,10,12);
		newCraft(12,11,11,12);
		newCraft(13,2,2,13);
		newCraft(1,2,4,15);
		newCraft(20,7,7,20);
		newCraft(21,20,7,21);
		newCraft(22,21,1,22);
		newCraft(23,7,2,23);
		newCraft(24,7,2,24);
		newCraft(25,23,24,25);
		newCraft(19,22,25,19);
		this.gp = gp;
		this.utool = utool;
		this.keyH = keyH;
		try {
			basecimage = ImageIO.read(getClass().getResourceAsStream("/objects/craftingbase.png"));
			basesimage = ImageIO.read(getClass().getResourceAsStream("/objects/craftingbasesel.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void makeCraft(Graphics2D g2, KeyHandler keyH, player pla, int x) {
		int starty = 100;
		int startx = x;
		int max = craftingnames.length;
		if(max > 8+(gp.startinv)) {
			max = 8;
		}
		for(int i = gp.startinv; i < max+gp.startinv; i++) {
			if(craftingnames[i] != 0) {
				if(starty > 500) {
					starty = 100;
					startx += 160;
				}
				if(i == selcrindex) {
					g2.drawImage(basesimage, startx, starty - 30, null);
					if(keyH.zpressed == true) {
						if(craftingresults[selcrindex] != 0) {
							int hasfirst = -1;
							int haslast = -1;
						
							for(int i1 = 0; i1 < pla.Inventory.length; i1++) {
								if(pla.Inventory[i1] == craftingfirsts[i]) {
									hasfirst = i1;
								}
							}
							for(int i1 = 0; i1 < pla.Inventory.length; i1++) {
								if(pla.Inventory[i1] == craftinglasts[i]) {
									if(hasfirst != i1) {
										haslast = i1;
									}
								}
							}
							if(hasfirst != -1 && haslast != -1) {
								pla.Inventory[hasfirst] = 0;
								pla.Inventory[haslast] = 0;
								pla.Inventory[gp.utool.findLengthofList(gp.Player.Inventory, 0)] = craftingnames[i];
							}
						}else {
							gp.unlock(0);
						}
					}
				}else {
					g2.drawImage(basecimage, startx, starty - 30, null);
				}
				BufferedImage image;
				image = gp.items.get(craftingfirsts[i]).img;
				image = utool.scaleImage(image, 32, 32);
				g2.drawImage(image, startx+15, starty, null);
				BufferedImage image2;
				image2 = gp.items.get(craftinglasts[i]).img;
				image2 = utool.scaleImage(image2, 32, 32);
				g2.drawImage(image2, startx+47, starty, null);
				try {
					BufferedImage image3;
					image3 = ImageIO.read(getClass().getResourceAsStream("/ui/equal_craft.png"));
					image3 = utool.scaleImage(image3, 32, 32);
					g2.drawImage(image3, startx+79, starty, null);
				} catch (IOException e) {
					e.printStackTrace();
				}
				BufferedImage image4;
				image4 = gp.items.get(craftingresults[i]).img;
				image4 = utool.scaleImage(image4, 32, 32);
				g2.drawImage(image4, startx+101, starty, null);
			}
			starty += 120;
		}
	}
	void newCraft(int name, int first, int last, int result) {
		craftingnames[indexCraft] = name;
		craftingfirsts[indexCraft] = first;
		craftinglasts[indexCraft] = last;
		craftingresults[indexCraft] = result;
		indexCraft += 1;
	}
}