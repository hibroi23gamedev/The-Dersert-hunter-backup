package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_MAP extends SuperObect{
	GamePanel gp;
	public OBJ_MAP(GamePanel gp) {
		this.gp = gp;
		name = "map";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/map.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = false;
	}
}
