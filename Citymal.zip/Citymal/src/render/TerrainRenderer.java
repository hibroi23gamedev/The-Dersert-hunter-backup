package render;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import models.RawModel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import shaders.TerrainShader;
import terrains.Terrain;
import textures.ModelTexture;
import textures.TerrainTexturePack;
import toolbox.Maths;

public class TerrainRenderer {
   private TerrainShader shader;
   private ModelTexture texture;

   public TerrainRenderer(TerrainShader shader, Matrix4f projectionMatrix, ModelTexture texture) {
      this.shader = shader;
      shader.start();
      shader.loadProjectionMatrix(projectionMatrix);
      shader.connectTextureUnits();
      shader.stop();
      this.texture = texture;
   }

   public void render(List<Terrain> terrains, Matrix4f toShadowSpace) {
      this.shader.loadToShadowSpaceMatrix(toShadowSpace);
      Iterator var4 = terrains.iterator();

      while(var4.hasNext()) {
         Terrain terrain = (Terrain)var4.next();
         this.prepareTerrain(terrain);
         this.loadModelMatrix(terrain);
         GL11.glDrawElements(4, terrain.getModel().getVertexCount(), 5125, 0L);
         this.unbindTerrain();
      }

   }

   private void prepareTerrain(Terrain terrain) {
      RawModel rmodel = terrain.getModel();
      GL30.glBindVertexArray(rmodel.getVaoID());
      GL20.glEnableVertexAttribArray(0);
      GL20.glEnableVertexAttribArray(1);
      GL20.glEnableVertexAttribArray(2);
      new Random();
      this.bindTextures(terrain);
      this.shader.loadShineVarables(1.0F, 0.0F);
   }

   private void bindTextures(Terrain terrain) {
      TerrainTexturePack texturePack = terrain.getTexturePack();
      GL13.glActiveTexture(33984);
      GL11.glBindTexture(3553, texturePack.getBackgroundTexture().getTextureID());
      GL13.glActiveTexture(33985);
      GL11.glBindTexture(3553, texturePack.getrTexture().getTextureID());
      GL13.glActiveTexture(33986);
      GL11.glBindTexture(3553, texturePack.getgTexture().getTextureID());
      GL13.glActiveTexture(33987);
      GL11.glBindTexture(3553, texturePack.getbTexture().getTextureID());
      GL13.glActiveTexture(33988);
      GL11.glBindTexture(3553, terrain.getBlendMap().getTextureID());
   }

   private void unbindTerrain() {
      GL20.glDisableVertexAttribArray(0);
      GL20.glDisableVertexAttribArray(1);
      GL20.glDisableVertexAttribArray(2);
      GL30.glBindVertexArray(0);
   }

   private void loadModelMatrix(Terrain terrain) {
      Matrix4f transformationMatrix = Maths.createTransformation(new Vector3f(terrain.getX(), 0.0F, terrain.getZ()), 0.0F, 0.0F, 0.0F, 1.0F);
      this.shader.loadTransformationMatrix(transformationMatrix);
   }
}
