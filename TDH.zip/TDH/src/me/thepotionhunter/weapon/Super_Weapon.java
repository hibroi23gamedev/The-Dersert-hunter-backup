package me.thepotionhunter.weapon;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import me.thepoitionhunter.main.GamePanel;
import me.thepotionhunter.objects.*;

public class Super_Weapon {
	public int worldX;
	public int worldY;
	public int counter;
	public int time;
	public int frame;
	public String name = "Throwing_Stick";
	int direction = 2;
	public BufferedImage[] img;
	
	public void draw(Graphics2D g2, GamePanel gp) {
		int screenX = worldX - gp.Player.worldX + gp.Player.ScreenX;
		int screenY = worldY - gp.Player.worldY + gp.Player.ScreenY;
		
		if(worldX > (gp.Player.worldX - gp.Player.ScreenX)-48 &&
				worldX < (gp.Player.worldX + gp.Player.ScreenX)+48 &&
				worldY > (gp.Player.worldY - gp.Player.ScreenY)-48 &&
				worldY < (gp.Player.worldY + gp.Player.ScreenY)+48) {
		g2.drawImage(img[frame], screenX, screenY, 48, 48, null);
		}
	}
	public void update(int index, GamePanel gp) {
		switch(name) {
		case "Throwing_Stick":
			counter += 1;
			if(counter >= 30) {
				counter = 0;
				frame += 1;
				if(frame >= 2) {
					frame = 0;
				}
			}
			time += 1;
			if(time >= 150) {
				boolean a = false;
				for(int i = 0; i < gp.Player.Inventory.length; i++) {
					if(gp.Player.Inventory[i] == 0) {
						if(!a) {
							a = true;
							gp.Player.Inventory[i] = 7;
						}
					}
				}
				gp.weapons.remove(index);
			}
			int speed = 6;
			switch(direction) {
			case 0:
				worldY -= speed;
				break;
			case 1:
				worldY += speed;
				break;
			case 2:
				worldX += speed;
				break;
			case 3:
				worldX -= speed;
				break;
			}
			
			boolean b = false;
			for(int i = 0; i < gp.sani.length; i++) {
				if(gp.sani[i] != null) {
					if(worldX >= gp.sani[i].worldX) {
						if(worldX <= gp.sani[i].worldX+gp.tileSize) {
							if(worldY >= gp.sani[i].worldY) {
								if(worldY <= gp.sani[i].worldY+gp.tileSize) {
									if(!b) {
										gp.sani[i].dead = true;
										boolean a = false;
										for(int i1 = 0; i1 < gp.Player.Inventory.length; i1++) {
											if(gp.Player.Inventory[i1] == 0) {
												if(!a) {
													a = true;
													gp.Player.Inventory[i1] = 7;
												}
											}
										}
										gp.weapons.remove(index);
									}
								}
							}
						}
					}
				}
			}
			
			break;
		}
	}
}
