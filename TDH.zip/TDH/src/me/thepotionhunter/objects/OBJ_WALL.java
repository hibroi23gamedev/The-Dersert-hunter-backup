package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_WALL extends SuperObect{
	GamePanel gp;
	public OBJ_WALL(GamePanel gp) {
		this.gp = gp;
		name = "wall";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/wall.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = true;
	}
}
