package extra;

public class Thought {
	public String thought;
	public int rating;
}
