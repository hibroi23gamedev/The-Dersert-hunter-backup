package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_PREWATER extends SuperObect{
	GamePanel gp;
	public OBJ_PREWATER(GamePanel gp) {
		this.gp = gp;
		name = "prewater";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/prewater.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = false;
	}
}
