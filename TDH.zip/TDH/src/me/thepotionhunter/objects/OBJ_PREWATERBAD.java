package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_PREWATERBAD extends SuperObect{
	GamePanel gp;
	public OBJ_PREWATERBAD(GamePanel gp) {
		this.gp = gp;
		name = "prewaterbad";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/prewaterbad.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = false;
	}
}
