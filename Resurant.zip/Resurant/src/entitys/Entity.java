package entitys;

import models.TexturedModel;
import render.Loader;
import render.MasterRenderer;
import render.ModelData;

import java.util.ArrayList;

import org.lwjgl.util.vector.Vector3f;
import terrains.Terrain;

public class Entity {
   public TexturedModel model;
   protected Vector3f position;
   
   private Vector3f[] positions_for_string;
   
   public float rotX;
   public float rotY;
   public float rotZ;
   protected float scale;
   protected float speedy;
   protected float speedx;
   protected float speedz;
   protected short phy_counter;
   
   float oldterrainheight = 0.0F;
   float oldx;
   float oldz;
   
   public boolean phy = true;

   public Entity(TexturedModel model, Vector3f position, float rotX, float rotY, float rotZ, float scale) {
      this.model = model;
      this.position = position;
      this.rotX = rotX;
      this.rotY = rotY;
      this.rotZ = rotZ;
      this.scale = scale;
      setStringPositions(100);
   }
   
   public void setStringPositions(int length) {
	   positions_for_string = new Vector3f[length];
	   positions_for_string[0] = null;
   }

   public void increasePosition(float dx, float dy, float dz) {
      Vector3f var10000 = this.position;
      var10000.x += dx;
      var10000 = this.position;
      var10000.y += dy;
      var10000 = this.position;
      var10000.z += dz;
   }

   public void increaseRotation(float dx, float dy, float dz) {
      this.rotX += dx;
      this.rotY += dy;
      this.rotZ += dz;
   }

   public void processPhysics(Terrain terrain, Player player, boolean string, MasterRenderer renderer) {
      if (this.phy) {
         this.speedy -= 0.004F;
         Vector3f var10000 = this.position;
         var10000.y += this.speedy;
         if (this.position.y < terrain.getHeightOfTerrain(this.position.x, this.position.z)) {
            this.position.y = terrain.getHeightOfTerrain(this.position.x, this.position.z);
            this.speedy = 0.0F;
         }

         if (this.position.y > terrain.getHeightOfTerrain(this.position.x - 0.005F, this.position.z)) {
            this.speedx -= 0.003F;
         } else if (this.position.y > terrain.getHeightOfTerrain(this.position.x + 0.005F, this.position.z)) {
            this.speedx += 0.003F;
         } else {
            this.speedx = 0.0F;
         }

         var10000 = this.position;
         var10000.x += this.speedx / 4.0F;
         if (this.position.y > terrain.getHeightOfTerrain(this.position.x, this.position.z - 0.005F)) {
            this.speedz -= 0.003F;
         } else if (this.position.y > terrain.getHeightOfTerrain(this.position.x, this.position.z + 0.005F)) {
            this.speedz += 0.003F;
         } else {
            this.speedz = 0.0F;
         }

         var10000 = this.position;
         var10000.z += this.speedz / 4.0F;
         int range = 2;
         if (this.position.x - (float)range < player.getPosition().x && this.position.x + (float)range > player.getPosition().x && this.position.z - (float)range < player.getPosition().z && this.position.z + (float)range > player.getPosition().z && this.position.y - (float)range < player.getPosition().y && this.position.y + (float)range > player.getPosition().y) {
            if (this.position.x < player.getPosition().x) {
               this.speedx -= 0.1F;
            }

            if (this.position.x > player.getPosition().x) {
               this.speedx += 0.1F;
            }

            if (this.position.z < player.getPosition().z) {
               this.speedz -= 0.1F;
            }

            if (this.position.z > player.getPosition().z) {
               this.speedx += 0.1F;
            }
         }
         
         float terrainHeight = terrain.getHeightOfTerrain(position.x, position.z);
         if ((double)terrainHeight - 0.3D > (double)this.oldterrainheight) {
             terrainHeight = this.oldterrainheight;
             speedx = 0-speedx;
             speedz = 0-speedz;
             position.y = terrainHeight;
             position.x = this.oldx;
             position.z = this.oldz;
          }
         
         if(string) {
        	positions_for_string[0] = position;
        	for(int i = positions_for_string.length-1; i > 1; i--) {
        		if(positions_for_string[i] != null) {
        			positions_for_string[i] = positions_for_string[i + 1];
        		}
        	}
        	for(int i = 0; i < positions_for_string.length; i++) {
        		if(positions_for_string[i] != null) {
        			renderer.processEntity(new Entity(model, positions_for_string[i], 0, 0, 0, scale));
        		}
        	}
         }
         
         oldx = position.x;
         oldz = position.z;
         oldterrainheight = terrainHeight;
         
      }

   }

   public TexturedModel getModel() {
      return this.model;
   }

   public void setModel(TexturedModel model) {
      this.model = model;
   }

   public Vector3f getPosition() {
      return this.position;
   }

   public void setPosition(Vector3f position) {
      this.position = position;
   }

   public float getRotX() {
      return this.rotX;
   }

   public void setRotX(float rotX) {
      this.rotX = rotX;
   }

   public float getRotY() {
      return this.rotY;
   }

   public void setRotY(float rotY) {
      this.rotY = rotY;
   }

   public float getRotZ() {
      return this.rotZ;
   }

   public void setRotZ(float rotZ) {
      this.rotZ = rotZ;
   }

   public float getScale() {
      return this.scale;
   }

   public void setScale(float scale) {
      this.scale = scale;
   }
}
