package shadows;

import entitys.Entity;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import models.RawModel;
import models.TexturedModel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Matrix4f;
import render.MasterRenderer;
import toolbox.Maths;

public class ShadowMapEntityRenderer {
   private Matrix4f projectionViewMatrix;
   private ShadowShader shader;

   protected ShadowMapEntityRenderer(ShadowShader shader, Matrix4f projectionViewMatrix) {
      this.shader = shader;
      this.projectionViewMatrix = projectionViewMatrix;
   }

   protected void render(Map<TexturedModel, List<Entity>> entities) {
	   Iterator var3 = entities.keySet().iterator();

	      while(var3.hasNext()) {
	         TexturedModel model = (TexturedModel)var3.next();
	         if(model != null) {
	        	 RawModel rawModel = model.getModel();
		         this.bindModel(rawModel);
		         GL13.glActiveTexture(33984);
		         GL11.glBindTexture(3553, model.getTexture().getID());
		         if (model.getTexture().isHasTransparency()) {
		            MasterRenderer.disableCulling();
		         }

		         Iterator var6 = ((List)entities.get(model)).iterator();

		         while(var6.hasNext()) {
		            Entity entity = (Entity)var6.next();
		            this.prepareInstance(entity);
		            GL11.glDrawElements(4, rawModel.getVertexCount(), 5125, 0L);
		         }

		         if (model.getTexture().isHasTransparency()) {
		            MasterRenderer.enableCulling();
		         }
	         }
	      }

	      GL20.glDisableVertexAttribArray(0);
	      GL20.glDisableVertexAttribArray(1);
	      GL30.glBindVertexArray(0);
   }

   private void bindModel(RawModel rawModel) {
      GL30.glBindVertexArray(rawModel.getVaoID());
      GL20.glEnableVertexAttribArray(0);
      GL20.glEnableVertexAttribArray(1);
   }

   private void prepareInstance(Entity entity) {
      Matrix4f modelMatrix = Maths.createTransformation(entity.getPosition(), entity.getRotX(), entity.getRotY(), entity.getRotZ(), entity.getScale());
      Matrix4f mvpMatrix = Matrix4f.mul(this.projectionViewMatrix, modelMatrix, (Matrix4f)null);
      this.shader.loadMvpMatrix(mvpMatrix);
   }
}
