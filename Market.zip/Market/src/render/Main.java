package render;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Main 
{	
	static Dimension ScreenSize = Toolkit.getDefaultToolkit().getScreenSize();
	static JTextField TF;
	
	public static void main(String[] args)
	{
		//JButton button = new JButton();
		//button.setBounds(50,200,80,40);
		JFrame F = new JFrame();
		F.setUndecorated(true);
	    F.setSize(ScreenSize);
		//F.setSize(800,600);
		Screen ScreenObject = new Screen(F);
		ScreenObject.frame = F;
		F.add(ScreenObject);
		//F.add(button);
		F.setTitle("Market");
		F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		F.setVisible(true);
	}
}
