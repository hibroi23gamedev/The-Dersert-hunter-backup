package terrains;

import java.util.Random;

public class HeightsGenerator {
   private static final float AMPLITUDE = 20.0F;
   private static final int OCTAVES = 1;
   private static final float ROUGHNESS = 0.001F;
   private Random random = new Random();
   public int seed;

   public HeightsGenerator() {
      //seed = this.random.nextInt(1000000000);
	   
	  //this.seed = 9999999;
	  this.seed = 243958;
   }

   public float generateHeight(int x, int z) {
      float total = 0.0F;
      float d = (float)Math.pow(2.0D, 2.0D);

      for(int i = 0; i < OCTAVES; ++i) {
         float freq = (float)(Math.pow(2.0D, (double)i) / (double)d);
         float amp = (float)Math.pow(ROUGHNESS, (double)i) * AMPLITUDE;
         total += this.getInterpolatedNoise(((float)x + freq) * freq, ((float)z + freq) * freq) * amp;
      }

      return total;
   }

   private float getInterpolatedNoise(float x, float z) {
      int intX = (int)x;
      int intZ = (int)z;
      float fracX = x - (float)intX;
      float fracZ = z - (float)intZ;
      float v1 = this.getSmoothNoise(intX, intZ);
      float v2 = this.getSmoothNoise(intX + 1, intZ);
      float v3 = this.getSmoothNoise(intX, intZ + 1);
      float v4 = this.getSmoothNoise(intX + 1, intZ + 1);
      float i1 = this.interpolate(v1, v2, fracX);
      float i2 = this.interpolate(v3, v4, fracZ);
      return this.interpolate(i1, i2, fracZ);
   }

   private float interpolate(float a, float b, float blend) {
      double theta = (double)blend * 3.141592653589793D;
      float f = (float)(1.0D - Math.cos(theta)) * 0.5F;
      return a * (1.0F - f) + b * f;
   }

   private float getSmoothNoise(int x, int z) {
      float corners = (this.getNoise(x - 1, z - 1) + this.getNoise(x + 1, z - 1) + this.getNoise(x - 1, z + 1) + this.getNoise(x + 1, z + 1)) / 16.0F;
      float sides = (this.getNoise(x + 1, z) + this.getNoise(x, z + 1) + this.getNoise(x - 1, z) + this.getNoise(x, z - 1)) / 8.0F;
      float center = this.getNoise(x, z) / 4.0F;
      return corners + sides + center;
   }

   private float getNoise(int x, int z) {
      this.random.setSeed((long)(x * '쇠' + z * 325176 + this.seed));
      return this.random.nextFloat() * 2.0F - 1.0F;
   }
}
