package particles;

import java.util.List;

public class InsertionSort {
   public static void sortHighToLow(List<Particle> list) {
      for(int i = 1; i < list.size(); ++i) {
         Particle item = (Particle)list.get(i);
         if (item.getDistance() > ((Particle)list.get(i - 1)).getDistance()) {
            sortUpHighToLow(list, i);
         }
      }

   }

   private static void sortUpHighToLow(List<Particle> list, int i) {
      Particle item = (Particle)list.get(i);

      int attemptPos;
      for(attemptPos = i - 1; attemptPos != 0 && ((Particle)list.get(attemptPos - 1)).getDistance() < item.getDistance(); --attemptPos) {
      }

      list.remove(i);
      list.add(attemptPos, item);
   }
}
