package particles;

import entitys.Camera;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.lwjgl.util.vector.Matrix4f;
import render.Loader;

public class ParticleMaster {
   private static Map<ParticleTexture, List<Particle>> particles = new HashMap();
   private static ParticleRenderer renderer;

   public static void init(Loader loader, Matrix4f project) {
      renderer = new ParticleRenderer(loader, project);
   }

   public static void update(Camera camera) {
      Iterator mapIterator = particles.entrySet().iterator();

      while(mapIterator.hasNext()) {
         List<Particle> list = (List)((Entry)mapIterator.next()).getValue();
         Iterator iterator = list.iterator();

         while(iterator.hasNext()) {
            Particle p = (Particle)iterator.next();
            boolean stillAlive = p.update(camera);
            if (!stillAlive) {
               mapIterator.remove();
            }
         }

         InsertionSort.sortHighToLow(list);
      }

   }

   public static void renderParticles(Camera cam) {
      renderer.render(particles, cam);
   }

   public static void cleanUp() {
      renderer.cleanUp();
   }

   public static void addParticle(Particle particle) {
      List<Particle> list = (List)particles.get(particle.getTexture());
      if (list == null) {
         list = new ArrayList();
         particles.put(particle.getTexture(), list);
      }

      ((List)list).add(particle);
   }
}
