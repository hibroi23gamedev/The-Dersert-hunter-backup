package fruits;

import java.util.Random;

import render.DPolygon;
import render.Screen;

public class Fruit {
	public String name;
	public DPolygon[] model = new DPolygon[500];
	public int shelfid;
	
	public double x;
	public double y;
	public double z;
	public int width;
	public int height;
	public int length;
	public double[] RotAdd = new double[4];
	public double[] angle;
	public double x1, x2, x3, x4, y1, y2, y3, y4;
	double rotation = Math.PI*0.75;
	public int type;
	public boolean conv;
	
	public double price;
	
	public double speed;
	
	public boolean remove;
	public short aftertime;
	
	public short timelasted = 0;
	
	public Fruit(int shelfid, boolean conv, boolean remove, short aftertime) {
		this.shelfid = shelfid;
		this.conv = conv;
		this.remove = remove;
		this.aftertime = aftertime;
		Random random = new Random();
		this.speed = random.nextDouble()/1.3;
	}
	
	public void updatePoly()
	{
		for(int i = 0; i < 17; i++)
		{
			Screen.DPolygons.add(model[i]);
			Screen.DPolygons.remove(model[i]);
		}
		
		double radius = Math.sqrt(width*width + length*length);
		
			   x1 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[0]);
			   x2 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[1]);
			   x3 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[2]);
			   x4 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[3]);
			   
			   y1 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[0]);
			   y2 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[1]);
			   y3 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[2]);
			   y4 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[3]);
   
		model[0].x = new double[]{x1, x2, x3, x4};
		model[0].y = new double[]{y1, y2, y3, y4};
		model[0].z = new double[]{z, z, z, z};

		model[1].x = new double[]{x4, x3, x2, x1};
		model[1].y = new double[]{y4, y3, y2, y1};
		model[1].z = new double[]{z+height, z+height, z+height, z+height};
			   
		model[2].x = new double[]{x1, x1, x2, x2};
		model[2].y = new double[]{y1, y1, y2, y2};
		model[2].z = new double[]{z, z+height, z+height, z};

		model[3].x = new double[]{x2, x2, x3, x3};
		model[3].y = new double[]{y2, y2, y3, y3};
		model[3].z = new double[]{z, z+height, z+height, z};

		model[4].x = new double[]{x3, x3, x4, x4};
		model[4].y = new double[]{y3, y3, y4, y4};
		model[4].z = new double[]{z, z+height, z+height, z};

		model[5].x = new double[]{x4, x4, x1, x1};
		model[5].y = new double[]{y4, y4, y1, y1};
		model[5].z = new double[]{z, z+height, z+height, z};
		
	}
	
	public void removeCube()
	{
		for(int i = 0; i < 500; i ++)
			if(model[i] != null) {
				Screen.DPolygons.remove(model[i]);
			}
		Screen.fruits.remove(this);
	}
}
