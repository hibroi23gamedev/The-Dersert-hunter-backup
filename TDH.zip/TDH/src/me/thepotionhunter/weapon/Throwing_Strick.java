package me.thepotionhunter.weapon;

import me.thepoitionhunter.main.GamePanel;

public class Throwing_Strick extends Super_Weapon{
	public Throwing_Strick(GamePanel gp, int worldX, int worldY, int direction) {
		this.img = gp.throwing_stick;
		this.worldX = worldX;
		this.worldY = worldY;
		this.direction = direction;
	}
	
	public void update() {
		counter += 1;
		if(counter >= 30) {
			counter = 0;
			frame += 1;
			if(frame > 2) {
				frame = 0;
			}
		}
		int speed = 6;
		switch(direction) {
		case 0:
			worldY -= speed;
			break;
		case 1:
			worldY += speed;
			break;
		case 2:
			worldX += speed;
			break;
		case 3:
			worldX -= speed;
			break;
		}
		
		
	}
}
