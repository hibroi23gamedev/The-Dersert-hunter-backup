package buildings;

import java.util.ArrayList;

import building_cs.Building_Componment;
import building_cs.*;
import models.TexturedModel;
import render.Loader;
import render.ModelData;
import render.OBJFileLoader;
import textures.ModelTexture;
import models.RawModel;

public class House extends Building_Type{
	static String name = "House";
	static String description = "a simple house";
	public static TexturedModel model;
	static ArrayList<Building_Componment> components = new ArrayList<Building_Componment>();

	public House(Loader loader) {
		super(name, description, components);
		ModelData data = OBJFileLoader.loadOBJ("buildings/house");
		RawModel raw = loader.loadtoVAO(data.getVertices(), data.getTextureCoords(), data.getNormals(), data.getIndices(), data);
		ModelTexture texture = new ModelTexture(loader.loadTexture("buildings/house"));
		House.texture = texture;
		TexturedModel model = new TexturedModel(raw, texture);
		House.model = model;
		this.id = 0;
		this.components.add(new Owning());
	}

	@Override
	public void update() {
		
	}
}
