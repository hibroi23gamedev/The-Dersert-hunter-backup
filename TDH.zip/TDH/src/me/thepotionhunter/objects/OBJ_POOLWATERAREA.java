package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_POOLWATERAREA extends SuperObect{
	GamePanel gp;
	public OBJ_POOLWATERAREA(GamePanel gp, int groupindex) {
		this.gp = gp;
		name = "Pool1";
		counter = 5;
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/poolpartone.png"));
			uTool.scaleImage(image,48, 48);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = true;
		group = groupindex;
	}
}
