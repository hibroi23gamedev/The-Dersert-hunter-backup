package me.thepoitionhunter.entity;

import java.net.InetAddress;

import me.thepoitionhunter.main.GamePanel;
import me.thepoitionhunter.main.KeyHandler;

public class playermp extends player{
	public InetAddress ipAddress;
	public int port;
	public playermp(GamePanel gp, KeyHandler keyH, InetAddress ipAddress, int port) {
		super(gp, keyH);
		this.ipAddress = ipAddress;
		this.port = port;
		
	}
}
