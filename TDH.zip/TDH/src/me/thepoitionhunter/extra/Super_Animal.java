package me.thepoitionhunter.extra;

import java.awt.Graphics2D;
import java.util.Random;

import me.thepoitionhunter.main.GamePanel;

public class Super_Animal {
	public int a_type;
	public int worldX;
	public int worldY;
	public int direction = 2;
	public boolean dead = false;
	public int counter;
	
	public void draw(GamePanel gp, Graphics2D g2) {
		int screenX = worldX - gp.Player.worldX + gp.Player.ScreenX;
		int screenY = worldY - gp.Player.worldY + gp.Player.ScreenY;
		
		if(worldX > (gp.Player.worldX - gp.Player.ScreenX)-48 &&
				worldX < (gp.Player.worldX + gp.Player.ScreenX)+48 &&
				worldY > (gp.Player.worldY - gp.Player.ScreenY)-48 &&
				worldY < (gp.Player.worldY + gp.Player.ScreenY)+48) {
		if(dead) {
			g2.drawImage(gp.cani[a_type].dead, screenX, screenY, gp.cani[a_type].width, gp.cani[a_type].height, null);
		}else {
			switch(direction) {
			case 0:
				g2.drawImage(gp.cani[a_type].up, screenX, screenY, gp.cani[a_type].width, gp.cani[a_type].height, null);
				break;
			case 1:
				g2.drawImage(gp.cani[a_type].down, screenX, screenY, gp.cani[a_type].width, gp.cani[a_type].height, null);
				break;
			case 2:
				g2.drawImage(gp.cani[a_type].left, screenX, screenY, gp.cani[a_type].width, gp.cani[a_type].height, null);
				break;
			case 3:
				g2.drawImage(gp.cani[a_type].right, screenX, screenY, gp.cani[a_type].width, gp.cani[a_type].height, null);
				break;
			}
		}
		}
	}
	
	public void update(GamePanel gp, int index) {
		if(dead) {
			if(gp.keyH.xpressed) {
				boolean c = false;
				for(int i1 = 0; i1 < gp.Player.Inventory.length; i1++) {
					if(gp.Player.Inventory[i1] == 0) {
						if(!c) {
							c = true;
							gp.Player.Inventory[i1] = gp.cani[a_type].invgive;
						}
					}
				}
				gp.sani[index] = null;
			}
		}else {
			switch(gp.cani[a_type].name) {
			case "pig":
				Random random = new Random();
				if(random.nextInt(60) == 0) {
					Random random2 = new Random();
					if(direction > 2) {
						direction -= 1;
					}else {
						if(direction < 1) {
							direction += 1;
						}else {
							if(random2.nextInt(2) == 0) {
								direction -= 1;
							}else {
								direction += 1;
							}
						}
					}
				}
				counter += 1;
				if(counter > 1000) {
					gp.sani[index] = null;
				}
				int speed = 3;
				switch(direction) {
				case 0:
					worldY -= speed;
					break;
				case 1:
					worldY += speed;
					break;
				case 2:
					worldX += speed;
					break;
				case 3:
					worldX -= speed;
					break;
				}
				break;
			}
		}
	}
}
