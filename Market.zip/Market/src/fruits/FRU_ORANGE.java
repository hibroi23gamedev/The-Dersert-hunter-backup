package fruits;

import java.awt.Color;

import render.DPolygon;
import render.Screen;

public class FRU_ORANGE extends Fruit{

	public FRU_ORANGE(int shelfid, double x, double y, double z, Color c, Color top, boolean conv, int timelasted, boolean remove, short aftertime) {
		super(shelfid, conv, remove, aftertime);
		this.shelfid = shelfid;
		this.type = 1;
		this.timelasted = (short) timelasted;
		
		this.x = x;
		this.y = y;
		this.z = z;
		
		price = 0.75;
		
		width = 4;
		height = 4;
		length = 4;
		model[0] = new DPolygon(new double[]{x, x+width, x+width, x}, new double[]{y, y, y+length, y+length},  new double[]{z, z, z, z}, c, false);
		Screen.DPolygons.add(model[0]);
		model[1] = new DPolygon(new double[]{x, x+width, x+width, x}, new double[]{y, y, y+length, y+length},  new double[]{z+height, z+height, z+height, z+height}, c, false);
		Screen.DPolygons.add(model[1]);
		model[2] = new DPolygon(new double[]{x, x, x+width, x+width}, new double[]{y, y, y, y},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(model[2]);
		model[3] = new DPolygon(new double[]{x+width, x+width, x+width, x+width}, new double[]{y, y, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(model[3]);
		model[4] = new DPolygon(new double[]{x, x, x+width, x+width}, new double[]{y+length, y+length, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(model[4]);
		model[5] = new DPolygon(new double[]{x, x, x, x}, new double[]{y, y, y+length, y+length},  new double[]{z, z+height, z+height, z}, c, false);
		Screen.DPolygons.add(model[5]);
		width = 2;
		height = 1;
		length = 2;
		z+=3;
		y+=2;
		x+=2;
		model[6] = new DPolygon(new double[]{x, x+width, x+width, x}, new double[]{y, y, y+length, y+length},  new double[]{z, z, z, z}, top, false);
		Screen.DPolygons.add(model[6]);
		model[7] = new DPolygon(new double[]{x, x+width, x+width, x}, new double[]{y, y, y+length, y+length},  new double[]{z+height, z+height, z+height, z+height}, top, false);
		Screen.DPolygons.add(model[7]);
		model[8] = new DPolygon(new double[]{x, x, x+width, x+width}, new double[]{y, y, y, y},  new double[]{z, z+height, z+height, z}, top, false);
		Screen.DPolygons.add(model[8]);
		model[9] = new DPolygon(new double[]{x+width, x+width, x+width, x+width}, new double[]{y, y, y+length, y+length},  new double[]{z, z+height, z+height, z}, top, false);
		Screen.DPolygons.add(model[9]);
		model[10] = new DPolygon(new double[]{x, x, x+width, x+width}, new double[]{y+length, y+length, y+length, y+length},  new double[]{z, z+height, z+height, z}, top, false);
		Screen.DPolygons.add(model[10]);
		model[11] = new DPolygon(new double[]{x, x, x, x}, new double[]{y, y, y+length, y+length},  new double[]{z, z+height, z+height, z}, top, false);
		Screen.DPolygons.add(model[11]);
		z-=3;
		y-=2;
		x-=2;
	}
	void setRotAdd()
	{
		angle = new double[4];
		
		double xdif = - width/2 + 0.00001;
		double ydif = - length/2 + 0.00001;
		
		angle[0] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[0] += Math.PI;
		
/////////
		xdif = width/2 + 0.00001;
		ydif = - length/2 + 0.00001;
		
		angle[1] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[1] += Math.PI;
/////////
		xdif = width/2 + 0.00001;
		ydif = length/2 + 0.00001;
		
		angle[2] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[2] += Math.PI;
		
/////////
		xdif = - width/2 + 0.00001;
		ydif = length/2 + 0.00001;
		
		angle[3] = Math.atan(ydif/xdif);
		
		if(xdif<0)
			angle[3] += Math.PI;	
		
		RotAdd[0] = angle[0] + 0.25 * Math.PI;
		RotAdd[1] =	angle[1] + 0.25 * Math.PI;
		RotAdd[2] = angle[2] + 0.25 * Math.PI;
		RotAdd[3] = angle[3] + 0.25 * Math.PI;

	}
	
	void UpdateDirection(double toX, double toY)
	{
		double xdif = toX - (x + width/2) + 0.00001;
		double ydif = toY - (y + length/2) + 0.00001;
		
		double anglet = Math.atan(ydif/xdif) + 0.75 * Math.PI;

		if(xdif<0)
			anglet += Math.PI;

		rotation = anglet;
		updatePoly();		
	}

	public void updatePoly()
	{
		for(int i = 0; i < 6; i++)
		{
			Screen.DPolygons.add(model[i]);
			Screen.DPolygons.remove(model[i]);
		}
		
		double radius = Math.sqrt(width*width + length*length);
		
			   x1 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[0]);
			   x2 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[1]);
			   x3 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[2]);
			   x4 = x+width*0.5+radius*0.5*Math.cos(rotation + RotAdd[3]);
			   
			   y1 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[0]);
			   y2 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[1]);
			   y3 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[2]);
			   y4 = y+length*0.5+radius*0.5*Math.sin(rotation + RotAdd[3]);
   
		model[0].x = new double[]{x1, x2, x3, x4};
		model[0].y = new double[]{y1, y2, y3, y4};
		model[0].z = new double[]{z, z, z, z};

		model[1].x = new double[]{x4, x3, x2, x1};
		model[1].y = new double[]{y4, y3, y2, y1};
		model[1].z = new double[]{z+height, z+height, z+height, z+height};
			   
		model[2].x = new double[]{x1, x1, x2, x2};
		model[2].y = new double[]{y1, y1, y2, y2};
		model[2].z = new double[]{z, z+height, z+height, z};

		model[3].x = new double[]{x2, x2, x3, x3};
		model[3].y = new double[]{y2, y2, y3, y3};
		model[3].z = new double[]{z, z+height, z+height, z};

		model[4].x = new double[]{x3, x3, x4, x4};
		model[4].y = new double[]{y3, y3, y4, y4};
		model[4].z = new double[]{z, z+height, z+height, z};

		model[5].x = new double[]{x4, x4, x1, x1};
		model[5].y = new double[]{y4, y4, y1, y1};
		model[5].z = new double[]{z, z+height, z+height, z};
		
	}
}
