package entitys;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.*;

import engineTester.MainGameLoop;

public class Camera {
   private float distanceFromPlayer = 80F;
//private float distanceFromPlayer = 30F;
   private float angleAroundPlayer = 0.0F;
   private Vector3f position = new Vector3f(0.0F, 10.0F, 0.0F);
   public float pitch = 0.0F;
   public float yaw = 0.0F;
   public float roll = 0;
   
   private Vector2f oldm = new Vector2f();

   public Camera() {
	   oldm = MainGameLoop.mousePosition();
   }
   
   public void move() {
	   if(Keyboard.isKeyDown(Keyboard.KEY_W)) {
		   position.z += ((Math.cos(Math.toRadians(180-yaw))*1));
		   position.x += ((Math.sin(Math.toRadians(180-yaw))*1));
	   }
	   if(Keyboard.isKeyDown(Keyboard.KEY_S)) {
		   position.z += 0-((Math.cos(Math.toRadians(180-yaw))*1));
		   position.x += 0-((Math.sin(Math.toRadians(180-yaw))*1));
	   }
	   if(Mouse.isButtonDown(1)) {
		   yaw += (oldm.x - MainGameLoop.mousePosition().x)*72;
		   pitch += (oldm.y - MainGameLoop.mousePosition().y)*42;
	   }
	   oldm = MainGameLoop.mousePosition();
   }

   public Vector3f getPosition() {
      return this.position;
   }

   public void setPosition(float x, float y, float z) {
      this.position.x = x;
      this.position.y = y;
      this.position.z = z;
   }
   public float getPitch() {
      return this.pitch;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getRoll() {
      return this.roll;
   }
}
