package render;

import java.awt.Color;
import java.util.Random;

public class GenerateTerrain {

    Random r;
    static double roughness = 0;
    static int mapSize = 64;
	static double Size = 64;
	int biome = 0;
	Color G = new Color(0, 170, 0);
//	static Color G = new Color(120, 100, 80);

    public GenerateTerrain() {
    		
    		
    		
	    	r = new Random();
	    	double[] values1 = new double[mapSize];	        
	        double[] values2 = new double[values1.length];	    	
	        double[] rough = new double[values2.length];
	        int[] biomes = new int[mapSize*mapSize];
	        GenBiome[] biomeg = new GenBiome[biomes.length];
	        int biomegi = 0;
	        
	        int bx = 0;
	        int by = 0;
	        for(int i = 0; i < biomes.length; i++) {
	        	bx += 1;
	        	if(bx >= mapSize) {
	        		bx = 0;
	        		by += 1;
	        	}
	        	Random random = new Random();
	        	Random random2 = new Random();
	        	if(random.nextInt(100) == 0) {
	        		int type = random2.nextInt(3);
	        		biomes[i] = type;
	        		biomeg[biomegi] = new GenBiome();
	        		biomeg[biomegi].type = type;
	        		biomeg[biomegi].x = bx;
	        		biomeg[biomegi].y = by;
	        	}
	        }
	        int bgx = 0;
	        int bgy = 0;
	        for(int i = 0; i < biomes.length; i++) {
	        	bgx += 1;
	        	if(bgx > mapSize) {
	        		bgx = 0;
	        		bgy += 1;
	        	}
	        	int bdx = 0;
	        	int bdy = 0;
	        	for(int i1 = 0; i1 < biomeg.length; i1++) {
	        		if(biomeg[i1] != null) {
	        			bdx += 1;
		        		if(bdx >= mapSize) {
		        			bdx = 0;
		        			bdy += 1;
		        		}
		        		double px = (int) (Math.pow(bgx - bdx, 2));
		        		double py = (int) (Math.pow(bgy - bdy, 2));
		        		double distance = Math.sqrt(px+py);
		        		System.out.println(distance);
		        		if(biomeg[i1].type != 0) {
		        			if(distance < 70) {
		        				biomes[i] = biomeg[i1].type;
		        			}
		        		}
	        		}
	        	}
	        }
	
	        for (int y = 0; y < values1.length/2; y+=2) {
	        	
	            for(int i = 0; i < values1.length; i++)
	        	{ 
	            	
	            	values1[i] = values2[i];
	                values2[i] = r.nextDouble()*roughness;            
	                rough[i] = roughness;
	            }            
	            
	            if(y != 0)
	            {
		            for (int x = 0; x < values1.length/2; x++) {	
		            	if(rough[x] <= 30) {
		            		Random random = new Random();
		            		if(random.nextInt(6) == 0) {
		            			
		            		}
		            	}
						Screen.DPolygons.add(new DPolygon(new double[]{(Size * x), (Size * x), Size + (Size * x)}, new double[]{(Size * y), Size + (Size * y), Size + (Size * y)}, new double[]{values1[x], values2[x], values2[x+1]}, G, false));	            	
						Screen.DPolygons.add(new DPolygon(new double[]{(Size * x), Size + (Size * x), Size + (Size * x)}, new double[]{(Size * y), Size + (Size * y), (Size * y)}, new double[]{values1[x], values2[x+1], values1[x+1]}, G, false));
		            }
	            }
	
	        	for(int i = 0; i < values1.length; i++)
	        	{
	   
	            	
	            	values1[i] = values2[i];
	                values2[i] = r.nextDouble()*roughness;
	            }
	
	            if(y != 0)
	            {
		            for (int x = 0; x < values1.length/2; x++) {
		            	
						Screen.DPolygons.add(new DPolygon(new double[]{(Size * x), (Size * x), Size + (Size * x)}, new double[]{(Size * (y+1)), Size + (Size * (y+1)), Size + (Size * (y+1))}, new double[]{values1[x], values2[x],  values2[x+1]}, G, false));
		            	Screen.DPolygons.add(new DPolygon(new double[]{(Size * x), Size + (Size * x), Size + (Size * x)}, new double[]{(Size * (y+1)), Size + (Size * (y+1)), (Size * (y+1))}, new double[]{values1[x], values2[x+1],  values1[x+1]}, G, false));
		            }            
	            }
	        }   
    }
}

