package draw;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class Chain {
	public int size;
	public int length;
	public int x;
	public int y;
	public Image[] chains;
	public int direction = 90;
	
	public Chain(int size, int length, int x, int y) {
		this.size = size;
		this.length = length;
		this.x = x;
		this.y = y;
		
		BufferedImage chainImage = null;
		
		try {
			chainImage = ImageIO.read(getClass().getResourceAsStream("/chains/chain.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		chains = new Image[length];
		for(int i = 0; i < length; i++) {
			chains[i] = new Image();
			chains[i].width = size;
			chains[i].height = size;
			chains[i].x = x;
			chains[i].y = y+(i*size);
			chains[i].c = chainImage;
			chains[i].init();
			chains[i].direction = 90;
		}
	}
	
	public void update() {
		if(direction > 360) {
			direction = 0;
		}
		for(int i = 0; i < length; i++) {
			//chains[i].x = (int) (x + (Math.sin(Math.toRadians(direction)) * (i*size)));
			//chains[i].y = (int) ((y)+(Math.cos(Math.toRadians(direction)+(i*size))));
			//chains[i].direction = direction;
		}
	}
	
	public void draw(Graphics g) {
		//chains[0].direction = direction;
		for(int i = 0; i < length; i++) {
			chains[i].draw(g, GamePanel.light);
		}
	}
}
