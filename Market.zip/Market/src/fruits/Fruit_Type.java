package fruits;

import java.awt.Color;

import render.Screen;

public class Fruit_Type extends Fruit {
	public Fruit_Type(double x, double y, double z, int shelfid, Color c, Color top, int type, boolean conv, int timelasted, boolean remove, short aftertime) {
		super(shelfid, conv, remove, aftertime);
		switch(type) {
		case 0:
			Screen.fruits.add(new FRU_APPLE(shelfid,x,y,z,Color.RED,Color.BLACK, conv, timelasted, remove, aftertime));
			break;
		case 1:
			Screen.fruits.add(new FRU_ORANGE(shelfid,x,y,z,Color.ORANGE,Color.GREEN, conv, timelasted, remove, aftertime));
			break;
		case 2:
			Screen.fruits.add(new FRU_BANANA(shelfid,x,y,z,Color.YELLOW,Color.YELLOW, conv, timelasted, remove, aftertime));
			break;
		case 3:
			Screen.fruits.add(new FRU_CUMBA(shelfid,x,y,z,Color.GREEN,Color.GREEN, conv, timelasted, remove, aftertime));
			break;
		case 4:
			Screen.fruits.add(new FRU_TOMATO(shelfid,x,y,z,Color.RED,Color.GREEN, conv, timelasted, remove, aftertime));
			break;
		case 8000:
			Screen.fruits.add(new FRU_CVEY_HELP(shelfid,x,y,z,Color.WHITE,null, conv, timelasted, remove, aftertime ));
			break;
		}
	}
}