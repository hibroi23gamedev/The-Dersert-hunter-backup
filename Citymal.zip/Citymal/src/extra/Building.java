package extra;

import buildings.Building_Type;

public class Building {
	public Building_Type type;
	public int x;
	public int y;
	
	public boolean owned = false;
	
	public Building(Building_Type type, int x, int y) {
		this.type = type;
		this.x = x;
		this.y = y;
	}
}
