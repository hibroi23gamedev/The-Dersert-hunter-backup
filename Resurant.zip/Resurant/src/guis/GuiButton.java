package guis;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;

import engineTester.MainGameLoop;
import fontMeshCreator.FontType;
import fontMeshCreator.GUIText;

public class GuiButton extends GuiTexture{
	
	public int def;
	public int sel;
	
	public GUIText drop_down;

	public GuiButton(int texture, Vector2f postiion, Vector2f scale, int sel, String drop_down_string, FontType font) {
		super(texture, postiion, scale);
		this.sel = sel;
		this.def = texture;
		drop_down = new GUIText(drop_down_string, 1.4f, font, new Vector2f(-2, -2), 0.2f, false);
		drop_down.setColour(0.12f, 0.1f, 0.05f);
	}
	
	public boolean mouseclickedonbutton(boolean c) {
		float mx = (2f*Mouse.getX()) / Display.getWidth() - 1f;
		float my = (2f*Mouse.getY()) / Display.getHeight() - 1f;
		Vector2f position = super.getPostiion();
		Vector2f scale = super.getScale();
		if(mx > position.x-(scale.x/1) && my > position.y-(scale.y/2) && mx < scale.x*1.1 && my < scale.y*2) {
			if(c) {
				texture = sel;
			}
			if(Mouse.isButtonDown(0)) {
				if(c) {
					texture = def;
				}
				return true;
			}
		}else {
			if(c) {
				texture = def;
			}
		}
		return false;
	}
	public void manage_Drop_down_menu() {
		//System.out.println("X: " + MainGameLoop.mousePosition().x + "| THIS.X: "+ this.getPostiion().x);
		//System.out.println("Y: " + MainGameLoop.mousePosition().y + "| THIS.Y: "+ this.getPostiion().y);
		if(this.mousehoveredonbutton(false)) {
			drop_down.getPosition().x = (MainGameLoop.mousePosition().x/2) + 0.32f;
        	drop_down.getPosition().y = 1.0f - ((MainGameLoop.mousePosition().y/2) + 0.6f);
         }else {
        	drop_down.getPosition().x = -2;
        	drop_down.getPosition().y = -2;
         }
	}
	public boolean mousehoveredonbutton(boolean c) {
		float mx = (MainGameLoop.mousePosition().x/2);
		float my = 1.0f - ((MainGameLoop.mousePosition().y/2));
		Vector2f position = super.getPostiion();
		Vector2f scale = super.getScale();
		float px = position.x-(scale.x/2);
		float py = position.y-(scale.y/2);
		float sx = (float) (scale.x*1.1);
		float sy = scale.y*2;
		if(mx > px && my > py && mx < px + sx && 
				my < py + sy) {
			if(c) {
				texture = sel;
			}
			return true;
		}else {
			if(c) {
				texture = def;
			}
		}
		return false;
	}
}
