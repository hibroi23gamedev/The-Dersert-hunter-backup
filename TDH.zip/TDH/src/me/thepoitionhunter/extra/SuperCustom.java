package me.thepoitionhunter.extra;

import java.awt.Graphics2D;

import me.thepoitionhunter.main.GamePanel;

public class SuperCustom {
	public int x;
	public int y;
	public int width;
	public int height;
	public int type_index;
	
	public int frame;
	
	public int counter;
	public int target;
	public byte filled = 0;
	public int oldtarget;
	public byte ontarget = 0;
	public int water_fill;
	
	public void draw(Graphics2D g2, GamePanel gp) {
		int screenX = x - gp.Player.worldX + gp.Player.ScreenX;
		int screenY = y - gp.Player.worldY + gp.Player.ScreenY;
		if(gp.cobj[type_index].ani) {
			g2.drawImage(gp.cobj[type_index].img[gp.cobj[type_index].frame_on],screenX,screenY,width,height,null);
		}else {
			g2.drawImage(gp.cobj[type_index].img[frame],screenX,screenY,width,height,null);
		}
	}
	
	public void update(int index, GamePanel gp) {
		switch(gp.cobj[type_index].name) {
		case "sand_storm":
			x += Math.sin(gp.winddirection)*5;
			y += Math.cos(gp.winddirection)*5;
			
			width += 1;
			height += 1;
			
			if(gp.Player.worldX > x) {
				if(gp.Player.worldY > y) {
					if(gp.Player.worldX < x+width) {
						if(gp.Player.worldY < y+height) {
							gp.Player.sand_index = index;
						}
					}
				}
			}
			
			counter += 1;
			if(counter > 600) {
				gp.sobj[index] = null;
			}
			break;
		case "water_transport":
			if(gp.Player.worldX > x) {
				if(gp.Player.worldY > y) {
					if(gp.Player.worldX < x+width) {
						if(gp.Player.worldY < y+height) {
							if(gp.keyH.zpressed) {
								ontarget = 1;
							}
						}
					}
				}
			}
			if(ontarget > 0) {
				counter += 1;
				if(counter >= 15) {
					if(ontarget == 1) {
						if(motiontweennext(frame, target+filled) != 0) {
							frame += motiontweennext(frame, target+filled);
						}else {
							ontarget = 2;
						}
					}else {
						if(motiontweennext(frame, target+filled) == 0) {
							if(frame < 5) {
								frame += 5;
								filled = 5;
							}
							water_fill += 5;
						}
						if(motiontweennext(frame, oldtarget+filled) != 0) {
							frame += motiontweennext(frame, oldtarget+filled);
						}else {
						}
					}
					counter = 0;
				}
			}
			if(water_fill > 0) {
				if(gp.keyH.zpressed) {
					if(gp.Player.Inventory[gp.Player.insel] == 3) {
						gp.Player.Inventory[gp.Player.insel] = 4;
						water_fill -= 1;
					}
				}
			}
			break;
		}
	}
	public int motiontweennext(int or, int target) {
		if(or > target) {
			return -1;
		}else if(or < target) {
			return 1;
		}else {
			return 0;
		}
	}
}
