package particles;

public class ParticleTexture {
   private int textureID;
   private int numberofRows;

   public ParticleTexture(int textureID, int numberofRows) {
      this.textureID = textureID;
      this.numberofRows = numberofRows;
   }

   protected int getTextureID() {
      return this.textureID;
   }

   protected int getNumberofRows() {
      return this.numberofRows;
   }
}
