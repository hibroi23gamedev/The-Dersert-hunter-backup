package entitys;

import org.lwjgl.util.vector.Vector3f;

import audio.Source;
import models.TexturedModel;
import terrains.Terrain;

import java.util.Random;

public abstract class Animal extends Entity{
	
	public int type;
	public int dir;
	Random random = new Random();
	public Source source;

	public Animal(TexturedModel model, Vector3f position, float rotX, float rotY, float rotZ, float scale, Source source) {
		super(model, position, rotX, rotY, rotZ, scale);
		this.source = source;
	}
	
	public abstract void update(Terrain terrain);
	
	public void move(Terrain terrain) {
		if(random.nextInt(20) == 0) {
			int rand = random.nextInt(4);
			dir = rand;
		}
		float speed = 0.05f;
		
		if(dir == 0) {
			position.x += speed;
			rotY = 270;
		}
		if(dir == 1) {
			position.x -= speed;
			rotY = 90;
		}
		if(dir == 2) {
			position.z += speed;
			rotY = 180;
		}
		if(dir == 3) {
			position.z -= speed;
			rotY = 0;
		}
		position.y = terrain.getHeightOfTerrain(position.x, position.z);
	}
}
