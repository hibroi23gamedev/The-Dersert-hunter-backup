package main;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Graphics;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import tiles.Tile;
import tiles.TileManager;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;
import java.util.ArrayList;
import mineshafts.*;

import entities.*;

import draw.*;
import items.*;

public class GamePanel extends JPanel implements MouseListener{
	private static final long serialVersionUID = 1L;
	public static int camX = 0;
	public static int camY = 0;
	public static int camZ = 0;
	public static JFrame frame;
	public static final int FPS = 60;
	
	public boolean mouseClicked = false;
	
	public int playerX = 240;
	public int playerY = 340;
	
	public static Light light = new Light();
	
	public static KeyHandler keys = new KeyHandler();
	
	ArrayList<Mineshaft> mineshafts = new ArrayList<Mineshaft>();
	
	Image test = new Image(null, 0, 0, 100, 100);
	
	public Player player;
	
	public static int player_speed = 32;
	
	public static BufferedImage[] images = new BufferedImage[3];
	
	public ArrayList<Item> items = new ArrayList<Item>();
	
	public GamePanel(JFrame frame) {
		this.light.range = 3;
		this.frame = frame;
		this.addKeyListener(keys);
		this.setFocusable(true);
		this.setBackground(Color.black);
		this.addMouseListener(this);
		
		playerX = frame.getWidth()/2;
		playerY = frame.getHeight()/2;
		player = new Player(playerX, playerY, 80);
		try {
			images[0] = ImageIO.read(getClass().getResourceAsStream("/tiles/stone.png"));
			images[1] = ImageIO.read(getClass().getResourceAsStream("/tiles/stone2.png"));
			images[2] = ImageIO.read(getClass().getResourceAsStream("/mineshaft/mineshaft.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		test.c = images[2];
		test.direction = 90;
		test.init();
		
		Image TILE0IMG = new Image(images[0], 0, 0, TileManager.tileSize, TileManager.tileSize);
		TILE0IMG.init();
		images[0] = TILE0IMG.c;
		Image TILE1IMG = new Image(images[1], 0, 0, TileManager.tileSize, TileManager.tileSize);
		TILE1IMG.init();
		images[1] = TILE1IMG.c;
		
		Random random = new Random();
		int y = 0;
		for(int i = 0; i < 128; i++) {
			int x = random.nextInt(TileManager.length*TileManager.tileSize);
			int z = 100-(y/40);
			y += random.nextInt(TileManager.length*TileManager.tileSize)/180;
			if(z > 60) {
				z = 60;
			}
			if(z < 0) {
				z = 0;
			}
			for(int i1 = 0; i1 < 40; i1++) {
				if(random.nextInt(4) > 0) {
					createRandomMineshaft(x + i1*200, y, z);
				}
			}
		}
		
		for(int i = 0; i < 800; i++) {
			boolean found_right_place = false;
			int best_x = 0;
			int best_y = 0;
			int steps = 0;
			while(!found_right_place && steps < 60) {
				int x = random.nextInt(TileManager.length*TileManager.tileSize);
				int by = random.nextInt(TileManager.length*TileManager.tileSize);
				boolean is_right_pos = false;
				for(int i1 = 0; i1 < mineshafts.size(); i1++) {
					if(mineshafts.get(i1).x-mineshafts.get(i1).img.width < x && mineshafts.get(i1).y-mineshafts.get(i1).img.height < by 
							&& mineshafts.get(i1).x+mineshafts.get(i1).img.width > x && mineshafts.get(i1).y+mineshafts.get(i1).img.height > by) {
						is_right_pos = true;
					}
				}
				if(is_right_pos) {
					found_right_place = true;
					best_x = x;
					best_y = by;
				}
				steps++;
			}
			items.add(new Battery(best_x, best_y, 70));
			//items.add(new Battery(0, 0, 70));
		}
		
		for(int i = 0; i < TileManager.length; i++) {
			for(int i1 = 0; i1 < TileManager.length; i1++) {
				TileManager.tiles[i][i1] = new Tile();
				int rand = random.nextInt(4);
				if(rand > 1) {
					rand = 0;
				}
				int x = (i*TileManager.tileSize) - camX;
				int y2 = (i1*TileManager.tileSize) - camY;
				TileManager.tiles[i][i1].id = rand;
				TileManager.tiles[i][i1].imageID = random.nextInt(2);
				/*
				TileManager.tiles[i][i1].img = new Image(images[TileManager.tiles[i][i1].imageID], x, y, TileManager.tileSize, TileManager.
						tileSize);
				TileManager.tiles[i][i1].img.init();
				*/
			}
		}
	}
	
	public void startGame() {
		double drawInterval = 1000000000/FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		long timer = 0;
		int drawCount = 0;
		
		while(true) {
			currentTime = System.nanoTime();
			delta += (currentTime - lastTime) / drawInterval;
			timer += (currentTime - lastTime);
			lastTime = currentTime;
			if(delta >= 1) {
				update();
				
				repaint();
				delta--;
				drawCount++;
			}
			
			
			if(timer >= 1000000000) {
				
				drawCount = 0;
			}
		}
	}
	
	public void update() {
		light.x = camX + playerX;
		light.y = camY + playerY;
		light.range-=0.001;
		
		if(light.range < 0) {
			System.exit(0);
		}
		
		int speed = player_speed;
		if(keys.keys[0]) {
			camX -= speed;
		}
		if(keys.keys[1]) {
			camX += speed;
		}
		if(keys.keys[2]) {
			camY -= speed;
		}
		if(keys.keys[3]) {
			camY += speed;
		}
		player.update();
		
		for(int i = 0; i < items.size(); i++) {
			items.get(i).update(this);
		}
	}
	
	public void createRandomMineshaft(int x, int y, int z) {
		Mineshaft mine = new Mineshaft(x, y, z, 0);
		Image mineshaftImg = new Image(images[2], x, y, 100, 4);
		mineshaftImg.length = 70;
		mineshaftImg.floor = true;
		mineshaftImg.init();
		mine.img = mineshaftImg;
		mine.img.direction = 90;
		mineshafts.add(mine);
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		
		
		for(int i = 0; i < TileManager.length; i++) {
			for(int i1 = 0; i1 < TileManager.length; i1++) {
				int x = (i*TileManager.tileSize) - camX;
				int y = (i1*TileManager.tileSize) - camY;
				x /= 3;
				y /= 3;
				if(x > -48 && y > -48 && x < frame.getWidth() && y < frame.getHeight()) {
					if(TileManager.tiles[i][i1].id != 0) {
						//TileManager.tiles[i][i1].img.draw(g, light);
						//int distanceX = x - light.x;
						//int distanceY = y - light.y;
						//int distance = (int) Math.sqrt(Math.pow(distanceX, 2) + Math.pow(distanceY, 2));
						//distance = Math.abs(distance/light.range);
						//if(distance < 240) {
							g.drawImage(images[TileManager.tiles[i][i1].imageID], x, y, TileManager.tileSize, TileManager.tileSize, null);
						//}
					}
				}
			}
		}
		
		for(int i = 0; i < mineshafts.size(); i++) {
			int x = mineshafts.get(i).x - camX;
			int y = mineshafts.get(i).y - camY;
			if(x > 0 && y > 0 && x < frame.getWidth() && y < frame.getHeight()) {
				mineshafts.get(i).img.draw(g, light);
			}
		}
		
		test.draw(g, light);
		
		player.draw(g, light);
		
		for(int i = 0; i < items.size(); i++) {
			int x = items.get(i).x-camX;
			int y = items.get(i).y-camY;
			if(x > 0 && y > 0 && x < frame.getWidth() && y < frame.getHeight()) {
				items.get(i).draw(g, light);
			}
			if(items.get(i).id == -1) {
				items.remove(i);
			}
		}
		//System.out.println(mouseClicked);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		mouseClicked = true;
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		mouseClicked = false;
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}
}