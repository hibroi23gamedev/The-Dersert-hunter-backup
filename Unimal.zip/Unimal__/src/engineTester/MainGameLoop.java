package engineTester;

import audio.AudioMaster;
import audio.Source;
import entitys.Animal;
import entitys.Camera;
import entitys.Entity;
import entitys.Light;
import entitys.Player;
import entitys.Sheep;
import entitys.Tree;
import extra.Crafting_Recipe;
import extra.ItemGroup;
import extra.ItemL;
import extra.Loot;
import extra_entity_types.AntiFact;
import fontMeshCreator.FontType;
import fontMeshCreator.GUIText;
import fontRendering.TextMaster;
import guis.GuiButton;
import guis.GuiRenderer;
import guis.GuiTexture;
import items.Item;
import items.ItemPro;
import items.SuperItem;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import models.RawModel;
import models.TexturedModel;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.openal.AL10;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import particles.ParticleMaster;
import postProcessing.Fbo;
import postProcessing.PostProcessing;
import render.DisplayManager;
import render.Loader;
import render.MasterRenderer;
import render.ModelData;
import render.OBJFileLoader;
import terrains.Terrain;
import textures.ModelTexture;
import textures.TerrainTexture;
import textures.TerrainTexturePack;
import toolbox.MouseRay;
import water.WaterFrameBuffers;
import water.WaterRenderer;
import water.WaterShader;
import water.WaterTile;

import extra_entity_types.*;

public class MainGameLoop {
   static int inventorysel = 0;
   public static ArrayList<Entity> entities = new ArrayList();
   public static ArrayList<Tree> rigged_entities = new ArrayList();
   public static Light light = new Light(new Vector3f(1000000.0F, 1500000.0F, -1000000.0F), new Vector3f(1.0F, 1.0F, 1.0F));
   public static boolean blood_moon = false;
   public static ArrayList<Entity> pickup = new ArrayList();
   public static ArrayList<Integer> pickup_inv = new ArrayList();
   public static ArrayList<Boolean> pickup_phy = new ArrayList();
   public static ArrayList<Entity> shops = new ArrayList();
   public static ArrayList<Loot> shop_loot = new ArrayList();
   static boolean shadows = true;
   public static List<GuiTexture> guis = new ArrayList();
   public static SuperItem itemmanager = new SuperItem();
   public static int dig_count = 0;
   public static int sel;
   public static int[] inventory = new int[5];
   public static int[] inventorycount = new int[5];
   public static int placement_index = 0;
   public static int antifact_index = -1;
   
   public static Car which_driving_car = null;

   public static void main(String[] args) {
      boolean usingitem = false;
      boolean placing = false;
      int placing_index = 0;
      int usingitemtime = 0;
      short craftcount = 0;
      AudioMaster.init();
      AudioMaster.setListenerData(0.0F, 0.0F, 0.0F);
      AL10.alDistanceModel(53252);
      int buffer = AudioMaster.loadSound("audio/bounce.wav");
      Source source = new Source();
      source.setLooping(true);
      source.play(buffer);
      source.setPosition(0.0F, 0.0F, 0.0F);
      ArrayList<Integer> crafted = new ArrayList();
      ArrayList<Integer> crafted_type = new ArrayList();
      ArrayList<Crafting_Recipe> crafting = new ArrayList();
      DisplayManager.createDisplay();
      ArrayList<Entity> floor = new ArrayList();
      ArrayList<Tree> trees = new ArrayList();
      ArrayList<Animal> animals = new ArrayList();
      ArrayList<AntiFact> antifacts = new ArrayList();
      new ArrayList();
      List<Light> lights = new ArrayList();
      ArrayList<TexturedModel> placement_models = new ArrayList();
      ArrayList<String> placement_popup = new ArrayList();
      ArrayList<Integer> placement_textures = new ArrayList();
      ArrayList<Integer> placement_textures_sel = new ArrayList();
      ArrayList<GuiButton> placement_buttons = new ArrayList();
      ArrayList<ArrayList<Integer>> placement_re = new ArrayList();
      ArrayList<Integer> placement_amount = new ArrayList();
      ArrayList<Entity> placedObject = new ArrayList();
      Loader loader = new Loader();
      TextMaster.init(loader);
      ModelData data8 = OBJFileLoader.loadOBJ("sink");
      RawModel model8 = loader.loadtoVAO(data8.getVertices(), data8.getTextureCoords(), data8.getNormals(), data8.getIndices(), data8);
      ModelTexture texture8 = new ModelTexture(loader.loadTexture("sink"));
      TexturedModel sink_model = new TexturedModel(model8, texture8);
      ModelData tdata = OBJFileLoader.loadOBJ("toilet2");
      RawModel tmodel = loader.loadtoVAO(tdata.getVertices(), tdata.getTextureCoords(), tdata.getNormals(), tdata.getIndices(), tdata);
      ModelTexture ttexture = new ModelTexture(loader.loadTexture("sink"));
      TexturedModel ttmodel = new TexturedModel(tmodel, ttexture);
      ModelTexture sink_t = new ModelTexture(loader.loadTexture("sink_inv"));
      ModelTexture sink_tsel = new ModelTexture(loader.loadTexture("sink_inv_sel"));
      placement_models.add(sink_model);
      placement_popup.add("Sink - Gives you 3x for water and fliters it!");
      placement_textures.add(sink_t.getTextureID());
      placement_textures_sel.add(sink_tsel.getTextureID());
      placement_re.add(new ArrayList());
      ((ArrayList)placement_re.get(0)).add(0);
      ((ArrayList)placement_re.get(0)).add(1);
      placement_amount.add(0);
      placement_models.add(ttmodel);
      placement_popup.add("Toilet - You know...");
      placement_textures.add(sink_t.getTextureID());
      placement_textures_sel.add(sink_tsel.getTextureID());
      placement_re.add(new ArrayList());
      ((ArrayList)placement_re.get(1)).add(3);
      ((ArrayList)placement_re.get(1)).add(1);
      ((ArrayList)placement_re.get(1)).add(2);
      placement_amount.add(0);
      sel = loader.loadTexture("sel");
      ModelData data = OBJFileLoader.loadOBJ("grass06");
      RawModel model = loader.loadtoVAO(data.getVertices(), data.getTextureCoords(), data.getNormals(), data.getIndices(), data);
      ModelTexture texture = new ModelTexture(loader.loadTexture("grassTexture"));
      TerrainTexture backtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backrtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backgtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexture backbtexture = new TerrainTexture(loader.loadTexture("grass"));
      TerrainTexturePack texturepack = new TerrainTexturePack(backtexture, backrtexture, backgtexture, backbtexture);
      TerrainTexture blendMap = new TerrainTexture(loader.loadTexture("blend_map"));
      texture.setHasTransparency(true);
      texture.setShineDamper(10.0F);
      texture.setRfi(0.0F);
      texture.setUseFakeLighting(true);
      GuiTexture gui3 = new GuiTexture(loader.loadTexture("health_bar"), new Vector2f(-0.7F, -0.75F), new Vector2f(0.15F, 0.03F));
      GuiTexture gui2 = new GuiTexture(loader.loadTexture("health_outline"), new Vector2f(-0.66F, -0.75F), new Vector2f(0.19F, 0.03F));
      GuiTexture gui = new GuiTexture(loader.loadTexture("heart"), new Vector2f(-0.85F, -0.75F), new Vector2f(0.07F, 0.13F));
      int sinecounter = 0;
      int inv = loader.loadTexture("inventory");
      int invs = loader.loadTexture("inventory_sel");
      int trans = loader.loadTexture("transparent");
      GuiTexture inv0 = new GuiTexture(inv, new Vector2f(-0.35F, -0.75F), new Vector2f(0.07F, 0.13F));
      GuiTexture invi4 = new GuiTexture(trans, new Vector2f(0.21F, -0.75F), new Vector2f(0.06F, 0.11F));
      GuiTexture invi3 = new GuiTexture(trans, new Vector2f(0.07F, -0.75F), new Vector2f(0.06F, 0.11F));
      GuiTexture invi2 = new GuiTexture(trans, new Vector2f(-0.07F, -0.75F), new Vector2f(0.06F, 0.11F));
      GuiTexture invi1 = new GuiTexture(trans, new Vector2f(-0.21F, -0.75F), new Vector2f(0.06F, 0.11F));
      GuiTexture invi0 = new GuiTexture(trans, new Vector2f(-0.35F, -0.75F), new Vector2f(0.06F, 0.11F));
      GuiTexture inv4 = new GuiTexture(inv, new Vector2f(0.21F, -0.75F), new Vector2f(0.07F, 0.13F));
      GuiTexture inv3 = new GuiTexture(inv, new Vector2f(0.07F, -0.75F), new Vector2f(0.07F, 0.13F));
      GuiTexture inv2 = new GuiTexture(inv, new Vector2f(-0.07F, -0.75F), new Vector2f(0.07F, 0.13F));
      GuiTexture inv1 = new GuiTexture(inv, new Vector2f(-0.21F, -0.75F), new Vector2f(0.07F, 0.13F));
      FontType font = new FontType(loader.loadTexture("segoe"), new File("res/segoe.fnt"));
      new GUIText("HELLO", 1.0F, font, new Vector2f(0.2F, 0.2F), 0.2F, true);
      ModelData data2 = OBJFileLoader.loadOBJ("fern");
      RawModel model2 = loader.loadtoVAO(data2.getVertices(), data2.getTextureCoords(), data2.getNormals(), data2.getIndices(), data2);
      ModelTexture texture2 = new ModelTexture(loader.loadTexture("fern"));
      texture.setHasTransparency(true);
      texture.setShineDamper(10.0F);
      texture.setRfi(0.0F);
      texture.setUseFakeLighting(true);
      Crafting_Recipe med_kit_craft = new Crafting_Recipe();
      med_kit_craft.recipe = new int[2];
      med_kit_craft.recipe[0] = 2;
      med_kit_craft.recipe[1] = 3;
      med_kit_craft.crafted = 1;
      crafting.add(med_kit_craft);
      GuiRenderer guiRenderer = new GuiRenderer(loader);
      TexturedModel texturedModel = new TexturedModel(model, texture);
      TexturedModel texturedfern = new TexturedModel(model2, texture2);
      Entity entity = new Entity(texturedModel, new Vector3f(80.0F, 0.0F, 50.0F), 0.0F, 180.0F, 0.5F, 1.0F);
      Entity entity2 = new Entity(texturedfern, new Vector3f(80.0F, 0.0F, 50.0F), 0.0F, 180.0F, 0.5F, 0.2F);
      lights.add(light);
      Terrain terrain = new Terrain(0, 0, loader, texturepack, blendMap, "heightmap");
      ModelData playerm = OBJFileLoader.loadOBJ("person");
      RawModel playermm = loader.loadtoVAO(playerm.getVertices(), playerm.getTextureCoords(), playerm.getNormals(), playerm.getIndices(), playerm);
      TexturedModel playert = new TexturedModel(playermm, new ModelTexture(loader.loadTexture("person")));
      Player player = new Player(playert, new Vector3f(140.0F, terrain.getHeightOfTerrain(140.0F, 140.0F) + 4.0F, 140.0F), 0.0F, 0.0F, 0.0F, 0.3F);
      player.phy = false;
      Camera camera = new Camera(player);
      MasterRenderer renderer = new MasterRenderer(texture2, loader, camera);
      Player phy_player = new Player((TexturedModel)null, new Vector3f(9999.0F, 9999.0F, 9999.0F), 0.0F, 0.0F, 0.0F, 0.0F);
      ModelData data3 = OBJFileLoader.loadOBJ("med_kit_model");
      RawModel model3 = loader.loadtoVAO(data3.getVertices(), data3.getTextureCoords(), data3.getNormals(), data3.getIndices(), data3);
      ModelTexture texture3 = new ModelTexture(loader.loadTexture("med_kit_model"));
      TexturedModel med_kit_model = new TexturedModel(model3, texture3);
      ModelData data9 = OBJFileLoader.loadOBJ("string");
      RawModel model9 = loader.loadtoVAO(data9.getVertices(), data9.getTextureCoords(), data9.getNormals(), data9.getIndices(), data9);
      ModelTexture texture9 = new ModelTexture(loader.loadTexture("med_kit_model"));
      TexturedModel stringmodel = new TexturedModel(model9, texture9);
      new Entity(stringmodel, new Vector3f(140.0F, 30.0F, 140.0F), 0.0F, 0.0F, 0.0F, 5.0F);
      new Entity(med_kit_model, new Vector3f(80.0F, 0.0F, 70.0F), 0.0F, 0.0F, 0.0F, 1.0F);
      ModelData data6 = OBJFileLoader.loadOBJ("cube");
      RawModel model6 = loader.loadtoVAO(data6.getVertices(), data6.getTextureCoords(), data6.getNormals(), data6.getIndices(), data6);
      ModelTexture texture6 = new ModelTexture(loader.loadTexture("f_to_grab"));
      TexturedModel f_to_grab_model = new TexturedModel(model6, texture6);
      Entity f_to_grab = new Entity(f_to_grab_model, new Vector3f(80.0F, -2.0F, 70.0F), 0.0F, 0.0F, 0.0F, 0.1F);
      camera.setPosition(80.0F, 2.5F, 80.0F);
      Random random = new Random();

      for(int i = 0; i < random.nextInt(340) + 1500; ++i) {
         Random random2 = new Random();
         Random random3 = new Random();
         Random random4 = new Random();
         int x = random2.nextInt(200) + 10;
         int z = random3.nextInt(200) + 10;
         if (random4.nextInt(4) == 0) {
            floor.add(new Entity(texturedfern, new Vector3f((float)x, terrain.getHeightOfTerrain((float)x, (float)z), (float)z), 0.0F, 180.0F, 0.5F, 0.3F));
         } else {
            floor.add(new Entity(texturedModel, new Vector3f((float)x, terrain.getHeightOfTerrain((float)x, (float)z) + 0.7F, (float)z), 180.0F, 180.0F, 0.0F, 0.9F));
         }
      }

      WaterShader waterS = new WaterShader();
      WaterRenderer waterR = new WaterRenderer(loader, waterS, renderer.getProjectionMatrix());
      List<WaterTile> waters = new ArrayList();
      waters.add(new WaterTile(player.getPosition().x, player.getPosition().y - 2.0F, player.getPosition().z));
      WaterFrameBuffers fbos = new WaterFrameBuffers();
      ModelData shopdata = OBJFileLoader.loadOBJ("shop");
      RawModel shopmodel = loader.loadtoVAO(shopdata.getVertices(), shopdata.getTextureCoords(), shopdata.getNormals(), shopdata.getIndices(), shopdata);
      ModelTexture shoptexture = new ModelTexture(loader.loadTexture("stick_model"));
      TexturedModel shop_model = new TexturedModel(shopmodel, shoptexture);
      ArrayList<ItemGroup> shop_lootc = new ArrayList();
      
      for(int i = 0; i < 30; ++i) {
         shop_lootc.add(new ItemGroup());
         ((ItemGroup)shop_lootc.get(i)).items.add(new ItemL(0, 1, 16));
         ((ItemGroup)shop_lootc.get(i)).items.add(new ItemL(1, 1, 16));
         ((ItemGroup)shop_lootc.get(i)).items.add(new ItemL(2, 1, 26));
         ((ItemGroup)shop_lootc.get(i)).items.add(new ItemL(4, 1, 16));
      }

      for(int i = 0; i < 8; ++i) {
         int x = random.nextInt(200);
         int z = random.nextInt(200);
         shops.add(new Entity(shop_model, new Vector3f((float)x, terrain.getHeightOfTerrain((float)x, (float)z), (float)z), 0.0F, 0.0F, 0.0F, 1.3F));
         shop_loot.add(new Loot("Shop", true, shop_lootc));
      }

      ModelData data5 = OBJFileLoader.loadOBJ("stick");
      RawModel model5 = loader.loadtoVAO(data5.getVertices(), data5.getTextureCoords(), data5.getNormals(), data5.getIndices(), data5);
      ModelTexture texture5 = new ModelTexture(loader.loadTexture("stick_model"));
      TexturedModel stick_model = new TexturedModel(model5, texture5);
      Entity sink = new Entity(sink_model, new Vector3f(140.0F, terrain.getHeightOfTerrain(140.0F, 140.0F), 140.0F), 0.0F, 0.0F, 0.0F, 0.5F);
      ModelTexture placement_texture = new ModelTexture(loader.loadTexture("placement_texture"));
      ModelData treedata = OBJFileLoader.loadOBJ("tree/brach/stright");
      RawModel treemodel = loader.loadtoVAO(treedata.getVertices(), treedata.getTextureCoords(), treedata.getNormals(), treedata.getIndices(), treedata);
      ModelTexture treetexture = new ModelTexture(loader.loadTexture("tree_leaf"));
      ModelTexture tree_leaftexture = new ModelTexture(loader.loadTexture("tree_leaf"));
      TexturedModel treetmodel = new TexturedModel(treemodel, treetexture);
      ModelData treedata2 = OBJFileLoader.loadOBJ("tree/brach/stright");
      RawModel treemodel2 = loader.loadtoVAO(treedata2.getVertices(), treedata2.getTextureCoords(), treedata2.getNormals(), treedata2.getIndices(), treedata2);
      ModelData treedata3 = OBJFileLoader.loadOBJ("tree/brach/up");
      RawModel treemodel3 = loader.loadtoVAO(treedata3.getVertices(), treedata3.getTextureCoords(), treedata3.getNormals(), treedata3.getIndices(), treedata3);
      ModelData treedata4 = OBJFileLoader.loadOBJ("tree/brach/down");
      RawModel treemodel4 = loader.loadtoVAO(treedata4.getVertices(), treedata4.getTextureCoords(), treedata4.getNormals(), treedata4.getIndices(), treedata4);
      ModelData treedata5 = OBJFileLoader.loadOBJ("tree/brach/stright_leaf");
      RawModel treemodel5 = loader.loadtoVAO(treedata5.getVertices(), treedata5.getTextureCoords(), treedata5.getNormals(), treedata5.getIndices(), treedata5);
      TexturedModel treetmodel2 = new TexturedModel(treemodel2, treetexture);
      TexturedModel treetmodel3 = new TexturedModel(treemodel3, treetexture);
      TexturedModel treetmodel4 = new TexturedModel(treemodel4, treetexture);
      TexturedModel treetmodel5 = new TexturedModel(treemodel5, tree_leaftexture);
      ModelData sheepdata = OBJFileLoader.loadOBJ("sheep");
      RawModel sheepmodel = loader.loadtoVAO(sheepdata.getVertices(), sheepdata.getTextureCoords(), sheepdata.getNormals(), sheepdata.getIndices(), sheepdata);
      ModelTexture sheeptexture = new ModelTexture(loader.loadTexture("sheep"));
      TexturedModel sheeptmodel = new TexturedModel(sheepmodel, sheeptexture);
      ModelData truckdata = OBJFileLoader.loadOBJ("truck");
      RawModel truckmodel = loader.loadtoVAO(truckdata.getVertices(), truckdata.getTextureCoords(), truckdata.getNormals(), truckdata.getIndices(), truckdata);
      ModelTexture trucktexture = new ModelTexture(loader.loadTexture("truck"));
      TexturedModel trucktmodel = new TexturedModel(truckmodel, trucktexture);
      Entity truck = new Entity(trucktmodel, new Vector3f(140.0F, terrain.getHeightOfTerrain(140.0F, 140.0F), 140.0F), 0.0F, 0.0F, 0.0F, 1.0F);

      int timesx;
      Random random10;
      for(timesx = 0; timesx < 600; ++timesx) {
         random10 = new Random();
         antifacts.add(new Car(trucktmodel, new Vector3f((float)random10.nextInt(200), (float)-((random10.nextInt(20) + 10)), (float)random10.nextInt(200)), 
        		 0.0F, 0.0F, 0.0F, 1.0F, phy_player));
      }

      for(timesx = 0; timesx < 40; ++timesx) {
         random10 = new Random();
         animals.add(new Sheep(sheeptmodel, new Vector3f((float)random10.nextInt(200), terrain.getHeightOfTerrain(140.0F, 140.0F), (float)random10.nextInt(200)), 0.0F, 0.0F, 0.0F, 0.4F, source));
         ((Animal)animals.get(timesx)).source.play(buffer);
      }

      placedObject.add(sink);
      timesx = Integer.valueOf(String.valueOf(terrain.seed).charAt(0));
      int timesz = Integer.valueOf(String.valueOf(terrain.seed).charAt(1));
      for(int i = 0; i < 8; ++i) {
         float x2 = (float)(i * (timesx / 5));
         float z2 = (float)(i * timesz);
         z2 = (float)Math.floorMod((int)z2, 200);
         x2 = (float)Math.floorMod((int)x2, 200);
         trees.add(new Tree(treetmodel2, new Vector3f(x2, terrain.getHeightOfTerrain(x2, z2), z2), 0.0F, 0.0F, 0.0F, 0.4F));
      }
      for(int i = 0; i < 200; ++i) {
         Random random2 = new Random();
         Random random3 = new Random();
         int x2 = random2.nextInt(200) + 10;
         int z2 = random3.nextInt(200) + 10;
         random2 = new Random();
         pickup_phy.add(random2.nextBoolean());
         if ((Boolean)pickup_phy.get(i)) {
            pickup.add(new Entity(stick_model, new Vector3f((float)x2, terrain.getHeightOfTerrain((float)x2, (float)z2) + 20.0F, (float)z2), 0.0F, 0.0F, 0.0F, 0.4F));
         } else {
            pickup.add(new Entity(stick_model, new Vector3f((float)x2, terrain.getHeightOfTerrain((float)x2, (float)z2), (float)z2), 0.0F, 0.0F, 0.0F, 0.4F));
         }

         pickup_inv.add(2);
      }

      ModelData data7 = OBJFileLoader.loadOBJ("stone");
      RawModel model7 = loader.loadtoVAO(data7.getVertices(), data7.getTextureCoords(), data7.getNormals(), data7.getIndices(), data7);
      ModelTexture texture7 = new ModelTexture(loader.loadTexture("stone"));
      TexturedModel stone_model = new TexturedModel(model7, texture7);

      for(int i = 0; i < 200; ++i) {
         new Random();
         Random random2 = new Random();
         Random random3 = new Random();
         int x2 = random2.nextInt(200) + 10;
         int z2 = random3.nextInt(200) + 10;
         Random random4 = new Random();
         pickup_phy.add(random4.nextBoolean());
         if ((Boolean)pickup_phy.get(i + 200)) {
            pickup.add(new Entity(stone_model, new Vector3f((float)x2, terrain.getHeightOfTerrain((float)x2, (float)z2) + 20.0F, (float)z2), 0.0F, 0.0F, 0.0F, 0.2F));
         } else {
            pickup.add(new Entity(stone_model, new Vector3f((float)x2, terrain.getHeightOfTerrain((float)x2, (float)z2), (float)z2), 0.0F, 0.0F, 0.0F, 0.2F));
         }

         pickup_inv.add(3);
      }

      ItemPro med_kit_pro = new ItemPro();
      med_kit_pro.setHeal(true);
      med_kit_pro.setHealamount(0.07F);
      med_kit_pro.setTimetouse(200);
      med_kit_pro.setIsuseable(true);
      itemmanager.additem("Med Kit", loader.loadTexture("med_kit"), med_kit_pro);
      ItemPro stick_pro = new ItemPro();
      itemmanager.additem("Stick", loader.loadTexture("stick"), stick_pro);
      ItemPro stone_pro = new ItemPro();
      itemmanager.additem("Stone", loader.loadTexture("stone_inv"), stone_pro);
      ItemPro bark_pro = new ItemPro();
      itemmanager.additem("Bark", loader.loadTexture("bark"), bark_pro);
      ItemPro leaf_pro = new ItemPro();
      itemmanager.additem("Leaf", loader.loadTexture("leaf"), leaf_pro);
      ItemPro axe_pro = new ItemPro();
      itemmanager.additem("Basic Axe", loader.loadTexture("axe"), axe_pro);
      ItemPro anti_covers_pro = new ItemPro();
      itemmanager.additem("Anti Cover", loader.loadTexture("anti_cover"), anti_covers_pro);
      inventory[0] = 1;
      inventorycount[0] = 1;
      inventory[1] = 6;
      inventorycount[1] = 1;
      inventory[2] = 7;
      inventorycount[2] = 1;
      ParticleMaster.init(loader, renderer.getProjectionMatrix());
      GuiButton BUTTON = new GuiButton(sink_t.getTextureID(), new Vector2f(0.0F, 0.0F), new Vector2f(0.09F, 0.15F), sink_tsel.getTextureID(), "", font);
      guis.add(BUTTON);

      for(int i = 0; i < placement_models.size(); ++i) {
         GuiButton ITEM = new GuiButton((Integer)placement_textures.get(i), new Vector2f(0.8F, 0.8F - (float)i * 0.35F), new Vector2f(0.09F, 0.15F), (Integer)placement_textures_sel.get(i), (String)placement_popup.get(i), font);
         guis.add(ITEM);
         placement_buttons.add(ITEM);
      }

      Fbo multisampleFbo = new Fbo(Display.getWidth(), Display.getHeight(), 2);
      new Fbo(Display.getWidth(), Display.getHeight(), 1);
      PostProcessing.init(loader);

      while(!Display.isCloseRequested()) {
         guis.clear();
         MouseRay.findmousepos(camera, terrain);
         if (shadows) {
            entities.clear();

            for(int i = 0; i < floor.size(); ++i) {
               entities.add((Entity)floor.get(i));
            }

            for(int i = 0; i < pickup.size(); ++i) {
               entities.add((Entity)pickup.get(i));
            }

            for(int i = 0; i < placedObject.size(); ++i) {
               entities.add((Entity)placedObject.get(i));
            }

            entities.add(player);

            for(int i = 0; i < animals.size(); ++i) {
               entities.add((Entity)animals.get(i));
            }

            for(int i = 0; i < antifacts.size(); ++i) {
               entities.add((Entity)antifacts.get(i));
            }

            entities.add(truck);
            entities.add(sink);
         }

         ++craftcount;
         ++sinecounter;
         if (sinecounter > 360) {
            sinecounter = 0;
         }
         
         truck.setPosition(MouseRay.getMousepos());

         ParticleMaster.update(camera);
         renderer.renderShadowMap(entities, light);
         f_to_grab.rotY = (float)((double)f_to_grab.rotY + 0.5D);
         if ((double)player.health > 0.15D) {
            player.health = 0.15F;
         }

         for(int i = 0; i < animals.size(); ++i) {
            renderer.processEntity((Entity)animals.get(i));
            ((Animal)animals.get(i)).source.setPosition(((Animal)animals.get(i)).getPosition().x, ((Animal)animals.get(i)).getPosition().y, ((Animal)animals.get(i)).getPosition().z, camera);
         }

         for(int i = 0; i < animals.size(); ++i) {
            ((Animal)animals.get(i)).move(terrain);
         }

         for(int i = 0; i < antifacts.size(); ++i) {
            antifacts.get(i).update(terrain, renderer, player, camera);
            renderer.processEntity((Entity)antifacts.get(i));
         }

         //renderer.processEntity(truck);
         checkInvInputs();
         renderer.processTerrain(terrain);
         renderer.processEntity(entity);
         renderer.processEntity(entity2);
         player.move(terrain, loader, camera);
         player.processPhysics(terrain, phy_player, false, renderer);
         if (Math.floorMod(sinecounter, 2) == 0) {
            TexturedModel[] treemodels = new TexturedModel[]{treetmodel, treetmodel2, treetmodel3, treetmodel4, treetmodel5};

            for(int i = 0; i < trees.size(); ++i) {
               ((Tree)trees.get(i)).grow_rig_tree(treemodels);
            }
         }
         
         if(Keyboard.isKeyDown(Keyboard.KEY_T)) {
        	 if(which_driving_car != null) {
        		 which_driving_car = null;
            	 player.getPosition().x += 5;
        	 }
         }

         for(int i = 0; i < trees.size(); ++i) {
            ((Tree)trees.get(i)).getPosition().y = terrain.getHeightOfTerrain(((Tree)trees.get(i)).getPosition().x, ((Tree)trees.get(i)).getPosition().z);
            renderer.processEntity((Tree)trees.get(i));
         }

         renderer.processEntity((Entity)player);
         if (Keyboard.isKeyDown(34)) {
            player.phy = !player.phy;
         }

         int range = 5;
         boolean reciped;
         int var10002;
         for(int i = 0; i < pickup.size(); ++i) {
            ((Entity)pickup.get(i)).processPhysics(terrain, player, false, renderer);
            if (((Entity)pickup.get(i)).getPosition().x - (float)range < player.getPosition().x && ((Entity)pickup.get(i)).getPosition().x + (float)range > player.getPosition().x && ((Entity)pickup.get(i)).getPosition().z - (float)range < player.getPosition().z && ((Entity)pickup.get(i)).getPosition().z + (float)range > player.getPosition().z && ((Entity)pickup.get(i)).getPosition().y - (float)range < player.getPosition().y && ((Entity)pickup.get(i)).getPosition().y + (float)range > player.getPosition().y) {
               Entity f_to_grab_per = new Entity(f_to_grab.getModel(), new Vector3f(((Entity)pickup.get(i)).getPosition().x, (float)((double)((Entity)pickup.get(i)).getPosition().y + 1.0D + Math.sin(Math.toRadians((double)sinecounter)) / 2.0D), ((Entity)pickup.get(i)).getPosition().z), f_to_grab.rotX, f_to_grab.rotY, f_to_grab.rotZ, f_to_grab.getScale());
               renderer.processEntity(f_to_grab_per);
               if (Keyboard.isKeyDown(33)) {
                  reciped = false;

                  for(int i1 = 0; i1 < inventory.length; ++i1) {
                     if (inventory[i1] == 0 || inventory[i1] == (Integer)pickup_inv.get(i)) {
                        inventory[i1] = (Integer)pickup_inv.get(i);
                        var10002 = inventorycount[i1]++;
                        reciped = true;
                        break;
                     }
                  }

                  if (reciped) {
                     pickup.remove(i);
                     continue;
                  }
               }
            }

            renderer.processEntity((Entity)pickup.get(i));
         }

         if (inventory[inventorysel] == 7) {
            if (Mouse.isButtonDown(0)) {
               for(int i = 0; i < antifacts.size(); ++i) {
                  if (isInRange(((Entity)antifacts.get(i)).getPosition(), player.getPosition(), 10.0F, 10.0F, 10.0F) && antifact_index != i) {
                     antifact_index = i;
                  }
               }
            }
         } else {
            antifact_index = -1;
         }

         if (antifact_index != -1) {
            ((Entity)antifacts.get(antifact_index)).getPosition().x = player.getPosition().x;
            ((Entity)antifacts.get(antifact_index)).getPosition().y = player.getPosition().y;
            ((Entity)antifacts.get(antifact_index)).getPosition().z = player.getPosition().z - 5.0F;
         }

         for(int i = 0; i < shops.size(); ++i) {
            if (isInRange(((Entity)shops.get(i)).getPosition(), player.getPosition(), 3.0F, 15.0F, 3.0F)) {
               ((Loot)shop_loot.get(i)).printallitems();
            }

            renderer.processEntity((Entity)shops.get(i));
         }

         if (inventory[inventorysel] == 6 && Mouse.isButtonDown(0)) {
            for(int i = 0; i < trees.size(); ++i) {
               if (isInRange(((Tree)trees.get(i)).getPosition(), player.getPosition(), 20.0F, 500000.0F, 20.0F)) {
                  --((Tree)trees.get(i)).health;
                  if (((Tree)trees.get(i)).health <= 0) {
                     ((Tree)trees.get(i)).slizeTree(0);
                  }
               }
            }
         }

         Keyboard.isKeyDown(25);
         if (craftcount >= 10) {
            craftcount = 0;
            if (inventory[inventorysel] != 0 && Keyboard.isKeyDown(46)) {
               boolean doit = true;

               for(int i = 0; i < crafted.size(); ++i) {
                  if ((Integer)crafted.get(i) == inventorysel) {
                     doit = false;
                  }
               }

               if (doit) {
                  crafted.add(inventorysel);
                  crafted_type.add(inventory[inventorysel]);
               }
            }
         }

         if (Keyboard.isKeyDown(45)) {
            crafted.clear();
            crafted_type.clear();
         }

         BUTTON.mouseclickedonbutton(true);
         BUTTON.manage_Drop_down_menu();

         try {
            for(int i = 0; i < crafting.size(); ++i) {
               ArrayList<Integer> recipe = new ArrayList();

               for(int i1 = 0; i1 < ((Crafting_Recipe)crafting.get(i)).recipe.length; ++i1) {
                  recipe.add(((Crafting_Recipe)crafting.get(i)).recipe[i1]);
               }

               reciped = true;

               for(int i1 = 0; i1 < recipe.size(); ++i1) {
                  if (i1 > crafted.size() || i1 > crafted_type.size()) {
                     reciped = false;
                     break;
                  }

                  if (recipe.get(i1) != crafted_type.get(i1)) {
                     reciped = false;
                  }
               }

               if (reciped) {
                  for(int i1 = 0; i1 < inventory.length; ++i1) {
                     if (inventory[i1] == 0 || inventory[i1] == ((Crafting_Recipe)crafting.get(i)).crafted) {
                        inventory[i1] = ((Crafting_Recipe)crafting.get(i)).crafted;
                        var10002 = inventorycount[i1]++;
                        break;
                     }
                  }

                  for(int i1 = 0; i1 < crafted.size(); ++i1) {
                     inventory[(Integer)crafted.get(i1)] = 0;
                     crafted.remove(i1);
                     crafted_type.remove(i1);
                  }
               }
            }
         } catch (IndexOutOfBoundsException var168) {
         }
         
         //renderer.processEntity(truck);

         if (Keyboard.isKeyDown(16) && inventory[inventorysel] != 0) {
            if (inventory[inventorysel] == 2) {
               pickup.add(new Entity(stick_model, new Vector3f((float)((double)player.getPosition().x + Math.sin((double)player.getRotX()) * 12.0D), player.getPosition().y + 4.0F, (float)((double)player.getPosition().z + Math.sin((double)player.getRotX()) * 12.0D)), 0.0F, 0.0F, 0.0F, 0.4F));
               pickup_inv.add(inventory[inventorysel]);
               pickup_phy.add(true);
               inventory[inventorysel] = 0;
            } else if (inventory[inventorysel] == 3) {
               pickup.add(new Entity(stone_model, new Vector3f((float)((double)player.getPosition().x + Math.sin((double)player.getRotX()) * 12.0D), player.getPosition().y + 4.0F, (float)((double)player.getPosition().z + Math.sin((double)player.getRotX()) * 12.0D)), 0.0F, 0.0F, 0.0F, 0.4F));
               pickup_inv.add(inventory[inventorysel]);
               pickup_phy.add(true);
               inventory[inventorysel] = 0;
            }
         }

         for(int i = 0; i < placement_models.size(); ++i) {
            ((GuiButton)placement_buttons.get(i)).manage_Drop_down_menu();
            GuiButton button = (GuiButton)placement_buttons.get(i);
            float x = button.getPostiion().x;
            float y = button.getPostiion().y;
            float sx = button.getScale().x;
            float sy = button.getScale().y;
            Vector2f mousepos = mousePosition();
            if (mousepos.x > x - sx / 2.0F && mousepos.y > y - sy / 2.0F && mousepos.x < x + sx && mousepos.y < y + sy) {
               ((GuiButton)placement_buttons.get(i)).setTexture(button.sel);
               ((GuiButton)placement_buttons.get(i)).drop_down.getPosition().x = mousePosition().x / 2.0F + 0.32F;
               ((GuiButton)placement_buttons.get(i)).drop_down.getPosition().y = 1.0F - (mousePosition().y / 2.0F + 0.6F);
               if (Mouse.isButtonDown(0) && placement_index != i) {
                  placement_index = i;
                  System.out.println(i);
                  ((GuiButton)placement_buttons.get(i)).setTexture(button.def);
               }
            } else {
               ((GuiButton)placement_buttons.get(i)).setTexture(button.def);
               ((GuiButton)placement_buttons.get(i)).drop_down.getPosition().x = -2.0F;
               ((GuiButton)placement_buttons.get(i)).drop_down.getPosition().y = -2.0F;
            }

            guis.add((GuiTexture)placement_buttons.get(i));

            for(int i1 = 0; i1 < ((ArrayList)placement_re.get(i)).size(); ++i1) {
               GuiTexture t = new GuiTexture(((Item)itemmanager.items.get((Integer)((ArrayList)placement_re.get(i)).get(i1))).textureid, new Vector2f(0.74F + (float)i1 * 0.055F, 0.63F - (float)i * 0.35F), new Vector2f(0.035F, 0.06F));
               guis.add(t);
            }

            GuiTexture tt = new GuiTexture(placement_texture.getTextureID(), new Vector2f(0.74F + (float)(((ArrayList)placement_re.get(i)).size() + 1) * 0.055F, 0.63F - (float)i * 0.35F), new Vector2f(0.06F, 0.03F));
            guis.add(tt);
            x = tt.getPostiion().x;
            y = tt.getPostiion().y;
            sx = tt.getScale().x;
            sy = tt.getScale().y;
            if (mousepos.x > x - sx / 2.0F && mousepos.y > y - sy / 2.0F && mousepos.x < x + sx && mousepos.y < y + sy && Mouse.isButtonDown(0)) {
               System.out.println("CLICK INDEX: " + i);
               boolean done = true;
               ArrayList<Integer> invremove = new ArrayList();
               for(int i1 = 0; i1 < ((ArrayList)placement_re.get(i)).size(); ++i1) {
                  boolean detected = false;

                  for(int i2 = 0; i2 < inventory.length; ++i2) {
                     if (inventory[i2] == (Integer)((ArrayList)placement_re.get(i)).get(i1)) {
                        detected = true;
                        invremove.add(i2);
                     }
                  }

                  if (!detected) {
                     done = false;
                  }
               }

               if (done) {
                  placement_amount.set(i, (Integer)placement_amount.get(i) + 1);

                  for(int i1 = 0; i1 < invremove.size(); ++i1) {
                     var10002 = inventorycount[(Integer)invremove.get(i1)];
                     if (inventorycount[(Integer)invremove.get(i1)] <= 0) {
                        inventory[(Integer)invremove.get(i1)] = 0;
                     }
                  }
               }
            }
         }

         for(int i = 0; i < crafted.size(); ++i) {
         }

         for(int i = 0; i < ((Crafting_Recipe)crafting.get(0)).recipe.length; ++i) {
         }

         for(int i = 0; i < floor.size(); ++i) {
            renderer.processEntity((Entity)floor.get(i));
         }

         if (Keyboard.isKeyDown(23) && dig_count == 0) {
            terrain.heights[(int)terrain.getGridOfXZ(player.getPosition().x, player.getPosition().z).x][(int)terrain.getGridOfXZ(player.getPosition().x, player.getPosition().z).y] -= 1f;
            terrain.model = terrain.remake_terrain(loader);
            dig_count = 10;
         }

         --dig_count;
         if (dig_count < 0) {
            dig_count = 0;
         }

         if (inventorysel == 0) {
            inv0.setTexture(invs);
         } else {
            inv0.setTexture(inv);
         }

         if (inventorysel == 1) {
            inv1.setTexture(invs);
         } else {
            inv1.setTexture(inv);
         }

         if (inventorysel == 2) {
            inv2.setTexture(invs);
         } else {
            inv2.setTexture(inv);
         }

         if (inventorysel == 3) {
            inv3.setTexture(invs);
         } else {
            inv3.setTexture(inv);
         }

         if (inventorysel == 4) {
            inv4.setTexture(invs);
         } else {
            inv4.setTexture(inv);
         }

         if (inventory[0] != 0) {
            invi0.setTexture(((Item)itemmanager.items.get(inventory[0] - 1)).textureid);
         } else {
            invi0.setTexture(trans);
         }

         if (inventory[1] != 0) {
            invi1.setTexture(((Item)itemmanager.items.get(inventory[1] - 1)).textureid);
         } else {
            invi1.setTexture(trans);
         }

         if (inventory[2] != 0) {
            invi2.setTexture(((Item)itemmanager.items.get(inventory[2] - 1)).textureid);
         } else {
            invi2.setTexture(trans);
         }

         if (inventory[3] != 0) {
            invi3.setTexture(((Item)itemmanager.items.get(inventory[3] - 1)).textureid);
         } else {
            invi3.setTexture(trans);
         }

         if (inventory[4] != 0) {
            invi4.setTexture(((Item)itemmanager.items.get(inventory[4] - 1)).textureid);
         } else {
            invi4.setTexture(trans);
         }

         if (inventory[inventorysel] != 0) {
            if (Mouse.isButtonDown(0)) {
               if (((Item)itemmanager.items.get(inventory[inventorysel] - 1)).itemprotecties.isIsuseable()) {
                  ++usingitemtime;
               }
            } else {
               usingitemtime = 0;
            }
         }

         guis.add(inv0);
         guis.add(inv1);
         guis.add(inv2);
         guis.add(inv3);
         guis.add(inv4);
         guis.add(invi0);
         guis.add(invi1);
         guis.add(invi2);
         guis.add(invi3);
         guis.add(invi4);
         guis.add(gui3);
         guis.add(gui2);
         guis.add(gui);
         if (inventory[inventorysel] != 0 && usingitemtime > ((Item)itemmanager.items.get(inventory[inventorysel] - 1)).itemprotecties.getTimetouse() && ((Item)itemmanager.items.get(inventory[inventorysel] - 1)).itemprotecties.isHeal()) {
            player.health += ((Item)itemmanager.items.get(inventory[inventorysel] - 1)).itemprotecties.getHealamount();
            inventory[inventorysel] = 0;
         }

         if (Keyboard.isKeyDown(21) && placing) {
            placing = false;
            ((Entity)placedObject.get(placedObject.size() - 1)).model.texture = texture8;
         } else if (Mouse.isButtonDown(0) && !placing) {
            placedObject.add(new Entity(new TexturedModel(model8, placement_texture), new Vector3f(140.0F, terrain.getHeightOfTerrain(140.0F, 140.0F), 140.0F), 0.0F, 0.0F, 0.0F, 0.5F));
            placing = true;
         }

         if (placing && (Integer)placement_amount.get(placement_index) > 0) {
            ((Entity)placedObject.get(placedObject.size() - 1)).model = (TexturedModel)placement_models.get(placement_index);
            int distance = 4;
            ((Entity)placedObject.get(placedObject.size() - 1)).setPosition(new Vector3f((float)((double)player.getPosition().x + Math.sin(Math.toRadians((double)player.getRotY())) * (double)distance), terrain.getHeightOfTerrain((float)((double)player.getPosition().x + Math.sin(Math.toRadians((double)player.getRotY())) * (double)distance), (float)((double)player.getPosition().z + Math.cos(Math.toRadians((double)player.getRotY())) * (double)distance)), (float)((double)player.getPosition().z + Math.cos(Math.toRadians((double)player.getRotY())) * (double)distance)));
            ((Entity)placedObject.get(placedObject.size() - 1)).setRotY(player.rotY);
            placement_amount.set(placement_index, (Integer)placement_amount.get(placement_index) - 1);
         }

         for(int i = 0; i < placedObject.size(); ++i) {
            renderer.processEntity((Entity)placedObject.get(i));
         }

         fbos.bindReflectionFrameBuffer();
         multisampleFbo.bindFrameBuffer();
         renderer.render(lights, camera);
         fbos.unbindCurrentFrameBuffer();
         ParticleMaster.renderParticles(camera);
         waterR.render(waters, camera);
         multisampleFbo.unbindFrameBuffer();
         PostProcessing.doPostProcessing(multisampleFbo.getColourTexture());
         guiRenderer.render(guis);
         gui3.getScale().x = player.health * 0.6F;
         TextMaster.render();
         DisplayManager.updateDisplay();
      }

      multisampleFbo.cleanUp();
      guiRenderer.cleanUp();
      renderer.cleanUp();
      loader.cleanUp();
      ParticleMaster.cleanUp();
      waterS.cleanUp();
      fbos.cleanUp();
      TextMaster.cleanUp();
      PostProcessing.cleanUp();
      source.delete();
      AudioMaster.cleanUp();
      DisplayManager.closeDisplay();
   }

   public static Vector2f mousePosition() {
      float mx = 2.0F * (float)Mouse.getX() / (float)Display.getWidth() - 1.0F;
      float my = 2.0F * (float)Mouse.getY() / (float)Display.getHeight() - 1.0F;
      return new Vector2f(mx, my);
   }

   public static void checkInvInputs() {
      if (Keyboard.isKeyDown(2)) {
         inventorysel = 0;
      }

      if (Keyboard.isKeyDown(3)) {
         inventorysel = 1;
      }

      if (Keyboard.isKeyDown(4)) {
         inventorysel = 2;
      }

      if (Keyboard.isKeyDown(5)) {
         inventorysel = 3;
      }

      if (Keyboard.isKeyDown(6)) {
         inventorysel = 4;
      }

   }

   public static boolean isInRange(Vector3f position1, Vector3f position2, float rangex, float rangey, float rangez) {
      return position1.x - rangex < position2.x && position1.x + rangex > position2.x && position1.z - rangez < position2.z && position1.z + rangez > position2.z && position1.y - rangey < position2.y && position1.y + rangey > position2.y;
   }
}