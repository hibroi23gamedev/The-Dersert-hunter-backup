package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener{
	
	public boolean[] keys = new boolean[4];

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int code = e.getKeyCode();
		if(code == KeyEvent.VK_A) {
			keys[0] = true;
		}
		if(code == KeyEvent.VK_D) {
			keys[1] = true;
		}
		if(code == KeyEvent.VK_W) {
			keys[2] = true;
		}
		if(code == KeyEvent.VK_S) {
			keys[3] = true;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		int code = e.getKeyCode();
		if(code == KeyEvent.VK_A) {
			keys[0] = false;
		}
		if(code == KeyEvent.VK_D) {
			keys[1] = false;
		}
		if(code == KeyEvent.VK_W) {
			keys[2] = false;
		}
		if(code == KeyEvent.VK_S) {
			keys[3] = false;
		}
	}

}
