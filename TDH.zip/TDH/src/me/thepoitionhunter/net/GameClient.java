package me.thepoitionhunter.net;

import java.net.DatagramSocket;
import java.io.IOException;
import java.net.*;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import me.thepoitionhunter.main.GamePanel;

public class GameClient extends Thread{
	public InetAddress ipAddress;
	private DatagramSocket socket;
	private GamePanel gp;
	
	public GameClient(String ipAddress, GamePanel gp) {
		this.gp = gp;
		try {
			this.socket = new DatagramSocket();
			this.ipAddress = InetAddress.getByName(ipAddress);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		while(true) {
			byte[] data = new byte[1024];
			DatagramPacket packet = new DatagramPacket(data, data.length);
			try {
				socket.receive(packet);
			} catch (IOException e) {
				e.printStackTrace();
			}
			String message = new String(packet.getData());
			System.out.println("SERVER >"+message);
		}
	}
	
	public void sendData(byte[] data) {
		DatagramPacket packet = new DatagramPacket(data, data.length, ipAddress, 1331);
		try {
			socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
