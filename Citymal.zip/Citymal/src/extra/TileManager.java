package extra;

import org.lwjgl.util.vector.Vector2f;

import engineTester.MainGameLoop;

import models.*;
import render.*;
import render.Loader;
import render.OBJFileLoader;
import textures.ModelTexture;

public class TileManager {
	public static Road[] tile_types = new Road[2];
	
	public static void init(Loader loader) {
		tile_types[0] = new Road(0, null);
		ModelData road_data = OBJFileLoader.loadOBJ("road");
		RawModel road_model = loader.loadtoVAO(road_data.getVertices(), road_data.getTextureCoords(), road_data.getNormals(), road_data.getIndices(), road_data);
		ModelData roadc_data = OBJFileLoader.loadOBJ("road_curve");
		RawModel roadc_model = loader.loadtoVAO(roadc_data.getVertices(), roadc_data.getTextureCoords(), roadc_data.getNormals(), roadc_data.getIndices(),
				roadc_data);
		ModelData roadci_data = OBJFileLoader.loadOBJ("road_curve_opp");
		RawModel roadci_model = loader.loadtoVAO(roadci_data.getVertices(), roadci_data.getTextureCoords(), roadci_data.getNormals(), roadci_data.getIndices(),
				roadci_data);
		ModelData roadct_data = OBJFileLoader.loadOBJ("road_t");
		RawModel roadct_model = loader.loadtoVAO(roadct_data.getVertices(), roadct_data.getTextureCoords(), roadct_data.getNormals(), roadct_data.getIndices(),
				roadct_data);
		ModelData roadco_data = OBJFileLoader.loadOBJ("road_o");
		RawModel roadco_model = loader.loadtoVAO(roadco_data.getVertices(), roadco_data.getTextureCoords(), roadco_data.getNormals(), roadco_data.getIndices(),
				roadco_data);
		ModelTexture road_texture = new ModelTexture(loader.loadTexture("road"));
		ModelTexture roadc_texture = new ModelTexture(loader.loadTexture("road_curve"));
		TexturedModel road = new TexturedModel(road_model, road_texture);
		tile_types[1] = new Road(1, road);
		tile_types[1].exmodel = new TexturedModel(roadc_model, roadc_texture);
		tile_types[1].exinmodel = new TexturedModel(roadci_model, roadc_texture);
		tile_types[1].extmodel = new TexturedModel(roadct_model, roadc_texture);
		tile_types[1].exomodel = new TexturedModel(roadco_model, roadc_texture);
	}
	
	public static Road gettileatindex(float x, float z) {
		int tx = (int) (x/8);
		int tz = (int) (z/8);
		return MainGameLoop.tiles[tx][tz];
	}
	public static Vector2f findtilexy(float x, float z) {
		int tx = (int) (x/8);
		int tz = (int) (z/8);
		return new Vector2f(tx, tz);
	}
	
}
