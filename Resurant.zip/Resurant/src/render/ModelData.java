package render;

import java.util.ArrayList;
import java.util.List;

public class ModelData {
   private float[] vertices;
   private float[] textureCoords;
   private float[] normals;
   private int[] indices;
   public List<Vertex> vertex_positions;
   private float furthestPoint;

   public ModelData(List<Vertex> vertex_positions, float[] vertices, float[] textureCoords, float[] normals, int[] indices, float furthestPoint) {
      this.vertices = vertices;
      this.textureCoords = textureCoords;
      this.normals = normals;
      this.indices = indices;
      this.vertex_positions = vertex_positions;
      this.furthestPoint = furthestPoint;
   }

   public float[] getVertices() {
      return this.vertices;
   }

   public float[] getTextureCoords() {
      return this.textureCoords;
   }

   public float[] getNormals() {
      return this.normals;
   }

   public int[] getIndices() {
      return this.indices;
   }

   public float getFurthestPoint() {
      return this.furthestPoint;
   }
}
