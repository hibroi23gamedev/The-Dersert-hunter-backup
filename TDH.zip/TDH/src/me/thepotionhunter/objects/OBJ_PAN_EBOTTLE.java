package me.thepotionhunter.objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import me.thepoitionhunter.main.*;

public class OBJ_PAN_EBOTTLE extends SuperObect{
	GamePanel gp;
	public OBJ_PAN_EBOTTLE(GamePanel gp) {
		this.gp = gp;
		name = "panebottle";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/panebottle.png"));
			uTool.scaleImage(image,gp.tileSize, gp.tileSize);
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = false;
	}
}
